import {
  useEffect,
  useState,
} from "react";

import {
  asNumber,
  runDql,
} from "./query";

import {
  TopologyModel,
  TopologyNode,
} from "../types/observability";

const extractAppCode = (
  value: unknown,
): string | undefined => {
  if (!value) {
    return undefined;
  }

  const text =
    typeof value === "string"
      ? value
      : JSON.stringify(value);

  const match =
    text.match(
      /(?:^|["',\s])APP:([A-Za-z0-9_-]+)/i,
    );

  return match?.[1]?.toUpperCase();
};

export const useEnterpriseTopology = () => {
  const [
    data,
    setData,
  ] = useState<TopologyModel>({
    nodes: [],
    edges: [],
  });

  const [
    loading,
    setLoading,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState<string | null>(
    null,
  );

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setError(null);

      try {
        /*
         * IMPORTANT:
         *
         * No hard-coded applications.
         * No hard-coded MQ.
         * No hard-coded databases.
         *
         * This query only discovers
         * services that actually have
         * observed spans.
         */
        const query = `
fetch spans
| filter isNotNull(dt.entity.service)
| lookup [
    fetch dt.entity.service
    | fields id, entity.name, tags
  ],
  sourceField:dt.entity.service,
  lookupField:id,
  fields:{
    service_name=entity.name,
    service_tags=tags
  }
| filter isNotNull(service_tags)
| summarize
    traffic=count(),
    by:{
      dt.entity.service,
      service_name,
      service_tags
    }
| sort traffic desc
| limit 1000
`;

        const rows =
          await runDql(query);

        /*
         * Aggregate observed services
         * into their APP:<code>.
         */
        const applications =
          new Map<
            string,
            number
          >();

        for (const row of rows) {
          const appCode =
            extractAppCode(
              row.service_tags,
            );

          if (!appCode) {
            continue;
          }

          const traffic =
            asNumber(
              row.traffic,
            );

          applications.set(
            appCode,
            (
              applications.get(
                appCode,
              ) ?? 0
            ) + traffic,
          );
        }

        const nodes:
          TopologyNode[] =
          Array.from(
            applications.entries(),
          )
            .sort(
              (
                [, trafficA],
                [, trafficB],
              ) =>
                trafficB -
                trafficA,
            )
            .map(
              ([
                appCode,
                traffic,
              ]) => ({
                id:
                  `app:${appCode}`,

                label:
                  appCode,

                kind:
                  "application",

                health:
                  "healthy",

                appCode,

                traffic,
              }),
            );

        /*
         * We intentionally do NOT
         * manufacture relationships
         * between applications.
         *
         * Enterprise edges will be
         * added only after we prove
         * source AppCode -> target
         * AppCode from span telemetry.
         */
        const nextData:
          TopologyModel = {
            nodes,
            edges: [],
          };

        if (!cancelled) {
          setData(
            nextData,
          );
        }
      } catch (caught) {
        console.error(
          "Enterprise topology query failed",
          caught,
        );

        if (!cancelled) {
          setData({
            nodes: [],
            edges: [],
          });

          setError(
            caught instanceof
              Error
              ? caught.message
              : "Unable to load enterprise topology.",
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void load();

    return () => {
      cancelled = true;
    };
  }, []);

  return {
    data,
    loading,
    error,
  };
};