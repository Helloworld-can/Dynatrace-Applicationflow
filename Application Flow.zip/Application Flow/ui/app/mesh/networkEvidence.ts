import {DqlRecord,asString} from '../hooks/query';
import {Health,TopologyNode,RequestOutcomes} from '../types/observability';

export type NetworkRole='proxy'|'gateway'|'loadbalancer'|'network'|'saas'|'external';
export const roleNames:Record<NetworkRole,string>={proxy:'Proxy',gateway:'API gateway',loadbalancer:'Load balancer',network:'Network device',saas:'SaaS',external:'External endpoint'};
export function classifyNetwork(row:DqlRecord):{role:NetworkRole;basis:string}|undefined {
  const type=asString(row.serviceType).toUpperCase().replace(/[ -]/g,'_');
  const roles:Record<string,NetworkRole>={PROXY:'proxy',REVERSE_PROXY:'proxy',API_GATEWAY:'gateway',LOAD_BALANCER:'loadbalancer',NETWORK_DEVICE:'network',SAAS:'saas'};
  if(roles[type])return {role:roles[type],basis:`Entity serviceType: ${type}`};
  const relations=row.runs_on;
  if(relations&&typeof relations==='object')for(const [key,value] of Object.entries(relations)){
    if(!value||(Array.isArray(value)&&!value.length))continue;
    if(/(?:^|\.)((aws_application|aws_network|azure)_load_balancer|elastic_load_balancer)$/.test(key))return {role:'loadbalancer',basis:`Observed runs_on relationship: ${key}`};
    if(/(?:^|\.)(azure_api_management_service|azure_application_gateway)$/.test(key))return {role:'gateway',basis:`Observed runs_on relationship: ${key}`};
  }
  const technologies:unknown[]=Array.isArray(row.softwareTechnologies)?row.softwareTechnologies:[];
  for(const tech of technologies){
    const type=typeof tech==='object'&&tech!==null&&'type' in tech?asString(tech.type).toUpperCase():asString(tech).toUpperCase();
    // Only role-specific technology identities; NGINX/APACHE alone are ambiguous.
    if(/^(HAPROXY|ENVOY)$/.test(type))return {role:'proxy',basis:`Observed software technology: ${type}`};
    if(/^(KONG|APIGEE|AWS_API_GATEWAY|AZURE_API_MANAGEMENT)$/.test(type))return {role:'gateway',basis:`Observed software technology: ${type}`};
  }
  return undefined;
}
export function outcomes(row:DqlRecord):RequestOutcomes {
  const total=Math.max(0,Number(row.requests??row.calls)||0),failed=Math.min(total,Math.max(0,Number(row.failed??row.errors)||0)),successful=Math.min(total-failed,Math.max(0,Number(row.successful)||0));
  return {successful,failed,unknown:Math.max(0,total-failed-successful)};
}
export function outcomeHealth(value:RequestOutcomes):Health {
  const known=value.failed+value.successful;
  if(!known)return 'unknown';
  const rate=100*value.failed/known;
  return rate>=5?'critical':rate>=1?'warning':value.unknown?'unknown':'healthy';
}
export function applyNetworkEvidence(nodes:TopologyNode[],entities:DqlRecord[],requests:DqlRecord[]):void {
  const metadata=new Map(entities.map(row=>[asString(row.service_id),row]));
  for(const node of nodes){
    const role=classifyNetwork(metadata.get(node.entityId??node.id)??{});
    if(role){node.networkRole=role.role;node.details=[...(node.details??[]),`${roleNames[role.role]} classification: ${role.basis}`];}
    else if(node.kind==='external'&&!node.id.startsWith('SERVICE-'))node.networkRole='external';
    if(!node.networkRole)continue;
    const evidence=requests.filter(row=>asString(row.service_id)===(node.entityId??node.id));
    if(evidence.length){node.requestOutcomes=evidence.map(outcomes).reduce((sum,value)=>({successful:sum.successful+value.successful,failed:sum.failed+value.failed,unknown:sum.unknown+value.unknown}),{successful:0,failed:0,unknown:0});}
    if(node.requestOutcomes){const known=node.requestOutcomes.successful+node.requestOutcomes.failed;node.errorRate=known?100*node.requestOutcomes.failed/known:undefined;}
    node.health='unknown';
    node.details=[...(node.details??[]),'Device/platform health is not assessed by this view. Request outcomes describe the observed path, not the cause of a failure.'];
  }
}
