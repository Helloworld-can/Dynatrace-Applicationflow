import {
  useEffect,
  useState,
} from "react";

import {
  asNumber,
  dqlString,
  runDql,
} from "./query";

import {
  RumExperience,
} from "../types/observability";

const empty:
  RumExperience = {
    sessions: 0,
    actions: 0,

    happy: 0,
    satisfied: 0,
    frustrated: 0,

    errors: 0,
  };

export const useRumExperience = (
  appCode: string,
) => {
  const [
    data,
    setData,
  ] = useState<RumExperience>(
    empty,
  );

  const [
    loading,
    setLoading,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState<
    string | null
  >(null);

  useEffect(() => {
    if (
      !appCode ||
      appCode === "ALL"
    ) {
      setData(empty);

      return;
    }

    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setError(null);

      try {
        const code =
          dqlString(
            appCode,
          );

        const query = `
fetch user.events
| filter
    app_code == ${code}
    OR app.code == ${code}
| summarize
    sessions=countDistinct(
      user.session.id
    ),
    actions=count(),
    happy=countIf(
      useraction.apdex.category
        == "SATISFIED"
    ),
    satisfied=countIf(
      useraction.apdex.category
        == "TOLERATING"
    ),
    frustrated=countIf(
      useraction.apdex.category
        == "FRUSTRATED"
    ),
    errors=countIf(
      useraction.is_error
        == true
    ),
    avg_duration=avg(
      useraction.duration
    )
`;

        const rows =
          await runDql(
            query,
          );

        const row =
          rows[0] ?? {};

        if (!cancelled) {
          setData({
            sessions:
              asNumber(
                row.sessions,
              ),

            actions:
              asNumber(
                row.actions,
              ),

            happy:
              asNumber(
                row.happy,
              ),

            satisfied:
              asNumber(
                row.satisfied,
              ),

            frustrated:
              asNumber(
                row.frustrated,
              ),

            errors:
              asNumber(
                row.errors,
              ),

            avgDurationMs:
              asNumber(
                row.avg_duration,
              ) / 1000000,
          });
        }
      } catch (caught) {
        if (!cancelled) {
          setError(
            caught instanceof Error
              ? caught.message
              : "Unable to load RUM experience.",
          );

          setData(empty);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void load();

    return () => {
      cancelled = true;
    };
  }, [appCode]);

  return {
    data,
    loading,
    error,
  };
};