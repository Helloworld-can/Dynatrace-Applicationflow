import {getEnvironmentUrl} from '@dynatrace-sdk/app-environment';

export function tenantOrigin():string|undefined {
  try {
    const url=new URL(getEnvironmentUrl());
    if(url.protocol==='https:'&&!['dynatrace.com','www.dynatrace.com'].includes(url.hostname))return url.origin;
  }catch{/* Runtime may be unavailable in a standalone preview. */}
  return undefined;
}
export function extensionsUrl():string|undefined {
  const origin=tenantOrigin();
  return origin?`${origin}/ui/apps/dynatrace.extensions.manager`:undefined;
}
