import {compactPositions} from './compactPositions';
import ELK from 'elkjs/lib/elk.bundled.js';
import type {ElkNode} from 'elkjs/lib/elk-api';
import type {Node,Edge} from '@xyflow/react';

export interface RoutedPoint {x:number;y:number}
export interface RouteData extends Record<string,unknown> {
  route?:RoutedPoint[];
  labelPosition?:{x:number;y:number;width:number;height:number};
  labelsVisible?:boolean;
}
const engine=new ELK();

/** Crossing-minimizing layered layout with explicit obstacle and label spacing. */
export async function routeGraph<N extends Node>(nodes:N[],edges:Edge[],compact=false,highLevel=false,fontSize=12):Promise<{nodes:N[];edges:Edge[]}> {
  if(compact){const positions=compactPositions(nodes.map(n=>n.id),edges);return {nodes:nodes.map(n=>({...n,position:positions.get(n.id)??{x:0,y:0}})),edges:edges.map(e=>{const a=positions.get(e.source)!,b=positions.get(e.target)!;const dx=b.x-a.x,dy=b.y-a.y,length=Math.hypot(dx,dy)||1;return {...e,data:{...e.data,route:undefined,labelPosition:undefined,curvature:0.35,circlePath:{sx:a.x+90+dx/length*38,sy:a.y+38+dy/length*38,tx:b.x+90-dx/length*38,ty:b.y+38-dy/length*38}}};})};}
  const ids=new Map(nodes.map((node,i)=>[node.id,`n${i}`]));
  const labels=new Map<string,{width:number;height:number}>();
  const graph:ElkNode={id:'root',layoutOptions:{
    'elk.algorithm':'layered','elk.direction':'RIGHT','elk.edgeRouting':'ORTHOGONAL',
    'elk.spacing.nodeNode':'65','elk.spacing.edgeNode':'40','elk.spacing.edgeEdge':'32',
    'elk.layered.spacing.nodeNodeBetweenLayers':highLevel?'130':'35','elk.layered.spacing.edgeNodeBetweenLayers':'16',
    'elk.layered.spacing.edgeEdgeBetweenLayers':'32','elk.layered.crossingMinimization.strategy':'LAYER_SWEEP',
    'elk.layered.nodePlacement.strategy':'BRANDES_KOEPF','elk.layered.nodePlacement.bk.fixedAlignment':'BALANCED','elk.layered.mergeEdges':'false',
    'elk.separateConnectedComponents':'true','elk.spacing.componentComponent':'100',
    'elk.padding':'[top=40,left=40,bottom=40,right=40]','elk.randomSeed':'11',
  },children:nodes.map(node=>{const id=ids.get(node.id)!;return {id,width:180,height:200,
    layoutOptions:{'elk.portConstraints':'FIXED_POS'},ports:(['in','out'] as const).flatMap(side=>{
      const incident=edges.map((edge,index)=>({edge,index})).filter(({edge})=>(side==='in'?edge.target:edge.source)===node.id);
      return incident.map(({index},order)=>({id:`${id}:${side}:${index}`,width:0,height:0,
        x:side==='in'?52:128,y:38+(incident.length>1?(order/(incident.length-1)-.5)*24:0),
        layoutOptions:{'elk.port.side':side==='in'?'WEST':'EAST'}}));
    })};}),edges:edges.map((edge,i)=>{
      const lines=typeof edge.label==='string'?edge.label.split('\n'):[];
      const width=Math.min(165,Math.max(60,...lines.map(line=>line.length*fontSize*0.55+8)));
      const height=lines.reduce((sum,line)=>sum+Math.max(1,Math.ceil((line.length*fontSize*0.55+8)/width))*(fontSize*1.3),0)+8;
      labels.set(`e${i}`,{width,height});
      return {id:`e${i}`,sources:[`${ids.get(edge.source)!}:out:${i}`],targets:[`${ids.get(edge.target)!}:in:${i}`],
        labels:lines.length?[{text:lines.join('\n'),width,height,layoutOptions:{'elk.edgeLabels.placement':'CENTER'}}]:[]};
    })};
  const laidOut=await engine.layout(graph);
  const positions=new Map(laidOut.children?.map(node=>[node.id,{x:node.x??0,y:node.y??0}])??[]);
  const routed=new Map(laidOut.edges?.map(edge=>[edge.id,edge])??[]);
  return {nodes:nodes.map(node=>({...node,position:positions.get(ids.get(node.id)!)??{x:0,y:0}})),edges:edges.map((edge,i)=>{
    const result=routed.get(`e${i}`),section=result?.sections?.[0],label=result?.labels?.[0],size=labels.get(`e${i}`)!;
    if(highLevel)return {...edge,data:{...edge.data,route:undefined,labelPosition:undefined,curvature:0.35}};
    return {...edge,data:{...edge.data,route:section?[section.startPoint,...section.bendPoints??[],section.endPoint]:undefined,
      labelPosition:label?{x:label.x??0,y:label.y??0,...size}:undefined}};
  })};
}

/** Rounded corners keep routed lanes legible while preserving the obstacle path. */
export function routePath(points:RoutedPoint[]):string {
  if(!points.length)return '';
  const first=points[0],lastPoint=points[points.length-1];
  // A gentle arch keeps even a direct connection visually curved.
  if(points.length===2){
    const dx=lastPoint.x-first.x,dy=lastPoint.y-first.y,length=Math.hypot(dx,dy)||1;
    const bow=Math.min(12,length/12),nx=-dy/length*bow,ny=dx/length*bow;
    return `M${first.x},${first.y} C${first.x+dx/3+nx},${first.y+dy/3+ny} ${first.x+2*dx/3+nx},${first.y+2*dy/3+ny} ${lastPoint.x},${lastPoint.y}`;
  }
  let path=`M${first.x},${first.y}`;
  for(let i=1;i<points.length-1;i++){
    const before=points[i-1],at=points[i],after=points[i+1];
    const incoming=Math.hypot(at.x-before.x,at.y-before.y),outgoing=Math.hypot(after.x-at.x,after.y-at.y);
    if(!incoming||!outgoing)continue;
    const radius=Math.min(32,incoming/2,outgoing/2);
    const a={x:at.x+(before.x-at.x)*radius/incoming,y:at.y+(before.y-at.y)*radius/incoming};
    const b={x:at.x+(after.x-at.x)*radius/outgoing,y:at.y+(after.y-at.y)*radius/outgoing};
    path+=` L${a.x},${a.y} Q${at.x},${at.y} ${b.x},${b.y}`;
  }
  const last=points[points.length-1];return `${path} L${last.x},${last.y}`;
}
