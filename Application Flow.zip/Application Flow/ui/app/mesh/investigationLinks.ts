import {tenantOrigin} from './tenantLinks';
const quote=(value:string)=>JSON.stringify(value);
function explorer(app:string,path:string,timeframe:string,params:Record<string,string>,filter?:string):string|undefined {
  const origin=tenantOrigin();if(!origin)return undefined;
  const url=new URL(`${origin}/ui/apps/${app}/${path}`);
  url.search=new URLSearchParams({tf:`now-${timeframe};now`,...params}).toString();
  if(filter)url.hash=new URLSearchParams({filtering:filter}).toString();
  return url.toString();
}
export function serviceLink(appCode:string|undefined,timeframe:string,id?:string){
  return explorer('dynatrace.services','explorer/services',timeframe,{perspective:'performance',sort:'healthIndicators:descending',...(id?{detailsid:id,sidebaropen:'false'}:{})},!id&&appCode?`tags = ${quote(`APP:${appCode}`)}`:undefined);
}
export function hostLink(timeframe:string,id?:string){
  return explorer('dynatrace.infraops','explorer/compute/hosts',timeframe,{perspective:'health',sort:'healthIndicators:descending',...(id?{fullpageid:id}:{})});
}
export function syntheticLink(appCode:string,timeframe:string){
  return explorer('dynatrace.synthetic','monitors',timeframe,{perspective:'default',sort:'healthIndicators:descending'},`Tag = ${quote(`APP:${appCode}`)}`);
}
export function rumLink(frontend:string,timeframe:string){
  return explorer('dynatrace.users.sessions','sessions/finished-sessions',timeframe,{perspective:'general',sort:'start_time:descending'},`Frontends = ${quote(frontend)}`);
}
export function logsLink(appCode:string|undefined,timeframe:string,serviceId?:string){
  const origin=tenantOrigin();if(!origin||(!appCode&&!serviceId))return undefined;
  const filterFieldQuery=serviceId?`dt.entity.service = ${quote(serviceId)}`:`APP = ${quote(appCode!)}`;
  return `${origin}/ui/apps/dynatrace.logs/#${encodeURIComponent(JSON.stringify({version:2,'dt.timeframe':{from:`now()-${timeframe}`,to:'now()'},tableConfig:{columns:['timestamp','status','Log message']},analysisMode:'logs',showDqlEditor:false,filterFieldQuery}))}`;
}
export function openInvestigation(url:string|undefined){if(url)window.open(url,'_blank','noopener,noreferrer');}
