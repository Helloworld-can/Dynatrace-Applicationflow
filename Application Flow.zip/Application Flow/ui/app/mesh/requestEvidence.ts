import { DqlRecord, dqlString, runDql } from '../hooks/query';
import { minutes } from './model';

type Execute = typeof runDql;

export function requestEvidenceQuery(sources: string[], targets: string[], window: string, lookupWindow = window): string {
  if (!sources.length || !targets.length) throw new Error('Service scope must not be empty');
  const scope = (ids: string[]) => ids.map(dqlString).join(',');
  const fetch = `fetch spans, timeframe: ${dqlString(window)}`;
  const [lookupFrom,lookupTo]=lookupWindow.split('/');
  return `${fetch}
| filter span.kind == "server" AND isNotNull(trace.id) AND isNotNull(span.parent_id)
| fieldsAdd target_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))
| filter in(target_id, {${scope(targets)}})
| fields target_id,duration,failed=coalesce(request.is_failed == true,false) OR coalesce(lower(span.status_code) == "error",false),succeeded=coalesce(request.is_failed == false,false) OR coalesce(lower(span.status_code) == "ok",false),parent_key=concat(toString(trace.id),":",toString(span.parent_id))
| lookup [fetch spans, timeframe: ${dqlString(lookupWindow)}
  | filter start_time >= toTimestamp(${dqlString(lookupFrom)}) AND start_time < toTimestamp(${dqlString(lookupTo)})
  | filter span.kind == "client" AND isNull(messaging.system) AND isNotNull(trace.id) AND isNotNull(span.id) AND (isNotNull(http.request.method) OR isNotNull(rpc.system))
  | fieldsAdd source_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))
  | filter in(source_id, {${scope(sources)}})
  | fields parent_key=concat(toString(trace.id),":",toString(span.id)),source_id
  | dedup parent_key,source_id
], sourceField:parent_key, lookupField:parent_key, fields:{source_id}
| fields source_id,target_id,duration,failed,succeeded
| filter isNotNull(source_id) AND isNotNull(target_id)
| summarize requests=count(),errors=countIf(failed),successes=countIf(succeeded AND NOT failed),duration_sum_ms=sum(duration)/1ms,duration_samples=countIf(isNotNull(duration)), by:{source_id,target_id}
| limit 10000`;
}

// Partition CLIENT lookup observations into disjoint intervals. Keep the SERVER window
// unchanged so a child starting after a partition boundary can still match its parent.
async function collectRequestEvidence(
  serviceIds: string[], timeframe: string,
  cancelled: () => boolean, publish: (rows: DqlRecord[]) => void,
  execute: Execute = runDql,
): Promise<string[]> {
  const ids=[...new Set(serviceIds)].sort();
  if(ids.length<2)return [];
  const end=Date.now(),from=end-minutes(timeframe)*60000;
  const window=`${new Date(from).toISOString()}/${new Date(end).toISOString()}`;
  type Task={ids:string[];from:number;to:number};
  const pending:Task[]=[];
  for(let i=0;i<ids.length;i+=20)pending.push({ids:ids.slice(i,i+20),from,to:end});
  const rows:DqlRecord[]=[],failed=new Set<string>(),reasons=new Set<string>();
  let attempts=0,halt=false;
  const emit=(finished=false)=>publish(rows.map(row=>({...row,coverage_complete:finished&&!failed.has(String(row.source_id))})));
  const worker=async()=>{
    while(pending.length&&!cancelled()&&!halt){
      if(attempts>=64||Date.now()-end>=120000){
        pending.splice(0).forEach(task=>task.ids.forEach(id=>failed.add(id)));
        reasons.add('enrichment work budget reached');break;
      }
      const task=pending.shift()!;attempts++;
      try{
        const notices:string[]=[];
        const lookupWindow=`${new Date(task.from).toISOString()}/${new Date(task.to).toISOString()}`;
        const result=await execute(requestEvidenceQuery(task.ids,ids,window,lookupWindow),timeframe,n=>notices.push(n));
        if(cancelled())return;
        if(notices.length)throw new Error(notices.join(' '));
        if(result.length>=10000)throw new Error('EVIDENCE_ROW_CAP');
        rows.push(...result);emit();
      }catch(error){
        if(cancelled())return;
        const message=error instanceof Error?error.message:'Query failed';
        const oversized=/LOOKUP_COMMAND_TABLE_SIZE|EVIDENCE_ROW_CAP|lookup[\s\S]*?(?:read too much data|size limit|too large)/i.test(message);
        if(oversized&&task.ids.length>1){
          const middle=Math.ceil(task.ids.length/2);
          pending.unshift({...task,ids:task.ids.slice(0,middle)},{...task,ids:task.ids.slice(middle)});
        }else if(oversized&&task.to-task.from>60000){
          const middle=Math.floor((task.from+task.to)/2);
          pending.unshift({...task,to:middle},{...task,from:middle});
        }else{
          task.ids.forEach(id=>failed.add(id));
          reasons.add(oversized?'Lookup/result limit still exceeded at minimum partition':message.split(/queryString|query:/i)[0].slice(0,240));
          if(!oversized){halt=true;pending.splice(0).forEach(item=>item.ids.forEach(id=>failed.add(id)));}
        }
      }
    }
  };
  await Promise.all([worker(),worker()]);
  if(!cancelled())emit(true);
  return failed.size?[`Request/response metrics query incomplete for ${failed.size} source services: ${[...reasons].join('; ')}. Completed observations are partial; missing metrics are not zero.`]:[];
}

/** A wall-clock deadline also covers a pending execute/poll request. */
export async function loadRequestEvidence(
  serviceIds:string[],timeframe:string,cancelled:()=>boolean,publish:(rows:DqlRecord[])=>void,
  execute:Execute=runDql,timeoutMs=120000,
):Promise<string[]> {
  const controller=new AbortController();
  let expired=false;
  let timer:ReturnType<typeof setTimeout>|undefined;
  const stopped=()=>expired||cancelled();
  const deadline=new Promise<string[]>(resolve=>{
    timer=setTimeout(()=>{
      expired=true;
      controller.abort();
      resolve(['Some connection metrics are unavailable: request/response enrichment reached its time limit. Completed results and the application flow are preserved. Refresh to retry.']);
    },timeoutMs);
  });
  try{
    return await Promise.race([
      collectRequestEvidence(serviceIds,timeframe,stopped,rows=>{if(!stopped())publish(rows);},
        (query,window,onWarning)=>execute(query,window,onWarning,controller.signal)),
      deadline,
    ]);
  }finally{
    if(timer!==undefined)clearTimeout(timer);
    controller.abort();
  }
}
