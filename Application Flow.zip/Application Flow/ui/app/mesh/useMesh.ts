import {loadMessagingEvidence} from './messagingEvidence';
import { loadRequestEvidence } from './requestEvidence';
import { addConnectionEvidence } from './connectionEvidence';
import { useEffect, useMemo, useState } from 'react';
import { runDql, DqlRecord } from '../hooks/query';
import { aggregateAppSignals } from './appSignals';
import { applicationInventory, buildMesh, inventory, ServiceOwner } from './model';

export function useMesh(environment: string, timeframe: string, revision: number, overviewActive=true) {
  const [applicationServices,setApplicationServices] = useState<ServiceOwner[]>([]);
  const [services, setServices] = useState<ServiceOwner[]>([]);
  const [relationships, setRelationships] = useState<DqlRecord[]>([]);
  const [messaging,setMessaging]=useState<DqlRecord[]>([]);
  const [requests,setRequests]=useState<DqlRecord[]>([]);
  const [excluded, setExcluded] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError(null); setRelationships([]); setWarnings([]);setMessaging([]);setRequests([]);
    void (async () => {
      try {
        const notices: string[] = [];
        const notify = (message: string) => { notices.push(message); };
        const [entities, calls] = await Promise.all([
          runDql('fetch dt.entity.service | fields id=toString(id), name=entity.name, tags | limit 50000', timeframe, notify).then(rows=>{if(!cancelled){const owned=inventory(rows);setServices(owned.services);setApplicationServices(applicationInventory(rows));setExcluded(owned.excluded);}return rows;}),
          runDql('smartscapeEdges "calls" | filter source_type == "SERVICE" AND target_type == "SERVICE" | fields source_id=toString(source_id), target_id=toString(target_id) | dedup source_id, target_id | limit 100000', timeframe, notify),
        ]);
        if (cancelled) return;
        const owned = inventory(entities);
        setServices(owned.services); setApplicationServices(applicationInventory(entities)); setExcluded(owned.excluded); setRelationships(calls);
        const baseWarnings = [
          ...new Set(notices),
          ...(entities.length >= 50000 ? ['Service inventory reached the 50,000-row cap; overview may be incomplete.'] : []),
          ...(calls.length >= 100000 ? ['Relationships reached the 100,000-row cap; overview may be incomplete.'] : []),
        ];
        setWarnings([...baseWarnings, 'Loading request/response and messaging evidence for the selected environment…']);
        setLoading(false);
        const eligible = buildMesh(owned.services, calls, environment).apps.flatMap(app => app.services.map(service => service.id));
        const [requestWarnings,messagingWarnings] = await Promise.all([
          loadRequestEvidence(eligible, timeframe, () => cancelled, rows => {
            if (!cancelled) setRequests(rows);
          }),
          loadMessagingEvidence(eligible,timeframe,()=>cancelled,rows=>{
            if(!cancelled)setMessaging(rows);
          }),
        ]);
        if (!cancelled) setWarnings([...baseWarnings, ...requestWarnings, ...messagingWarnings]);
      } catch (caught) {
        if (!cancelled) setError(caught instanceof Error ? caught.message : 'Unable to retrieve application connections.');
      } finally { if (!cancelled) setLoading(false); }
    })();
    return () => { cancelled = true; };
  }, [environment, timeframe, revision]);
  const [signalState, setSignalState] = useState<{timeframe:string; rows:DqlRecord[]; updatedAt?:number; refreshing:boolean; warning?:string}>({timeframe,rows:[],refreshing:true});
  useEffect(() => {
    if(!overviewActive)return;
    let cancelled=false;
    let timer:ReturnType<typeof setTimeout> | undefined;
    const refresh=async () => {
      if(cancelled)return;
      // Invalidate old colour immediately; a failed refresh must not leave a green ring.
      setSignalState({timeframe,rows:[],refreshing:true});
      try {
        const notices:string[]=[];
        const rows=await runDql(`fetch spans
| filter span.kind == "server" OR span.kind == "consumer"
| fieldsAdd service_id=coalesce(toString(dt.entity.service), toString(dt.smartscape.service))
| filter isNotNull(service_id)
| fieldsAdd failed=request.is_failed == true OR lower(span.status_code) == "error", recent=start_time >= now()-5m
| summarize requests=count(), errors=countIf(failed), latency_ms=avg(duration)/1ms,
    recent_requests=countIf(recent), recent_errors=countIf(recent AND failed),
    recent_latency_ms=avg(if(recent,duration))/1ms, by:{service_id}
| limit 50000`,timeframe,message=>notices.push(message));
        if(rows.length>=50000)notices.push('Metric results reached the 50,000-service limit.');
        if(!cancelled)setSignalState({timeframe,rows:notices.length?[]:rows,updatedAt:Date.now(),refreshing:false,warning:notices.join(' ')||undefined});
      } catch(caught){
        if(!cancelled)setSignalState({timeframe,rows:[],refreshing:false,warning:caught instanceof Error?caught.message:'Application metrics could not be refreshed.'});
      } finally {
        // Schedule after completion: queries never overlap within this poller.
        if(!cancelled)timer=setTimeout(()=>{void refresh();},60000);
      }
    };
    void refresh();
    return()=>{cancelled=true;if(timer)clearTimeout(timer);};
  },[timeframe,revision,overviewActive]);
  const topology = useMemo(() => {
    const base=addConnectionEvidence(buildMesh(services,relationships,environment,excluded),messaging,requests,timeframe,environment);
    const present=new Set(base.apps.map(app=>app.id));
    for(const member of applicationServices){
      const eligible=environment==='ALL'||member.environments.includes(environment)||(environment==='__UNTAGGED__'&&member.environments.length===0);
      if(present.has(member.app)||(!eligible&&member.environments.length>0))continue;
      base.apps.push({id:member.app,services:[],scopeNote:eligible?'Ownership ambiguous — inspect APP tags':'ENV tag missing — scope unverified'});present.add(member.app);
    }
    // Environment warnings belong to contributing service pairs, not every edge of an app.
    // buildMesh and addConnectionEvidence annotate those individual connections.
    return base;
  },[services,relationships,environment,excluded,messaging,requests,timeframe,applicationServices]);
  const mesh = useMemo(() => {
    const current=signalState.timeframe===timeframe;
    const metrics=aggregateAppSignals(topology.apps,current?signalState.rows:[],timeframe);
    return {...topology,connectionMetricsIncomplete:warnings.some(note=>/request|connection metrics/i.test(note)),apps:topology.apps.map(app=>({...app,signals:metrics.get(app.id)})),
      metricsUpdatedAt:current?signalState.updatedAt:undefined,metricsRefreshing:!current||signalState.refreshing,
      metricsWarning:current?signalState.warning:undefined};
  },[topology,signalState,timeframe,warnings]);
  const environments = useMemo(() => [...new Set(services.flatMap(service => service.environments))].sort(), [services]);
  return { mesh, services, applicationServices, environments, loading, error, warnings };
}
