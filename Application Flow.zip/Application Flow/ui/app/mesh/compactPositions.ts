/** Balanced rings around the selected/highest-degree node. Positions never change connectivity. */
export function compactPositions(ids:string[],links:{source:string;target:string}[],preferred?:string){
  const allowed=new Set(ids),degree=new Map(ids.map(id=>[id,0]));
  for(const e of links)if(allowed.has(e.source)&&allowed.has(e.target)){degree.set(e.source,(degree.get(e.source)??0)+1);degree.set(e.target,(degree.get(e.target)??0)+1);}
  const ordered=[...ids].sort((a,b)=>(degree.get(b)??0)-(degree.get(a)??0)||a.localeCompare(b));
  const centre=preferred&&allowed.has(preferred)?preferred:ordered[0];
  const positions=new Map<string,{x:number;y:number}>();if(!centre)return positions;
  positions.set(centre,{x:0,y:0});
  const neighbours=new Set(links.flatMap(e=>e.source===centre?[e.target]:e.target===centre?[e.source]:[]));
  const rest=ordered.filter(id=>id!==centre).sort((a,b)=>Number(neighbours.has(b))-Number(neighbours.has(a)));
  let offset=0,ring=1;
  while(offset<rest.length){const count=Math.min(ring*6,rest.length-offset),radius=ring*330;
    for(let i=0;i<count;i++){const angle=2*Math.PI*i/count-Math.PI/2+(ring%2?0:Math.PI/count);positions.set(rest[offset+i],{x:Math.cos(angle)*radius*1.25,y:Math.sin(angle)*radius});}
    offset+=count;ring++;
  }
  return positions;
}
