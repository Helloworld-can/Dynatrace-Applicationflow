import { DqlRecord, asString } from '../hooks/query';
import { TopologyEdge, TopologyNode } from '../types/observability';

// A queue name is unique only within a broker. Missing broker identity must not
// merge unrelated destinations or imply a producer-to-consumer relationship.
export function messagingFlow(rows:DqlRecord[],visible:Set<string>,windowMinutes:number) {
  const nodes=new Map<string,TopologyNode>();
  const edges:TopologyEdge[]=[];
  for(const row of rows){
    const service=asString(row.service_id),destination=asString(row.destination);
    if(!visible.has(service)||!destination)continue;
    const kind=asString(row.kind).toLowerCase(),operation=asString(row.operation).toLowerCase();
    const publish=kind==='producer'||operation==='publish'||operation==='send';
    const consume=kind==='consumer'||['process','receive','peek'].includes(operation);
    if(publish===consume)continue;
    const system=asString(row.system),manager=asString(row.manager),address=asString(row.address),port=asString(row.port);
    const broker=manager?['manager',manager]:address?['address',address,port]:['unresolved',service];
    const id=`queue:${JSON.stringify([system,...broker,destination])}`;
    const calls=Number(row.calls),errors=Number(row.errors),latency=Number(row.latency_ms);
    const valid=calls>0&&Number.isFinite(errors)&&Number.isFinite(latency);
    const errorRate=valid?100*errors/calls:undefined;
    const health=!valid?'unknown':errorRate!>=5||latency>=1500?'critical':errorRate!>=1||latency>=700?'warning':'healthy';
    const node=nodes.get(id);
    if(!node)nodes.set(id,{id,label:destination,kind:'messaging',health,
      details:[`Messaging system: ${system||'Unknown'}`,`Destination: ${destination}`,`Broker: ${manager||address||'Unknown — not correlated across services'}`,'Health reflects observed messaging operations, not queue depth or message age.','Producer and consumer observations do not establish individual message delivery.']});
    else {const rank={unknown:0,healthy:1,warning:2,critical:3};if(rank[health]>rank[node.health])node.health=health;}
    edges.push({id:`${id}:${service}:${operation||kind}`,source:publish?service:id,target:publish?id:service,health,
      calls:valid?calls:undefined,latencyMs:valid?latency:undefined,errorRate,
      interaction:'messaging',operation:operation||(publish?'publish':'consume'),ratePerMinute:valid?calls/windowMinutes:undefined});
  }
  return {nodes:[...nodes.values()],edges};
}
