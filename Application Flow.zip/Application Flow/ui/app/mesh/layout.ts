import { AppConnection } from './model';

// Collapse call cycles, then place the resulting dependency DAG in columns.
export function dependencyPositions(ids: string[], connections: AppConnection[]) {
  const allowed = new Set(ids);
  const adjacency = new Map(ids.map(id => [id, [] as string[]]));
  connections.forEach(({source,target}) => { if (allowed.has(source) && allowed.has(target)) adjacency.get(source)?.push(target); });
  const index = new Map<string,number>(), low = new Map<string,number>();
  const stack: string[] = [], stacked = new Set<string>(), groups: string[][] = [];
  let sequence = 0;
  function visit(id:string) {
    index.set(id,sequence); low.set(id,sequence++); stack.push(id); stacked.add(id);
    for (const next of adjacency.get(id) ?? []) {
      if (!index.has(next)) { visit(next); low.set(id,Math.min(low.get(id)!,low.get(next)!)); }
      else if (stacked.has(next)) low.set(id,Math.min(low.get(id)!,index.get(next)!));
    }
    if (low.get(id) === index.get(id)) {
      const group:string[]=[];
      let member:string;
      do { member=stack.pop()!; stacked.delete(member); group.push(member); } while(member!==id);
      groups.push(group.sort());
    }
  }
  [...ids].sort().forEach(id=>{if(!index.has(id)) visit(id);});
  const owner=new Map<string,number>(); groups.forEach((group,i)=>group.forEach(id=>owner.set(id,i)));
  const outgoing=groups.map(()=>new Set<number>()), degree=groups.map(()=>0), rank=groups.map(()=>0);
  connections.forEach(({source,target})=>{
    const a=owner.get(source),b=owner.get(target);
    if(a!==undefined && b!==undefined && a!==b && !outgoing[a].has(b)){outgoing[a].add(b);degree[b]++;}
  });
  const queue=degree.flatMap((n,i)=>n===0?[i]:[]);
  for(let cursor=0;cursor<queue.length;cursor++) for(const next of outgoing[queue[cursor]]) {
    rank[next]=Math.max(rank[next],rank[queue[cursor]]+1);
    if(--degree[next]===0) queue.push(next);
  }
  const linked=new Set(connections.flatMap(e=>[e.source,e.target]));
  const columns=new Map<number,string[]>();
  groups.forEach((group,i)=>{const members=group.filter(id=>linked.has(id));if(members.length) columns.set(rank[i],[...(columns.get(rank[i])??[]),...members]);});
  const positions=new Map<string,{x:number;y:number}>();
  const height=Math.max(1,...[...columns.values()].map(col=>col.length))*280;
  columns.forEach((column,col)=>column.forEach((id,row)=>positions.set(id,{x:col*390,y:row*280+(height-column.length*280)/2})));
  const isolated=ids.filter(id=>!linked.has(id)).sort();
  isolated.forEach((id,i)=>positions.set(id,{x:(i%5)*280,y:height+180+Math.floor(i/5)*280}));
  return positions;
}
