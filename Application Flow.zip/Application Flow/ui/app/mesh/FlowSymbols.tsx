import React from 'react';

/** Symbol outlines remain black; only the centre light carries observed health. */
export function FlowSymbol({kind,color}:{kind:'database'|'rum';color:string}) {
  const database=kind==='database';
  return <svg role="img" aria-label={database?'Database with observed health light':'Web and mobile client interaction'} viewBox="0 0 112 112" width="112" height="112">
    <title>{database?'Database — light shows observed call health, not extension connection status':'Web/mobile real user monitoring'}</title>
    {database ? <g transform="translate(21 13) scale(.625)" fill="#fff" stroke="#111" strokeWidth="4" strokeLinejoin="round">
      <path d="M8 23v65c0 20 96 20 96 0V23"/>
      <ellipse cx="56" cy="23" rx="48" ry="16"/>
      <path d="M8 55c0 21 96 21 96 0M8 78c0 21 96 21 96 0" fill="none"/>
      <circle cx="56" cy="48" r="10" fill={color} stroke="#fff" strokeWidth="3"/>
    </g> : <g fill="#fff" stroke="#111" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <rect x="8" y="12" width="73" height="51" rx="5"/>
      <path d="M9 24h71M35 64v12m-13 1h39" fill="none"/>
      <circle cx="17" cy="18" r="1" fill="#111" stroke="none"/>
      <circle cx="23" cy="18" r="1" fill="#111" stroke="none"/>
      <circle cx="37" cy="37" r="7"/>
      <path d="M23 56c1-13 27-13 28 0" fill="none"/>
      <rect x="73" y="34" width="29" height="49" rx="5"/>
      <path d="M82 40h10M84 77h7" fill="none"/>
      <path d="m56 45 1 23 6-7 8-1Z" fill="#111" strokeWidth="1"/>
      <circle cx="56" cy="88" r="6" fill={color} stroke="#fff" strokeWidth="2"/>
    </g>}
  </svg>;
}
