import {DqlRecord,asString} from '../hooks/query';
import {ApplicationMesh,AppConnection,minutes} from './model';
export function addConnectionEvidence(mesh:ApplicationMesh,messaging:DqlRecord[],requests:DqlRecord[],timeframe = '15m',environment = 'ALL'):ApplicationMesh {
  const owners=new Map(mesh.apps.flatMap(app=>app.services.map(service=>[service.id,service] as const)));
  const edges=new Map<string,AppConnection>(mesh.connections.map(edge=>[edge.id,{...edge,queues:[] as string[],requestResponse:false}]));
  const connection=(source:string,target:string):AppConnection|undefined=>{
    if(source===target)return;
    const id=JSON.stringify([source,target]);
    let edge=edges.get(id);if(!edge){edge={id,source,target,servicePairs:0,queues:[],requestResponse:false};edges.set(id,edge);}return edge;
  };
  const number=(value:unknown):number|undefined=>typeof value==='number'&&Number.isFinite(value)&&value>=0?value:typeof value==='string'&&value.trim()!==''&&Number.isFinite(Number(value))&&Number(value)>=0?Number(value):undefined;
  for(const row of requests){
    const source=owners.get(asString(row.source_id)),target=owners.get(asString(row.target_id));
    if(!source||!target)continue;
    const edge=connection(source.app,target.app);if(!edge)continue;
    edge.requestResponse=true;
    if(environment!=='ALL'&&environment!=='__UNTAGGED__'&&(!source.environments.length||!target.environments.length))edge.scopeUnverified=true;
    const count=number(row.requests),errors=number(row.errors),sum=number(row.duration_sum_ms),samples=number(row.duration_samples);
    if(count===undefined||count<=0||errors===undefined||samples===undefined||(samples>0&&sum===undefined))continue;
    const successes=number(row.successes)??0;
    if(errors+successes>count)continue;
    const previous=edge.metrics;
    const total=(previous?.requests??0)+count,failed=(previous?.errors??0)+errors;
    const durationSum=(previous?.durationSumMs??0)+(sum??0),durationSamples=(previous?.durationSamples??0)+samples;
    edge.metrics={incomplete:previous?.incomplete===true||row.coverage_complete===false,requests:total,errors:failed,successes:(previous?.successes??0)+successes,unknown:(previous?.unknown??0)+count-errors-successes,durationSumMs:durationSum,durationSamples,
      requestsPerMinute:total/minutes(timeframe),responseMs:durationSamples?durationSum/durationSamples:undefined,errorRate:100*failed/total};
  }
  const destinations=new Map<string,{label:string;publish:Set<string>;consume:Set<string>}>();
  for(const row of messaging){
    const owner=owners.get(asString(row.service_id));if(!owner)continue;
    const destination=asString(row.destination),manager=asString(row.manager),address=asString(row.address),system=asString(row.system);
    if(!destination||(!manager&&!address))continue;
    const broker=manager?`manager:${manager}`:`address:${address}:${asString(row.port)}`;
    const environment=owner.environments.length?[...owner.environments].sort().join(','):`unknown:${owner.id}`;
    const key=JSON.stringify([system,broker,destination,environment]);
    const group=destinations.get(key)??{label:`${destination} (${system||'messaging'} · ${manager||address})`,publish:new Set<string>(),consume:new Set<string>()};
    const kind=asString(row.kind).toLowerCase(),operation=asString(row.operation).toLowerCase();
    const publish=kind==='producer'||['publish','send'].includes(operation),consume=kind==='consumer'||['receive','process','peek'].includes(operation);
    if(publish&&!consume)group.publish.add(owner.app);if(consume&&!publish)group.consume.add(owner.app);destinations.set(key,group);
  }
  for(const group of destinations.values())for(const source of group.publish)for(const target of group.consume){const edge=connection(source,target);if(edge&&!edge.queues?.includes(group.label))edge.queues?.push(group.label);}
  return {...mesh,connections:[...edges.values()]};
}
export function connectionLabel(edge:AppConnection){
  const queue=edge.queues?.length===1?edge.queues[0]:`${edge.queues?.length??0} queues/topics`;
  return [edge.requestResponse?'Request/response':undefined,edge.queues?.length?`Async · ${queue}`:undefined].filter(Boolean).join(' + ')||'Type unknown';
}

export function connectionMetricLines(edge:AppConnection):string[] {
  if(!edge.metrics)return [];
  const format=(value:number|undefined)=>value===undefined?'—':value.toLocaleString(undefined,{maximumFractionDigits:1});
  return [`${format(edge.metrics.requestsPerMinute)} observed calls/min, ${format(edge.metrics.responseMs)} ms`,
    `${format(edge.metrics.successes)} successful · ${format(edge.metrics.errors)} failed · ${format(edge.metrics.unknown)} unknown`,
    `${format(edge.metrics.errorRate)}% of observed calls flagged failed`,
    ...(edge.metrics.incomplete?['Metrics query incomplete — partial observations']:[]),
    ...(edge.queues?.length?['HTTP/RPC metrics']:[])];
}
