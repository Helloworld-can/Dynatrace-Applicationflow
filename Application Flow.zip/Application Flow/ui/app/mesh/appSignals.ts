import { asString, DqlRecord } from '../hooks/query';
import { AppNode, minutes } from './model';
export type AppHealth = 'healthy' | 'warning' | 'critical' | 'unknown';
export interface AppSignals { requestsPerMinute?:number; latencyMs?:number; errorRate?:number; health:AppHealth; reportingServices:number }
const n = (value:unknown):number|undefined => value === null || value === undefined || !Number.isFinite(Number(value)) ? undefined : Number(value);
export function classifyHealth(requests:number, errors?:number, latency?:number):AppHealth {
  if (!requests || errors === undefined || latency === undefined) return 'unknown';
  const rate=100*errors/requests;
  return rate>=5 || latency>=1500 ? 'critical' : rate>=1 || latency>=700 ? 'warning' : 'healthy';
}
export function aggregateAppSignals(apps:AppNode[], rows:DqlRecord[], timeframe:string):Map<string,AppSignals> {
  const byService=new Map(rows.map(row=>[asString(row.service_id),row]));
  const result=new Map<string,AppSignals>();
  for(const app of apps){
    let requests=0, errors=0, weightedLatency=0, latencyRequests=0, reportingServices=0;
    let health:AppHealth='unknown';
    for(const service of app.services){
      const row=byService.get(service.id); if(!row) continue;
      const count=n(row.requests)??0, latency=n(row.latency_ms);
      requests+=count; errors+=n(row.errors)??0;
      if(latency!==undefined){weightedLatency+=count*latency;latencyRequests+=count;}
      const recent=n(row.recent_requests)??0;
      const serviceHealth=classifyHealth(recent,n(row.recent_errors),n(row.recent_latency_ms));
      if(serviceHealth!=='unknown')reportingServices++;
      if(serviceHealth==='critical' || (serviceHealth==='warning' && health!=='critical') || (serviceHealth==='healthy' && health==='unknown'))health=serviceHealth;
    }
    result.set(app.id,{requestsPerMinute:requests>0?requests/minutes(timeframe):undefined,
      latencyMs:latencyRequests>0?weightedLatency/latencyRequests:undefined,errorRate:requests>0?100*errors/requests:undefined,health,reportingServices});
  }
  return result;
}
