import {aggregateEdges} from './edgeMetrics';
import {TopologyModel,TopologyNode} from '../types/observability';

/** Presentation only: never changes discovery, ownership, or the source model. */
export function compactTopology(model:TopologyModel,appCode:string,expanded:Set<string>,highLevel=false):TopologyModel {
  const buckets=new Map<string,TopologyNode[]>();
  const owned=new Set(model.coverage?.ownedServices.map(s=>s.id)??[]);
  const sorted=[...model.nodes].sort((a,b)=>a.id.localeCompare(b.id));
  for(const node of sorted){
    const id=node.entityId??node.id;
    const key=id.startsWith('SERVICE-')?(owned.has(id)||node.appCode===appCode?'Application services':node.appCode?`Application ${node.appCode}`:'Other connected services'):node.kind==='database'?'Databases':node.kind==='messaging'?'Queues':node.kind==='external'?'External endpoints':'';
    if(!key)continue;
    const list=buckets.get(key)??[];list.push(node);buckets.set(key,list);
  }
  const mapped=new Map<string,string>(),groups:TopologyNode[]=[];
  for(const [key,list] of buckets){
    const externalApp=key.startsWith('Application ' )&&key!=='Application services';
    if((!highLevel&&!externalApp)||list.length<=1)continue;
    // Stable, explicitly labelled display batches; never infer business tiers from names.
    const size=list.length;
    for(let start=0;start<list.length;start+=size){
      const members=list.slice(start,start+size);if(members.length===1)continue;
      const id=`display-group:${key}:${start/size}`;if(expanded.has(id))continue;
      members.forEach(node=>mapped.set(node.id,id));
      const health=members.some(n=>n.health==='critical')?'critical':members.some(n=>n.health==='warning')?'warning':members.every(n=>n.health==='healthy')?'healthy':'unknown';
      groups.push({id,label:`${key} · ${members.length}`,kind:key==='Application services'||externalApp?'application':members[0].kind,health,services:members.map(n=>({id:n.entityId??n.id,name:n.label})),details:['Display group. Click to open Directional layers or use Focus service. Health is the worst observed member status; request totals are not summed across nodes.']});
    }
  }
  const edges=model.edges.map(e=>({...e,source:mapped.get(e.source)??e.source,target:mapped.get(e.target)??e.target})).filter(e=>e.source!==e.target);
  if(!highLevel)return {...model,nodes:[...model.nodes.filter(n=>!mapped.has(n.id)),...groups],edges};
  return {...model,nodes:[...model.nodes.filter(n=>!mapped.has(n.id)),...groups],edges:aggregateEdges(edges,true)};
}

/** Layout choices affect presentation only; keep discovered idle/DR dependencies in detailed views. */
export function layoutTopology(model:TopologyModel,appCode:string,layout:string,expanded:Set<string>,showUnverified:boolean):TopologyModel {
  const edges=model.edges.filter(edge=>showUnverified||!edge.evidence||edge.evidence==='trace');
  const visible={...model,edges};
  if(layout==='layered')return visible;
  return compactTopology(visible,appCode,layout==='high-level'?new Set():expanded,layout==='high-level');
}
