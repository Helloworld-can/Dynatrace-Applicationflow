import {loadRequestEvidence} from './requestEvidence';
import {minutes} from './model';
import {asString,dqlString,DqlRecord,runDql} from '../hooks/query';
import {TopologyModel,TopologyEdge,TopologyNode} from '../types/observability';

export function reconcileTraceTopology(model:TopologyModel,rows:DqlRecord[],notes:string[]):TopologyModel {
  const text=(r:DqlRecord,k:string)=>asString(r[k]);
  const key=(trace:string,span:string)=>JSON.stringify([trace,span]);
  const index=new Map<string,DqlRecord>(),ambiguous=new Set<string>();
  for(const row of rows){const k=key(text(row,'trace_id'),text(row,'span_id'));if(!text(row,'trace_id')||!text(row,'span_id'))continue;const old=index.get(k);if(old&&JSON.stringify(old)!==JSON.stringify(row))ambiguous.add(k);else index.set(k,row);}
  const scope=new Set(model.nodes.map(n=>n.entityId??n.id));
  const pairs=new Map<string,TopologyEdge>();const matchedClients=new Set<string>();let missing=0,conflicts=0;
  for(const server of index.values()){
    if(text(server,'kind')!=='server'||ambiguous.has(key(text(server,'trace_id'),text(server,'span_id'))))continue;
    const target=text(server,'service_id'),trace=text(server,'trace_id');if(!target)continue;
    let parent=text(server,'parent_id');const visited=new Set<string>();let client:DqlRecord|undefined;
    // Only walk a contiguous chain of INTERNAL spans. Never skip another server boundary.
    while(parent){const k=key(trace,parent);if(visited.has(k)||ambiguous.has(k)){conflicts++;break;}visited.add(k);const row=index.get(k);if(!row){missing++;break;}const kind=text(row,'kind');if(kind==='client'){client=row;break;}if(kind!=='internal'||(text(row,'service_id')&&text(row,'service_id')!==target)){conflicts++;break;}parent=text(row,'parent_id');}
    if(!client)continue;
    // Determine execution context from the nearest contiguous SERVER ancestor.
    let source='';parent=text(client,'parent_id');visited.clear();
    while(parent){const k=key(trace,parent);if(visited.has(k)||ambiguous.has(k)){source='';conflicts++;break;}visited.add(k);const row=index.get(k);if(!row){missing++;break;}const kind=text(row,'kind');if(kind==='server'){source=text(row,'service_id');break;}if(kind!=='internal'||(text(row,'service_id')&&text(row,'service_id')!==text(client,'service_id'))){conflicts++;break;}parent=text(row,'parent_id');}
    if(source&&source!==text(client,'service_id')){conflicts++;continue;}
    if(!source||source===target||(!scope.has(source)&&!scope.has(target)))continue;
    matchedClients.add(key(trace,text(client,'span_id')));
    const id=key(source,target);const edge=pairs.get(id)??{id:`trace:${id}`,source,target,health:'unknown',evidence:'trace' as const,sampleCalls:0};edge.sampleCalls=(edge.sampleCalls??0)+1;pairs.set(id,edge);
  }
  const nodes:TopologyNode[]=model.nodes.map(n=>({...n}));
  for(const edge of pairs.values())for(const id of [edge.source,edge.target])if(!nodes.some(n=>n.id===id))nodes.push({id,entityId:id,label:id,kind:'component',health:'unknown',details:['Service discovered through correlated trace parent/child spans. APP ownership has not been inferred.']});
  let unresolved=0;const unresolvedNodes=new Map<string,TopologyNode>();const unresolvedEdges=new Map<string,TopologyEdge>();
  for(const row of index.values()){
    if(text(row,'kind')!=='client'||matchedClients.has(key(text(row,'trace_id'),text(row,'span_id')))||!scope.has(text(row,'service_id')))continue;
    if(text(row,'db_system')||text(row,'messaging_system'))continue;
    const host=text(row,'host');if(!host)continue;
    unresolved++;
    const source=text(row,'service_id'),port=text(row,'port'),id=`unresolved:${JSON.stringify([source,host,port])}`;
    unresolvedNodes.set(id,{id,label:`${host}${port?`:${port}`:''}`,kind:'external',health:'unknown',networkRole:'external',details:['Unresolved client-span destination. No correlated server span in the loaded trace sample. This is not a confirmed direct service call.',`Attributed service: ${source}`]});
    const previous=unresolvedEdges.get(id);unresolvedEdges.set(id,{id,source,target:id,health:'unknown',evidence:'unresolved',sampleCalls:(previous?.sampleCalls??0)+1});
  }
  // Do not promote full-window destination aggregates to direct service calls.
  // Replace their display with bounded, explicitly labelled trace evidence.
  const removed=new Set<string>(); // Retain discovery even when recent trace sampling misses a path.
  const edges:TopologyEdge[]=model.edges.filter(e=>!removed.has(e.source)&&!removed.has(e.target)).map(e=>{
    if(e.source.startsWith('SERVICE-')&&e.target.startsWith('SERVICE-'))return {...e,evidence:'smartscape' as const,calls:undefined,ratePerMinute:undefined,latencyMs:undefined,errorRate:undefined,requestOutcomes:undefined};
    if(e.target.startsWith('external:'))return {...e,evidence:'unresolved' as const};
    return e;
  }).filter(e=>!pairs.has(key(e.source,e.target)));
  const quality=[...notes,'Discovered relationships remain visible by default. Dashed links are not validated by the loaded trace sample. A node without a loaded outgoing link is not proof that a transaction ends there.',`Trace validation: ${new Set(rows.map(r=>text(r,'trace_id'))).size} sampled traces; ${pairs.size} confirmed service pairs; ${unresolved} unresolved client spans; ${missing} missing parent links; ${conflicts} ambiguous/cyclic links. Sample counts are not full-timeframe rates. Absence from this sample does not disprove a Smartscape relationship.`];
  const allEdges=[...edges,...pairs.values(),...unresolvedEdges.values()];
  for(const node of nodes){if((node.entityId??node.id).startsWith('SERVICE-')&&!allEdges.some(edge=>edge.source===node.id))node.details=[...(node.details??[]),'Downstream coverage unresolved','No outgoing relationship resolved in loaded evidence. This does not establish a transaction endpoint.'];}
  return {...model,nodes:[...nodes.filter(n=>!removed.has(n.id)),...unresolvedNodes.values()],edges:[...edges,...pairs.values(),...unresolvedEdges.values()],topologyQuality:quality};
}

export async function validateTraceTopology(model:TopologyModel,ids:string[],timeframe:string,cancelled:()=>boolean):Promise<TopologyModel>{
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),60000);const notes:string[]=[];const rows:DqlRecord[]=[];
  const execute=(q:string)=>runDql(q,timeframe,m=>notes.push(m),controller.signal);
  try{
    const seed=await execute(`fetch spans
| filter in(coalesce(toString(dt.entity.service),toString(dt.smartscape.service)),{${ids.map(dqlString).join(',')}})
| filter isNotNull(trace.id)
| summarize latest=max(start_time), by:{trace_id=toString(trace.id)}
| sort latest desc
| limit 101`);
    const traces=seed.slice(0,100).map(r=>asString(r.trace_id)).filter(Boolean);
    notes.push('Bounded validation of up to 100 recent traces in the selected timeframe; this is not an exhaustive architecture map.');
    for(let i=0;i<traces.length&&!cancelled();i+=10){
      const before=notes.length;
      const batch=await execute(`fetch spans
| filter in(toString(trace.id),{${traces.slice(i,i+10).map(dqlString).join(',')}})
| fields trace_id=toString(trace.id),span_id=toString(span.id),parent_id=toString(span.parent_id),kind=span.kind,service_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service)),host=server.address,port=toString(server.port),db_system=coalesce(db.system,db.system.name),messaging_system=messaging.system
| limit 10000`);
      if(batch.length>=10000||notes.length>before){notes.push('A capped or warned trace batch was omitted from validation.');continue;}rows.push(...batch);
    }
  }catch(error){notes.push(`Trace validation incomplete: ${error instanceof Error?error.message:'query failed'}`);}finally{clearTimeout(timer);}
  const result=reconcileTraceTopology(model,rows,notes);
  // Resolve new entity labels by ID only, never match service names to destinations.
  const unknown=result.nodes.filter(n=>n.label===n.id&&n.id.startsWith('SERVICE-'));
  if(unknown.length&&!cancelled())try{const names=await runDql(`fetch dt.entity.service | filter in(toString(id),{${unknown.map(n=>dqlString(n.id)).join(',')}}) | fields service_id=toString(id),name=entity.name | limit 1000`,timeframe);for(const node of unknown){const found=names.find(r=>asString(r.service_id)===node.id);if(found)node.label=asString(found.name)||node.id;}}catch{/* Keep the explicit entity ID when metadata is unavailable. */}
  const confirmed=result.edges.filter(edge=>edge.evidence==='trace');
  const metricIds=[...new Set(confirmed.flatMap(edge=>[edge.source,edge.target]))];
  let measured:DqlRecord[]=[];
  if(metricIds.length&&!cancelled()){
    const warnings=await loadRequestEvidence(metricIds,timeframe,cancelled,values=>{measured=values;},runDql,45000);
    if(warnings.length)result.topologyQuality?.push('Connection metrics incomplete; completed observations are partial. '+warnings.join(' '));
    for(const edge of confirmed){
      if(warnings.length)edge.metricNote='Metrics query incomplete';
      const matching=measured.filter(row=>asString(row.source_id)===edge.source&&asString(row.target_id)===edge.target);
      if(!matching.length){edge.metricNote=warnings.length?'Metrics query incomplete':'No matching spans in selected timeframe';continue;}
      const calls=matching.reduce((n,row)=>n+Number(row.requests??0),0),errors=matching.reduce((n,row)=>n+Number(row.errors??0),0);
      const samples=matching.reduce((n,row)=>n+Number(row.duration_samples??0),0),duration=matching.reduce((n,row)=>n+Number(row.duration_sum_ms??0),0);
      const successful=matching.reduce((n,row)=>n+Number(row.successes??0),0);
      if(calls>0&&errors+successful<=calls){edge.requestOutcomes={successful,failed:errors,unknown:calls-errors-successful};edge.durationSamples=samples;edge.calls=calls;edge.ratePerMinute=calls/minutes(timeframe);edge.errorRate=100*errors/calls;edge.latencyMs=samples?duration/samples:undefined;}
    }
  }
  return result;
}
