import {asString,dqlString,DqlRecord,runDql} from '../hooks/query';
import {DataResource} from './dataInventory';
export const finite=(value:unknown):number|undefined=>typeof value==='number'&&Number.isFinite(value)?value:undefined;
export const mqIdentity=(manager:string,destination:string)=>JSON.stringify([manager,destination]);
export function queueDepthQuery(items:DataResource[]):string{
 const pairs=[...new Map(items.filter(x=>x.system==='mqseries'&&x.manager&&x.destination).map(x=>[mqIdentity(x.manager,x.destination),x])).values()];
 if(!pairs.length)return '';
 return `timeseries depth=max(ibmmq.queue.depth,scalar:true),by:{actual_qm_name,queue_name},filter: ${pairs.map(x=>`(actual_qm_name == ${dqlString(x.manager)} AND queue_name == ${dqlString(x.destination)})`).join(' OR ')}\n| fields actual_qm_name,queue_name,depth`;
}
export interface CapacityMetric {key:string;label:string;unit:'bytes'|'pages'}
export function capacityMetrics(system:string):CapacityMetric[]{
 if(system.toLowerCase()==='oracle')return [['totalSpace','Capacity'],['usedSpace','Used'],['freeSpace','Free']].map(([key,label])=>({key:`com.dynatrace.extension.sql-oracle.tablespaces.${key}`,label,unit:'bytes'}));
 if(['postgres','postgresql'].includes(system.toLowerCase()))return [{key:'postgres.db_size',label:'Database size',unit:'bytes'},{key:'postgres.tablespace.size',label:'Tablespace size',unit:'bytes'}];
 if(system.toLowerCase()==='db2')return [{key:'db2.tbsp_size',label:'Tablespace capacity',unit:'bytes'},{key:'db2.tbsp_used_pages',label:'Used pages',unit:'pages'},{key:'db2.tbsp_total_pages',label:'Total pages',unit:'pages'}];
 return [];
}
const identifier=(value:string)=>'`'+value.replace(/`/g,'``')+'`';
const hostKeys=['server.address','host','hostname','host.name','host_name','db.host','db.host.name','db.hostname','database.host','endpoint.host'];
const databaseKeys=['db.namespace','db.name','dbname','database','database_name','database.name','db','service_name','serviceName'];
const portKeys=['server.port','port','db.port','database.port'];
const dimensionText=(v:unknown)=>typeof v==='string'?v:typeof v==='number'?String(v):'';
export function capacitySeriesMatch(row:DqlRecord,item:DataResource):boolean{
 const endpoint=['endpoint','db.endpoint','database.endpoint','server.address'].some(key=>dimensionText(row[key]).toLowerCase()===`${item.address}:${item.port}`.toLowerCase()&&Boolean(item.address&&item.port));
 const host=endpoint||hostKeys.some(key=>dimensionText(row[key]).toLowerCase()===item.address.toLowerCase()&&Boolean(item.address));
 const database=databaseKeys.some(key=>dimensionText(row[key])===item.namespace&&Boolean(item.namespace));
 const port=endpoint||portKeys.some(key=>dimensionText(row[key])===item.port&&Boolean(item.port));
 return host&&database&&port;
}
export interface CapacityReading {metric:CapacityMetric;scope:string;value:number|undefined}
export async function loadCapacity(item:DataResource,timeframe:string,onWarning:(m:string)=>void,signal?:AbortSignal):Promise<CapacityReading[]>{
 const metrics=capacityMetrics(item.system);if(!metrics.length)return [];
 // Discover actual dimensions, never guess which database owns a metric series.
 const rows=await runDql(`metrics from:now()-10d, to:now()\n| filter in(metric.key,{${metrics.map(m=>dqlString(m.key)).join(',')}})\n| limit 2000`,'24h',onWarning,signal);
 if(rows.length>=2000)onWarning('Storage metric discovery reached its limit; coverage may be incomplete.');
 const matched=rows.filter(row=>capacitySeriesMatch(row,item));
 if(!matched.length){onWarning('No storage series matched this host, port and database. Enable extension storage metrics or verify the metric dimensions; storage is not inferred from spans.');return [];}
 const entries=[...new Map(matched.map(row=>[JSON.stringify(row),row])).values()];
 if(entries.length>60)onWarning('Showing the first 60 matching storage series; narrow the database scope to inspect more.');
 const readings:CapacityReading[]=[];
 // Small concurrent batches avoid a request burst for databases with many tablespaces.
 for(let i=0;i<Math.min(entries.length,60);i+=4){
  signal?.throwIfAborted();
  const batch=await Promise.all(entries.slice(i,Math.min(i+4,60)).map(async row=>{
   const metric=metrics.find(m=>m.key===asString(row['metric.key']));if(!metric)return undefined;
   const dimensions=Object.entries(row).filter(([key,value])=>key!=='metric.key'&&!key.startsWith('dt.system.')&&(typeof value==='string'||typeof value==='number'||typeof value==='boolean'));
   const filter=dimensions.map(([key,value])=>`${identifier(key)} == ${typeof value==='string'?dqlString(value):String(value)}`).join(' AND ');
   if(!filter)return undefined;
   const scope=dimensions.filter(([key])=>/tablespace|tbsp|member|instance|db.name|dbname|database|namespace/i.test(key)).map(([key,value])=>`${key}: ${dimensionText(value)}`).join(' · ')||item.namespace;
   try{const data=await runDql(`timeseries observed=max(${identifier(metric.key)},scalar:true),filter: ${filter}`,timeframe,onWarning,signal);return {metric,scope,value:finite(data[0]?.observed)};}
   catch{onWarning(`Unable to read ${metric.label.toLowerCase()} metrics.`);return {metric,scope,value:undefined};}
  }));
  readings.push(...batch.filter((x):x is CapacityReading=>x!==undefined));
 }
 return readings;
}
