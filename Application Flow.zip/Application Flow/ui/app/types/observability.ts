export type Health =
  | "healthy"
  | "warning"
  | "critical"
  | "unknown";

export type TopologyKind =
  | "application"
  | "component"
  | "database"
  | "messaging"
  | "external";
  
export type RuntimeType =
  | "process-group"
  | "kubernetes-workload"
  | "container"
  | "hybrid"
  | "unknown";

export interface ComponentService {
  id: string;
  name: string;
}

export interface RequestOutcomes {successful:number;failed:number;unknown:number}

export interface TopologyNode {
  networkRole?: 'proxy'|'gateway'|'loadbalancer'|'network'|'saas'|'external';
  requestOutcomes?:RequestOutcomes;
  id: string;
  label: string;

  kind: TopologyKind;
  runtimeType?: RuntimeType;

  health: Health;

  appCode?: string;
  environment?: string;

  entityId?: string;

  // Runtime inventory
  instanceCount?: number;
  podCount?: number;
  containerCount?: number;
  hostCount?: number;

  // Drill-down
  serviceCount?: number;
  services?: ComponentService[];

  // Observed telemetry
  traffic?: number;
  latencyMs?: number;
  errorRate?: number;

  details?: string[];
}
export interface TopologyEdge {
  metricNote?: string;
  durationSamples?: number;
  evidence?: "trace"|"smartscape"|"unresolved";
  sampleCalls?:number;
  requestOutcomes?:RequestOutcomes;
  interaction?: "request-response" | "messaging" | "unknown";
  operation?: string;
  ratePerMinute?: number;
  id: string;

  source: string;
  target: string;

  protocol?: string;

  calls?: number;
  latencyMs?: number;
  errorRate?: number;

  health: Health;
}

export interface TopologyModel {
  topologyQuality?:string[];
  coverage?: {ownedServices:ComponentService[];relationshipPairs:number};
  warnings?: string[];
  nodes: TopologyNode[];
  edges: TopologyEdge[];
}

export interface RumExperience {
  sessions: number;
  actions: number;
  happy: number;
  satisfied: number;
  frustrated: number;
  errors: number;
  avgDurationMs?: number;
}
