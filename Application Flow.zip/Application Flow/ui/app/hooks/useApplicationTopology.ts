import {validateTraceTopology} from '../mesh/traceTopology';
import {applyNetworkEvidence,outcomes} from '../mesh/networkEvidence';
import {tagValues} from '../mesh/model';
import {databaseIdentity,identityValue,requestHost,enrichServiceLabels} from '../mesh/entityLabels';
import {topologyBatches} from '../mesh/topologyBatches';
import { messagingFlow } from "../mesh/messagingFlow";
import {
  useEffect,
  useState,
} from "react";

import {
  asNumber,
  asString,
  dqlString,
  runDql,
  DqlRecord,
} from "./query";

import {
  TopologyEdge,
  TopologyModel,
  TopologyNode,
} from "../types/observability";

/* =========================================================
   HELPERS
========================================================= */





/* =========================================================
   DISPLAY-NAME RESOLVER

   This changes display names only.
   Process Group IDs remain the real component identity.
========================================================= */

const TECHNOLOGY_WORDS = [
  "SpringBoot",
  "Spring Boot",
  "Java",
  "JVM",
  "Tomcat",
  "Apache Tomcat",
  "WebSphere",
  "JBoss",
  "WildFly",
  "Node.js",
  "NodeJS",
  "dotnet",
  ".NET",
];

const escapeRegex = (
  value: string,
): string =>
  value.replace(
    /[.*+?^${}()|[\]\\]/g,
    "\\$&",
  );

const cleanTechnologyName = (
  input: string,
): string => {
  let value = input.trim();

  for (
    const technology
    of TECHNOLOGY_WORDS
  ) {
    value = value.replace(
      new RegExp(
        `\\b${escapeRegex(
          technology,
        )}\\b`,
        "gi",
      ),
      " ",
    );
  }

  value = value.replace(
    /\b(?:com|org|net|io)\.[a-zA-Z0-9_.$-]+(?:\.[a-zA-Z0-9_.$-]+)+\b/g,
    " ",
  );

  value = value.replace(
    /\((cert|prod|production|dev|test|qa|uat|load)\)/gi,
    " ",
  );

  value = value.replace(
    /\bon\s+port\s+\d+\b/gi,
    " ",
  );

  value = value.replace(
    /\bport\s*[:=]?\s*\d+\b/gi,
    " ",
  );

  return value
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
};

const humanizeName = (
  input: string,
): string =>
  input
    .replace(
      /([a-z0-9])([A-Z])/g,
      "$1 $2",
    )
    .replace(
      /([A-Z])([A-Z][a-z])/g,
      "$1 $2",
    )
    .replace(/\s+/g, " ")
    .trim() || input;

const cleanServiceName = (
  input: string,
  appCode: string,
  environment: string,
): string => {
  let value = input.trim();

  const prefix =
    new RegExp(
      `^${escapeRegex(
        environment,
      )}\\s+${escapeRegex(
        appCode,
      )}\\s*[-:]\\s*`,
      "i",
    );

  value = value.replace(
    prefix,
    "",
  );

  value =
    cleanTechnologyName(
      value,
    );

  value = value
    .replace(
      /Controller$/i,
      "",
    )
    .replace(
      /Application$/i,
      "",
    )
    .replace(
      /SpringBoot$/i,
      "",
    );

  return humanizeName(
    value.trim(),
  );
};







/* =========================================================
   EXCLUDE NON-APPLICATION RUNTIME COMPONENTS
========================================================= */




/* =========================================================
   ONEAGENT-MONITORED BACKEND CLASSIFICATION

   The main Application Flow represents monitored backend
   runtimes, not every operation/service Dynatrace discovers.

   Important:
   - The Process Group is the component boundary.
   - APP/ENV tags establish ownership.
   - A mapped dt.entity.service is supporting evidence.
   - Process Group Instance data is optional enrichment.
     Missing PGI APP/ENV tagging must not suppress a valid
     service-backed application runtime.
   - Technical services remain available in drill-down.
   - Service names alone never create a separate node.
========================================================= */













/* =========================================================
   SERVICE FLOW V2

   Primary topology identity:
   - dt.entity.service = visible service node
   - smartscapeEdges "calls" = observed SERVICE -> SERVICE edge
   - smartscapeEdges "runs_on" = runtime evidence only

   Process Groups are deliberately NOT promoted to application
   nodes in this version.
========================================================= */

const serviceDisplayName = (
  name: string,
  appCode: string,
  environment: string,
): string => {
  const cleaned = cleanServiceName(name, appCode, environment)
    .replace(/\b(?:Service|Controller)\b$/i, "")
    .replace(/\s+/g, " ")
    .trim();

  return cleaned || name;
};



type ServiceRecord = {
  id: string;
  name: string;
  owned: boolean;
  apps?:string[];
};

const timeframeMinutes = (value: string): number => {
  const normalized = value.trim().toLowerCase();
  const short = normalized.match(/^(\d+(?:\.\d+)?)\s*(m|h|d|w)$/);
  if (short) {
    const amount = Number(short[1]);
    const unit = short[2];
    if (unit === "m") return amount;
    if (unit === "h") return amount * 60;
    if (unit === "d") return amount * 1440;
    if (unit === "w") return amount * 10080;
  }

  const long = normalized.match(
    /^(\d+(?:\.\d+)?)\s*(minute|minutes|hour|hours|day|days|week|weeks)$/,
  );
  if (long) {
    const amount = Number(long[1]);
    const unit = long[2];
    if (unit.startsWith("minute")) return amount;
    if (unit.startsWith("hour")) return amount * 60;
    if (unit.startsWith("day")) return amount * 1440;
    if (unit.startsWith("week")) return amount * 10080;
  }

  return 0;
};

const telemetryHealth = (
  requests: number,
  errors: number,
  latencyMs: number,
): TopologyNode["health"] => {
  if (requests <= 0) return "unknown";

  const errorRate = (errors / requests) * 100;
  const availability = 100 - errorRate;

  if (availability < 95 || errorRate >= 5 || latencyMs >= 2000) {
    return "critical";
  }

  if (availability < 99.5 || errorRate >= 1 || latencyMs >= 1000) {
    return "warning";
  }

  return "healthy";
};

export const useApplicationTopology = (
  appCode: string,
  environment: string,
  timeframe = "2h",
) => {
  const [data, setData] = useState<TopologyModel>({
    nodes: [],
    edges: [],
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!appCode || appCode === "ALL" || !environment) {
      setData({ nodes: [], edges: [] });
      setError(null);
      return;
    }

    let cancelled = false;
    let published=false;
    const controller=new AbortController();

    const load = async () => {
      setLoading(true);
      setError(null);
      setData({nodes:[],edges:[]});

      const queryWarnings:string[]=[];
      const checkedDql:typeof runDql=async(query,window,onWarning)=>{
        const label=query.trim().split('\n')[0];
        let rows:DqlRecord[];
        try{rows=await runDql(query,window,message=>{queryWarnings.push(`${label}: ${message}`);onWarning?.(message);},controller.signal);}
        catch(error){queryWarnings.push(`${label}: query failed; coverage is incomplete.`);throw error;}
        const cap=/\|\s*limit\s+(\d+)\s*$/.exec(query.trim());
        if(cap&&rows.length>=Number(cap[1]))queryWarnings.push(`${label}: ${cap[1]}-row cap reached; coverage may be incomplete.`);
        return rows;
      };
      try {
        const appTag = dqlString(`APP:${appCode}`);

        // Per-AppCode fallback:
        // ApplicationFlow passes "__APP_ONLY__" only when this AppCode
        // has no ENV:* tags. APP:<code> then remains the ownership boundary.
        const appOnly = environment === "__APP_ONLY__";

        const envTag = appOnly
          ? ""
          : dqlString(`ENV:${environment}`);

        const envFilter: string = appOnly
          ? ""
          : `| filter in(${envTag}, tags)`;

        /* -------------------------------------------------
           1. Exact APP/ENV-owned Dynatrace SERVICE entities.
        -------------------------------------------------- */
        // Always let Grail/DQL perform APP ownership matching.
        // This is the same query pattern validated in Notebook for DMB.
        //
        // APP-only example:
        //   APP:DMB
        //
        // Environment-tagged example:
        //   APP:WBK + ENV:PROD
        //
        // Do not convert the tags array to a JavaScript string and
        // re-filter it client-side.
        const ownedRows = await checkedDql(`
fetch dt.entity.service
| filter in(${appTag}, tags)
${envFilter}
| fields service_id=toString(id), service_name=entity.name, tags, serviceType, softwareTechnologies, runs_on
| limit 50000
`, timeframe);

        if (cancelled) return;

        const owned = new Map<string, ServiceRecord>();

        for (const row of ownedRows) {
          const id = asString(row.service_id);
          const name = asString(row.service_name) || id;

          // Ownership and presentation are separate concerns.
          // Keep every APP/ENV-owned SERVICE for call/span correlation.
          // Technical/noise filtering happens only when building visible nodes.
          if (!id) continue;

          owned.set(id, {
            id,
            name,
            owned: true,
          });
        }

        if (owned.size === 0) {
          setData({ nodes: [], edges: [], warnings:queryWarnings });
          return;
        }

        /* -------------------------------------------------
           2. Real Smartscape SERVICE -> SERVICE calls.

           We intentionally retrieve the native edge set and
           intersect it with the exact owned SERVICE IDs in
           TypeScript. No PG relationship inference.
        -------------------------------------------------- */
        const callsByPair=new Map<string,DqlRecord>();
        const callBatches=await topologyBatches([...owned.keys()],ids=>`
smartscapeEdges "calls"
| filter startsWith(toString(source_id), "SERVICE-") AND startsWith(toString(target_id), "SERVICE-")
| filter in(toString(source_id), {${ids.map(dqlString).join(',')}}) OR in(toString(target_id), {${ids.map(dqlString).join(',')}})
| summarize calls=count(), by:{source_id,target_id}
| limit 10000`,timeframe,()=>cancelled,message=>queryWarnings.push(message),'Service relationships');
        for(const row of callBatches)callsByPair.set(JSON.stringify([row.source_id,row.target_id]),row);
        const callRows=[...callsByPair.values()];

        if (cancelled) return;

        const rawCalls: Array<{ source: string; target: string; calls: number }> = [];
        const connectedServiceIds = new Set<string>();

        for (const row of callRows) {
          const source = asString(row.source_id);
          const target = asString(row.target_id);

          if (!source || !target || source === target) continue;

          // Keep the observed application neighborhood:
          // at least one side must belong to the selected APP/ENV.
          // IMPORTANT: owned contains ALL tagged services, including hidden
          // technical endpoints, so those endpoints can preserve topology.
          if (!owned.has(source) && !owned.has(target)) continue;

          rawCalls.push({ source, target, calls: (() => {
            const value = Number(row.calls);
            return Number.isFinite(value) && value > 0 ? value : 1;
          })() });
          connectedServiceIds.add(source);
          connectedServiceIds.add(target);
        }

        /* -------------------------------------------------
           3. Resolve names for the connected SERVICE IDs.

           APP/ENV ownership still comes ONLY from step 1.
           This inventory is used solely to name observed
           downstream/upstream SERVICE entities.
        -------------------------------------------------- */
        const inventoryRows = await topologyBatches([...connectedServiceIds],ids=>`
fetch dt.entity.service
| filter in(toString(id), {${ids.map(dqlString).join(',')}})
| fields service_id=toString(id), service_name=entity.name, tags, serviceType, softwareTechnologies, runs_on
| limit 10000`,timeframe,()=>cancelled,message=>queryWarnings.push(message),'Connected service names');

        if (cancelled) return;

        const serviceInventory = new Map<string, ServiceRecord>();

        for (const row of inventoryRows) {
          const id = asString(row.service_id);
          if (!id || !connectedServiceIds.has(id)) continue;

          serviceInventory.set(id, {
            id,
            name: asString(row.service_name) || id,
            owned: owned.has(id),
            apps:tagValues(row.tags,'APP:'),
          });
        }

        for (const [id, record] of owned) {
          serviceInventory.set(id, record);
        }

        // Publish discovery before runtime, endpoint, messaging and trace enrichment.
        if(!cancelled){
          published=true;
          setData({nodes:[...serviceInventory.values()].map(record=>({id:record.id,entityId:record.id,label:record.name,kind:'component' as const,health:'unknown' as const})),edges:rawCalls.map(edge=>({id:`discovery:${edge.source}:${edge.target}`,source:edge.source,target:edge.target,health:'unknown' as const,evidence:'smartscape' as const})),coverage:{ownedServices:[...owned.values()].map(record=>({id:record.id,name:record.name})),relationshipPairs:callRows.length},topologyQuality:['Discovery loaded. Runtime details, dependencies, metrics and trace validation are still loading.']});
          setLoading(false);
        }

        /* -------------------------------------------------
           4. Runtime evidence.

           "runs_on" proves Dynatrace has an observed runtime
           relationship for the SERVICE. It is supporting
           evidence only; it is NOT labelled "OneAgent" because
           runs_on by itself does not prove instrumentation type.
        -------------------------------------------------- */
        const runtimeRows = await topologyBatches([...owned.keys(),...connectedServiceIds],ids=>`
smartscapeEdges "runs_on"
| filter in(toString(source_id), {${ids.map(dqlString).join(',')}})
| fields source_id,target_id
| limit 10000`,timeframe,()=>cancelled,message=>queryWarnings.push(message),'Runtime relationships');

        if (cancelled) return;

        const runtimeTargets = new Map<string, Set<string>>();

        for (const row of runtimeRows) {
          const serviceId = asString(row.source_id);
          const runtimeId = asString(row.target_id);

          if (
            !serviceId ||
            !runtimeId ||
            (!connectedServiceIds.has(serviceId) && !owned.has(serviceId))
          ) {
            continue;
          }

          const set = runtimeTargets.get(serviceId) ?? new Set<string>();
          set.add(runtimeId);
          runtimeTargets.set(serviceId, set);
        }

        /* -------------------------------------------------
           5. AppDynamics-style logical component projection.

           SERVICE remains the evidence graph, but endpoint/alert/health/
           host:port services are hidden. We contract paths through hidden
           services so the canvas preserves the observed call direction
           between meaningful components.
        -------------------------------------------------- */
        const visibleIds = new Set<string>();

        // APP ownership and observed connectivity are different concerns.
        //
        // Previously a service had to appear in Smartscape "calls" before
        // it could become visible. That incorrectly removed APP:DMB services
        // when they were valid APP-owned services but had no matching call
        // edge in the current Smartscape result window.
        //
        // Start with every APP-owned service, then add observed neighboring
        // services. Technical/noise filtering still applies below.
        const visibilityCandidates = new Set<string>([
          ...owned.keys(),
          ...connectedServiceIds,
        ]);

        for (const id of visibilityCandidates) {
          const record = serviceInventory.get(id);
          if (!record) continue;

          visibleIds.add(id);
        }

        const nodes: TopologyNode[] = Array.from(visibleIds)
          .map((id) => serviceInventory.get(id))
          .filter((record): record is ServiceRecord => Boolean(record))
          .map((record) => ({
            id: record.id,
            entityId: record.id,
            label: `${!record.owned&&record.apps?.length===1?`${record.apps[0]} · `:''}${serviceDisplayName(record.name, appCode, environment)}`,
            kind: record.owned ? "component" : "external",
            runtimeType: "unknown",
            health: "unknown",
            appCode: record.owned ? appCode : record.apps?.length===1?record.apps[0]:undefined,
            environment:
              record.owned && !appOnly
                ? environment
                : undefined,
            serviceCount: 1,
            services: [{ id: record.id, name: record.name }],
            details: [
              record.owned ? "Application component" : "Observed downstream component",
              `Dynatrace SERVICE: ${record.id}`,
              ...(record.apps?.length?[`APP tags: ${record.apps.join(', ')}`]:[]),
              `Raw name: ${record.name}`,
              "Endpoint/health/alerting services are hidden from the executive canvas",
            ],
          }));

        const adjacency = new Map<string, Set<string>>();
        for (const { source, target } of rawCalls) {
          const set = adjacency.get(source) ?? new Set<string>();
          set.add(target);
          adjacency.set(source, set);
        }

        const edges: TopologyModel["edges"] = [];
        const edgeKeys = new Set<string>();

        const addEdge = (source: string, target: string, prefix = "flow") => {
          if (source === target || !visibleIds.has(source) || !visibleIds.has(target)) return;
          const key = `${source}->${target}`;
          if (edgeKeys.has(key)) return;
          edgeKeys.add(key);
          edges.push({
            id: `${prefix}:${source}:${target}`,
            source,
            target,
            health: "unknown",
          });
        };

        // Direct observed calls between visible components.
        const directCallCounts = new Map<string, number>();
        for (const { source, target, calls } of rawCalls) {
          if (!visibleIds.has(source) || !visibleIds.has(target)) continue;
          const key = `${source}->${target}`;
          directCallCounts.set(key, (directCallCounts.get(key) ?? 0) + calls);
        }
        for (const [key, calls] of directCallCounts) {
          const [source, target] = key.split("->");
          if (edgeKeys.has(key)) continue;
          edgeKeys.add(key);
          edges.push({
            id: `calls:${key}`,
            source,
            target,
            calls,
            health: "unknown",
          });
        }

        /*
         * V13 controlled graph reduction:
         * preserve connectivity through hidden technical endpoints, but stop
         * each branch at the FIRST visible downstream component. This avoids
         * V11's transitive fan-out and V12's disconnected islands.
         */
        for (const source of visibleIds) {
          const queue: Array<{ id: string; depth: number }> = [];
          const seen = new Set<string>([source]);

          for (const next of adjacency.get(source) ?? []) {
            if (!visibleIds.has(next)) queue.push({ id: next, depth: 1 });
          }

          while (queue.length > 0) {
            const current = queue.shift()!;
            if (seen.has(current.id) || current.depth > 3) continue;
            seen.add(current.id);

            for (const next of adjacency.get(current.id) ?? []) {
              if (next === source) continue;

              if (visibleIds.has(next)) {
                addEdge(source, next, "reduced-path");
                // Do not traverse through a visible component.
                continue;
              }

              queue.push({ id: next, depth: current.depth + 1 });
            }
          }
        }

        /* -------------------------------------------------
           6. Real MQ / Database dependencies from APP-owned
              SERVICE spans.

           Dependency nodes are attached to the emitting visible SERVICE.
           If the emitting SERVICE is hidden, attach to the nearest visible
           upstream component in the observed SERVICE-call graph. This is an
           observed-path projection, not a fabricated SERVICE->PROCESS join.
        -------------------------------------------------- */
        const dependencyRows = await topologyBatches([...owned.keys()],ids=>`
fetch spans
| fieldsAdd dt.entity.service=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))
| filter in(dt.entity.service,{${ids.map(dqlString).join(',')}})
| filter isNotNull(db.system)
    or isNotNull(db.namespace) or isNotNull(db.name) or isNotNull(db.system.name)
    or isNotNull(db.operation.name)
    or isNotNull(messaging.system)
    or isNotNull(messaging.destination.name)
| summarize {
    calls=count(),
    errors=countIf(request.is_failed == true or span.status_code == "error"),
    latency_ms=avg(duration)/1000000
  }, by:{
    dt.entity.service=coalesce(toString(dt.entity.service),toString(dt.smartscape.service)),
    db.system=coalesce(db.system,db.system.name),
    db.namespace=coalesce(db.namespace,db.name),
    db.operation.name,
    server.address,
    server.port,
    messaging.system,
    messaging.destination.name,
    messaging.destination.manager_name,
    messaging.operation.type
  }
| sort calls desc
| limit 10000
`,timeframe,()=>cancelled,message=>queryWarnings.push(message),'Database and messaging dependencies');

        if (cancelled) return;

        const reverseAdjacency = new Map<string, Set<string>>();
        for (const { source, target } of rawCalls) {
          const set = reverseAdjacency.get(target) ?? new Set<string>();
          set.add(source);
          reverseAdjacency.set(target, set);
        }

        /*
         * STRICT dependency ownership.
         *
         * 1. If the dependency span emitter is itself visible, it owns it.
         * 2. If the emitter is hidden/technical, walk upstream through REAL
         *    Smartscape SERVICE->SERVICE calls.
         * 3. Stop at the first distance where visible APP-owned backends exist.
         * 4. Assign ownership ONLY when exactly one backend exists at that
         *    minimum distance.
         * 5. Ambiguous ownership is intentionally not drawn.
         *
         * This prevents one hidden listener/controller from causing a DB/MQ
         * dependency to be propagated to several visible services.
         */
        const strictDependencyOwner = (
          serviceId: string,
        ): { owner?: string; reason: string } => {
          if (visibleIds.has(serviceId) && owned.has(serviceId)) {
            return { owner: serviceId, reason: "exact emitting service" };
          }

          let frontier = new Set<string>([serviceId]);
          const seen = new Set<string>([serviceId]);

          for (let depth = 1; depth <= 4; depth += 1) {
            const nextFrontier = new Set<string>();
            const candidates = new Set<string>();

            for (const current of frontier) {
              for (const previous of reverseAdjacency.get(current) ?? []) {
                if (seen.has(previous)) continue;
                seen.add(previous);

                // Dependency ownership stays inside the selected APP/ENV.
                if (!owned.has(previous)) continue;

                if (visibleIds.has(previous)) {
                  candidates.add(previous);
                } else {
                  nextFrontier.add(previous);
                }
              }
            }

            if (candidates.size === 1) {
              return {
                owner: Array.from(candidates)[0],
                reason: `unique upstream owner at depth ${depth}`,
              };
            }

            if (candidates.size > 1) {
              return {
                reason: `ambiguous: ${candidates.size} visible upstream owners at depth ${depth}`,
              };
            }

            frontier = nextFrontier;
            if (frontier.size === 0) break;
          }

          return { reason: "no unique visible APP-owned upstream owner" };
        };

        const dependencyIds = new Set<string>();
        const scopeNodeId = `app-scope:${appCode}:${environment}`;
        let scopeNodeAdded = false;

        const ensureScopeNode = (): string => {
          if (!scopeNodeAdded) {
            scopeNodeAdded = true;
            nodes.unshift({
              id: scopeNodeId,
              label: appCode,
              kind: "component",
              runtimeType: "unknown",
              health: "unknown",
              appCode,
              environment,
              serviceCount: owned.size,
              services: Array.from(owned.values()).map((service) => ({
                id: service.id,
                name: service.name,
              })),
              details: [
                `AppCode scope: ${appCode}`,
                `Environment: ${environment}`,
                `${owned.size} APP/ENV-owned Dynatrace services`,
                "Logical application scope — not a dt.entity.application",
              ],
            });
            visibleIds.add(scopeNodeId);
          }
          return scopeNodeId;
        };

        const technologyName = (raw: string): string => {
          const v = raw.toLowerCase();
          if (v === "mqseries") return "IBM MQ";
          if (v === "rabbitmq") return "RabbitMQ";
          if (v === "kafka") return "Apache Kafka";
          if (v === "msmq") return "MSMQ";
          if (v === "oracle") return "Oracle";
          if (v === "postgresql") return "PostgreSQL";
          if (v === "mysql") return "MySQL";
          if (v === "mssql") return "Microsoft SQL Server";
          if (!raw || raw === "<unknown>") return "Unknown";
          return raw;
        };

        const dependencySpanCounts = new Map<string, number>();

        for (const row of dependencyRows) {
          const emitter = asString(row["dt.entity.service"]);

          // Dependency spans must come from an exact selected APP/ENV service.
          if (!emitter || !owned.has(emitter)) continue;

          const messagingSystem = asString(row["messaging.system"]);
          const destination = asString(row["messaging.destination.name"]);
          const manager = asString(row["messaging.destination.manager_name"]);

          if (messagingSystem || destination) {
            const tech = technologyName(messagingSystem || "Messaging");
            const label = destination || manager || "Messaging destination";
            // Executive map: one messaging technology node.
            // Individual queue destinations stay as details, not separate circles.
            const id = `mq:${tech.toLowerCase()}`;

            if (!dependencyIds.has(id)) {
              dependencyIds.add(id);
              nodes.push({
                id,
                label: tech,
                kind: "messaging",
                health: "unknown",
                appCode,
                environment,
                details: [
                  `Technology: ${tech}`,
                  label ? `Queue: ${label}` : "Queue name unavailable",
                  manager ? `Queue manager: ${manager}` : "Queue manager unavailable",
                  "Observed from APP-owned SERVICE spans",
                ],
              });
            } else {
              const mqNode = nodes.find((node) => node.id === id);
              if (mqNode) {
                const queueDetail = label ? `Queue: ${label}` : "";
                if (queueDetail && !mqNode.details?.includes(queueDetail)) {
                  mqNode.details = [...(mqNode.details ?? []), queueDetail];
                }
              }
            }

            // Preserve the real emitting backend when it is meaningful.
            // Fall back to the AppCode scope only when the emitter is technical/hidden.
            const ownership = strictDependencyOwner(emitter);
            if (!ownership.owner) {
              console.debug("Skipping ambiguous MQ dependency", {
                emitter,
                dependency: id,
                reason: ownership.reason,
              });
              continue;
            }
            const executiveOwner = ownership.owner;
            const key = `${executiveOwner}->${id}`;
            const countKey = `mq-edge:${key}`;
            const observedCalls = Math.max(1, asNumber(row.calls));
            const observedErrors = Math.max(0, asNumber(row.errors));
            const observedLatencyMs = Math.max(0, asNumber(row.latency_ms));
            const nextCount = (dependencySpanCounts.get(countKey) ?? 0) + observedCalls;
            dependencySpanCounts.set(countKey, nextCount);
            const existing = edges.find((edge) => edge.id === countKey);
            if (existing) {
              const previousCalls = existing.calls ?? 0;
              const previousErrors = ((existing.errorRate ?? 0) / 100) * previousCalls;
              const totalErrors = previousErrors + observedErrors;
              existing.calls = nextCount;
              existing.errorRate = nextCount > 0 ? (totalErrors / nextCount) * 100 : 0;
              existing.latencyMs = observedLatencyMs || existing.latencyMs;
              existing.health = telemetryHealth(nextCount, totalErrors, existing.latencyMs ?? 0);
            } else {
              edgeKeys.add(key);
              edges.push({
                id: countKey,
                source: executiveOwner,
                target: id,
                calls: nextCount,
                latencyMs: observedLatencyMs,
                errorRate: nextCount > 0 ? (observedErrors / nextCount) * 100 : 0,
                health: telemetryHealth(nextCount, observedErrors, observedLatencyMs),
              });
            }
            continue;
          }

          const dbSystem = identityValue(row["db.system"]);
          const dbNamespace = identityValue(row["db.namespace"]);
          
          const host=identityValue(row["server.address"]),port=identityValue(row["server.port"]);
          const server = host&&port?`${host}:${port}`:host;

          const normalizedDbSystem =
            dbSystem && dbSystem !== "<unknown>" ? dbSystem : "";
          const normalizedNamespace =
            dbNamespace && dbNamespace !== "<unknown>" ? dbNamespace : "";
          const normalizedServer =
            server &&
            server !== "<host_unavailable>" &&
            server !== "<unknown>"
              ? server
              : "";

          // A DB operation alone (CONNECT/PREPARE/etc.) is not database identity.
          // Only create a dependency when Dynatrace gives us an identifiable
          // namespace or server destination. db.system enriches technology only.
          const hasRealDatabaseIdentity =
            Boolean(normalizedNamespace || normalizedServer);

          if (hasRealDatabaseIdentity) {
            const tech = technologyName(normalizedDbSystem);
            const label = `${normalizedNamespace || tech || "Database"}${normalizedServer ? ` (${normalizedServer})` : " (server not observed)"}`;

            // Prefer namespace as the logical DB identity. This prevents the
            // same Oracle service from becoming multiple nodes merely because
            // multiple SCAN/server addresses were observed.
            const id = databaseIdentity(normalizedDbSystem,normalizedNamespace,normalizedServer,emitter);

            if (!dependencyIds.has(id)) {
              dependencyIds.add(id);
              nodes.push({
                id,
                label,
                kind: "database",
                health: "unknown",
                appCode,
                environment,
                details: [
                  normalizedDbSystem
                    ? `Technology: ${tech}`
                    : "Technology unavailable",
                  normalizedNamespace
                    ? `Namespace: ${normalizedNamespace}`
                    : "Namespace unavailable",
                  normalizedServer
                    ? `Server: ${normalizedServer}`
                    : "Server unavailable",
                  `Emitting service: ${emitter}`,
                  "Observed from APP-owned SERVICE spans",
                ],
              });
            } else {
              const dbNode = nodes.find((node) => node.id === id);
              if (dbNode) {
                const extraDetails = [
                  normalizedServer ? `Server: ${normalizedServer}` : "",
                  normalizedDbSystem ? `Technology: ${tech}` : "",
                ].filter(Boolean);
                dbNode.details = Array.from(
                  new Set([...(dbNode.details ?? []), ...extraDetails]),
                );
              }
            }

            const ownership = strictDependencyOwner(emitter);
            if (!ownership.owner) {
              console.debug("Skipping ambiguous DB dependency", {
                emitter,
                dependency: id,
                reason: ownership.reason,
              });
              continue;
            }
            const executiveOwner = ownership.owner;
            const key = `${executiveOwner}->${id}`;
            const countKey = `db-edge:${key}`;
            const observedCalls = Math.max(1, asNumber(row.calls));
            const observedErrors = Math.max(0, asNumber(row.errors));
            const observedLatencyMs = Math.max(0, asNumber(row.latency_ms));
            const nextCount = (dependencySpanCounts.get(countKey) ?? 0) + observedCalls;
            dependencySpanCounts.set(countKey, nextCount);
            const existing = edges.find((edge) => edge.id === countKey);
            if (existing) {
              const previousCalls = existing.calls ?? 0;
              const previousErrors = ((existing.errorRate ?? 0) / 100) * previousCalls;
              const totalErrors = previousErrors + observedErrors;
              existing.calls = nextCount;
              existing.errorRate = nextCount > 0 ? (totalErrors / nextCount) * 100 : 0;
              existing.latencyMs = observedLatencyMs || existing.latencyMs;
              existing.health = telemetryHealth(nextCount, totalErrors, existing.latencyMs ?? 0);
            } else {
              edgeKeys.add(key);
              edges.push({
                id: countKey,
                source: executiveOwner,
                target: id,
                calls: nextCount,
                latencyMs: observedLatencyMs,
                errorRate: nextCount > 0 ? (observedErrors / nextCount) * 100 : 0,
                health: telemetryHealth(nextCount, observedErrors, observedLatencyMs),
              });
            }
          }
        }

        /*
         * V20: roll real dependency-edge telemetry up to MQ/DB nodes.
         * This fixes the case where an observed dependency has flow data
         * but its node still says "No data".
         */
        for (const dependencyId of dependencyIds) {
          const dependencyNode = nodes.find((node) => node.id === dependencyId);
          if (!dependencyNode) continue;

          const incomingDependencyEdges = edges.filter(
            (edge) => edge.target === dependencyId && (edge.calls ?? 0) > 0,
          );

          if (incomingDependencyEdges.length === 0) continue;

          const totalCalls = incomingDependencyEdges.reduce(
            (sum, edge) => sum + (edge.calls ?? 0),
            0,
          );

          const totalErrors = incomingDependencyEdges.reduce(
            (sum, edge) =>
              sum + ((edge.errorRate ?? 0) / 100) * (edge.calls ?? 0),
            0,
          );

          const weightedLatency = incomingDependencyEdges.reduce(
            (sum, edge) =>
              sum + (edge.latencyMs ?? 0) * (edge.calls ?? 0),
            0,
          );

          const avgLatency =
            totalCalls > 0 ? weightedLatency / totalCalls : 0;
          const errorRate =
            totalCalls > 0 ? (totalErrors / totalCalls) * 100 : 0;

          dependencyNode.traffic = totalCalls;
          dependencyNode.errorRate = errorRate;
          dependencyNode.latencyMs = avgLatency;
          dependencyNode.health = telemetryHealth(
            totalCalls,
            totalErrors,
            avgLatency,
          );

          dependencyNode.details = [
            ...(dependencyNode.details ?? []),
            `Observed calls: ${totalCalls}`,
            `Successful calls: ${Math.max(0, Math.round(totalCalls - totalErrors))}`,
            `Failed calls: ${Math.round(totalErrors)}`,
            `Error rate: ${errorRate.toFixed(2)}%`,
            `Avg dependency duration: ${avgLatency.toFixed(0)} ms`,
          ];
        }

        /*
         * When a scope node was needed for hidden dependency emitters, connect
         * it only to visible root components. This gives the map one clean
         * AppDynamics-style entry point without fabricating component calls.
         */
        if (scopeNodeAdded) {
          const visibleComponents = nodes.filter(
            (node) => node.kind === "component" && node.id !== scopeNodeId,
          );
          const componentIds = new Set(visibleComponents.map((node) => node.id));
          const incomingComponent = new Set(
            edges
              .filter(
                (edge) =>
                  componentIds.has(edge.source) && componentIds.has(edge.target),
              )
              .map((edge) => edge.target),
          );

          for (const component of visibleComponents) {
            if (incomingComponent.has(component.id)) continue;
            const key = `${scopeNodeId}->${component.id}`;
            if (!edgeKeys.has(key)) {
              edgeKeys.add(key);
              edges.push({
                id: `scope:${key}`,
                source: scopeNodeId,
                target: component.id,
                health: "unknown",
              });
            }
          }
        }

        /*
         * V16 focused application flow:
         *   APP scope -> meaningful APP-owned backends -> MQ / DB
         *
         * We do NOT show all 71 services. A backend is promoted only when it:
         *   1) is APP/ENV owned and survives technical filtering, AND
         *   2) participates in a displayed backend call or owns an MQ/DB edge.
         *
         * SERVICE entities remain the evidence layer; only relevant backends
         * become visible circles.
         */
        const scopeId = ensureScopeNode();

        const dependencyNodeIds = new Set(
          nodes
            .filter((node) => node.kind === "messaging" || node.kind === "database")
            .map((node) => node.id),
        );

        // Inventory and connectivity are intentionally separate:
        // every APP-owned SERVICE is a valid application
        // component even when it has no observed call/dependency in the
        // selected timeframe. Edges remain telemetry-derived only.
        const backendIds = new Set<string>(
          Array.from(owned.keys()),
        );

        // Backends that directly own a technology dependency.
        for (const edge of edges) {
          if (dependencyNodeIds.has(edge.target) && edge.source !== scopeId) {
            const sourceRecord = serviceInventory.get(edge.source);
            if (sourceRecord?.owned) backendIds.add(edge.source);
          }
        }

        // Backends connected to another selected APP-owned backend by a real/reduced call.
        for (const edge of edges) {
          const sourceRecord = serviceInventory.get(edge.source);
          const targetRecord = serviceInventory.get(edge.target);
          if (sourceRecord?.owned && targetRecord?.owned) {
            backendIds.add(edge.source);
            backendIds.add(edge.target);
          }
        }

        // Keep the executive graph bounded for readability. Prefer dependency
        // owners first, then the most connected APP-owned backends.
        const degree = new Map<string, number>();
        for (const edge of edges) {
          degree.set(edge.source, (degree.get(edge.source) ?? 0) + 1);
          degree.set(edge.target, (degree.get(edge.target) ?? 0) + 1);
        }

        const dependencyOwnerIds = new Set<string>();
        for (const edge of edges) {
          if (
            dependencyNodeIds.has(edge.target) &&
            backendIds.has(edge.source) &&
            edge.source !== scopeId
          ) {
            dependencyOwnerIds.add(edge.source);
          }
        }

        const orderedBackends = Array.from(backendIds).sort((a, b) => {
          const aDependencyOwner = dependencyOwnerIds.has(a) ? 1 : 0;
          const bDependencyOwner = dependencyOwnerIds.has(b) ? 1 : 0;
          if (aDependencyOwner !== bDependencyOwner) {
            return bDependencyOwner - aDependencyOwner;
          }

          const degreeDifference =
            (degree.get(b) ?? 0) - (degree.get(a) ?? 0);
          if (degreeDifference !== 0) return degreeDifference;

          const aName =
            serviceInventory.get(a)?.name ?? a;
          const bName =
            serviceInventory.get(b)?.name ?? b;

          return aName.localeCompare(bName);
        });

        // Preserve every owned service; use focus and zoom for readability.
        const selectedBackendIds = new Set(orderedBackends);

        const strictlyOwnedDependencyIds = new Set(
          edges
            .filter(
              (edge) =>
                dependencyNodeIds.has(edge.target) &&
                edge.source !== scopeId &&
                visibleIds.has(edge.source),
            )
            .map((edge) => edge.target),
        );

        const presentationNodes = nodes.filter(
          (node) =>
            node.id === scopeId ||
            selectedBackendIds.has(node.id) ||
            (node.kind === "external" && connectedServiceIds.has(node.id)) ||
            strictlyOwnedDependencyIds.has(node.id),
        );
        const presentationIds = new Set(presentationNodes.map((node) => node.id));

        const presentationEdges: TopologyModel["edges"] = [];
        const presentationEdgeKeys = new Set<string>();

        const pushPresentationEdge = (edge: TopologyModel["edges"][number]) => {
          const key = `${edge.source}->${edge.target}`;
          if (presentationEdgeKeys.has(key)) {
            const existing = presentationEdges.find(
              (candidate) =>
                candidate.source === edge.source && candidate.target === edge.target,
            );
            if (existing && edge.calls) {
              existing.calls = (existing.calls ?? 0) + edge.calls;
            }
            return;
          }
          presentationEdgeKeys.add(key);
          presentationEdges.push(edge);
        };

        // Preserve only relationships among selected visible entities.
        for (const edge of edges) {
          if (
            presentationIds.has(edge.source) &&
            presentationIds.has(edge.target) &&
            edge.source !== scopeId
          ) {
            pushPresentationEdge(edge);
          }
        }

        // Scope is a visual entry point. Connect it only to root backends.
        const incomingBackends = new Set(
          presentationEdges
            .filter(
              (edge) =>
                selectedBackendIds.has(edge.source) &&
                selectedBackendIds.has(edge.target),
            )
            .map((edge) => edge.target),
        );

        for (const backendId of selectedBackendIds) {
          if (!presentationIds.has(backendId) || incomingBackends.has(backendId)) continue;
          pushPresentationEdge({
            id: `scope:${scopeId}:${backendId}`,
            source: scopeId,
            target: backendId,
            health: "unknown",
          });
        }

        /*
         * Real request telemetry for the visible application/backends.
         * request.is_root_span and request.is_failed are native Dynatrace span fields.
         */
        const telemetryServiceIds = Array.from(owned.keys());
        const telemetryFilter = telemetryServiceIds.length > 0
          ? `in(coalesce(toString(dt.entity.service),toString(dt.smartscape.service)), array(${telemetryServiceIds.map(dqlString).join(", ")}))`
          : "";

        const serviceTelemetryRows = telemetryFilter
          ? await checkedDql(`
fetch spans
| filter ${telemetryFilter}
| filter request.is_root_span == true
| summarize {
    requests=count(),
    errors=countIf(request.is_failed == true),
    latency_ms=avg(duration)/1000000
  }, by:{dt.entity.service}
| fields service_id=toString(dt.entity.service), requests, errors, latency_ms
| limit 2000
`, timeframe)
          : [];

        if (cancelled) return;

        const telemetryByService = new Map<
          string,
          { requests: number; errors: number; latencyMs: number }
        >();

        for (const row of serviceTelemetryRows) {
          const id = asString(row.service_id);
          if (!id) continue;
          telemetryByService.set(id, {
            requests: Math.max(0, asNumber(row.requests)),
            errors: Math.max(0, asNumber(row.errors)),
            latencyMs: Math.max(0, asNumber(row.latency_ms)),
          });
        }

        for (const node of presentationNodes) {
          if (!selectedBackendIds.has(node.id)) continue;
          const metric = telemetryByService.get(node.id);
          if (!metric || metric.requests <= 0) continue;

          const successful = Math.max(0, metric.requests - metric.errors);
          const errorRate = (metric.errors / metric.requests) * 100;
          const availability = (successful / metric.requests) * 100;

          node.traffic = metric.requests;
          node.errorRate = errorRate;
          node.latencyMs = metric.latencyMs;
          node.health = telemetryHealth(metric.requests, metric.errors, metric.latencyMs);
          node.details = [
            ...(node.details ?? []),
            `Requests: ${metric.requests}`,
            `Successful responses: ${successful}`,
            `Errors: ${metric.errors}`,
            `Error rate: ${errorRate.toFixed(2)}%`,
            `Request availability: ${availability.toFixed(2)}%`,
            `Avg response time: ${metric.latencyMs.toFixed(0)} ms`,
          ];
        }

        let scopeRequests = 0;
        let scopeErrors = 0;
        let weightedLatency = 0;

        for (const [serviceId, metric] of telemetryByService) {
          if (!owned.has(serviceId) || metric.requests <= 0) continue;
          scopeRequests += metric.requests;
          scopeErrors += metric.errors;
          weightedLatency += metric.latencyMs * metric.requests;
        }

        const scopeNode = presentationNodes.find((node) => node.id === scopeId);
        if (scopeNode && scopeRequests > 0) {
          const scopeLatency = weightedLatency / scopeRequests;
          const successful = Math.max(0, scopeRequests - scopeErrors);
          const errorRate = (scopeErrors / scopeRequests) * 100;
          const availability = (successful / scopeRequests) * 100;

          scopeNode.traffic = scopeRequests;
          scopeNode.errorRate = errorRate;
          scopeNode.latencyMs = scopeLatency;
          scopeNode.health = telemetryHealth(scopeRequests, scopeErrors, scopeLatency);
          scopeNode.details = [
            ...(scopeNode.details ?? []),
            `Requests: ${scopeRequests}`,
            `Successful responses: ${successful}`,
            `Errors: ${scopeErrors}`,
            `Error rate: ${errorRate.toFixed(2)}%`,
            `Request availability: ${availability.toFixed(2)}%`,
            `Avg response time: ${scopeLatency.toFixed(0)} ms`,
          ];
        }

        // Backend-to-backend arrows keep their observed Smartscape call count,
        // but inherit downstream request health for dynamic color.
        for (const edge of presentationEdges) {
          if (dependencyNodeIds.has(edge.target)) continue;
          const targetNode = presentationNodes.find((node) => node.id === edge.target);
          if (!targetNode) continue;
          edge.health = targetNode.health;
          edge.errorRate = targetNode.errorRate;
          edge.latencyMs = targetNode.latencyMs;
        }

        /*
         * V25 rate labels:
         * DB/MQ edge.calls is counted from dependency spans in the selected
         * timeframe, so calls/min is valid for dependency edges.
         * Smartscape edge counts are relationship evidence and are NOT
         * converted to RPM.
         */
        const windowMinutes = timeframeMinutes(timeframe);

        if (windowMinutes > 0) {
          for (const edge of presentationEdges) {
            if (
              dependencyNodeIds.has(edge.target) &&
              typeof edge.calls === "number" &&
              edge.calls >= 0
            ) {
              (
                edge as typeof edge & { ratePerMinute?: number }
              ).ratePerMinute = edge.calls / windowMinutes;
            }
          }
        }

        /*
         * V41: Grail-owned experience inventory.
         *
         * APP:<code> establishes ownership only. These nodes are NOT
         * automatically connected to services. An edge is created only when
         * Grail gives us correlation evidence.
         *
         * This means:
         *   - dt.entity.application => real RUM/application node
         *   - dt.entity.synthetic_test => real Synthetic node when tagged
         *   - no "APP scope -> everything" synthetic arrows
         *
         * Service/service, DB and messaging arrows continue to come from
         * Smartscape/spans above.
         */
        const applicationRows = (await Promise.all(['application','mobile_application','custom_application'].map(type=>checkedDql(`
fetch dt.entity.${type}
| filter in(${appTag}, tags)
| fields application_id=toString(id), application_name=entity.name, tags
| limit 1000
`, timeframe)))).flat();

        if (cancelled) return;

        let syntheticRows: Array<Record<string, unknown>> = [];

        try {
          syntheticRows = await checkedDql(`
fetch dt.entity.synthetic_test
| filter in(${appTag}, tags)
| fields synthetic_id=toString(id), synthetic_name=entity.name, tags
| limit 1000
`, timeframe);
        } catch (syntheticError) {
          // Some tenants expose Synthetic execution telemetry in user.events
          // but do not return APP-tagged dt.entity.synthetic_test records.
          // Do not fail the entire Application Flow in that case.
          console.debug(
            "No APP-tagged dt.entity.synthetic_test inventory available",
            syntheticError,
          );
        }

        if (cancelled) return;

        const experienceNodes: TopologyNode[] = [];
        const experienceIds = new Set<string>();

        for (const row of applicationRows) {
          const entityId = asString(row.application_id);
          if (!entityId) continue;

          const nodeId = `rum:${entityId}`;
          if (experienceIds.has(nodeId)) continue;
          experienceIds.add(nodeId);

          experienceNodes.push({
            id: nodeId,
            entityId,
            label: asString(row.application_name) || entityId,
            kind: "application",
            runtimeType: "unknown",
            health: "unknown",
            appCode,
            details: [
              "RUM APPLICATION",
              "Experience role: Frontend / client",
              `Dynatrace APPLICATION: ${entityId}`,
              `Ownership: APP:${appCode}`,
              "Client Apdex: requires correlated RUM telemetry",
              "Displayed from Grail entity ownership.",
              "No service edge is drawn unless correlation evidence exists.",
            ],
          });
        }

        for (const row of syntheticRows) {
          const entityId = asString(row.synthetic_id);
          if (!entityId) continue;

          const nodeId = `synthetic:${entityId}`;
          if (experienceIds.has(nodeId)) continue;
          experienceIds.add(nodeId);

          experienceNodes.push({
            id: nodeId,
            entityId,
            label: asString(row.synthetic_name) || entityId,
            // Keep the existing TopologyKind contract so V41 works without
            // requiring an immediate renderer/type migration.
            kind: "application",
            runtimeType: "unknown",
            health: "unknown",
            appCode,
            details: [
              "SYNTHETIC",
              "Experience role: Synthetic monitoring",
              `Dynatrace SYNTHETIC_TEST: ${entityId}`,
              `Ownership: APP:${appCode}`,
              "Displayed from Grail entity ownership.",
              "No service edge is drawn unless correlation evidence exists.",
            ],
          });
        }


        /*
         * V46: business-readable span-authoritative dependency enrichment.
         *
         * APP:<code> establishes ownership.
         * Owned SERVICE entities remain the application-service layer.
         * SERVER spans are used as entry evidence on the SERVICE itself;
         * they do NOT create synthetic "Observed inbound" nodes.
         * CLIENT spans create only observed downstream dependencies.
         */
        const isBusinessEndpoint = (value: string): boolean => {
          const endpoint = value.toLowerCase();
          return ![
            "health",
            "ready",
            "live",
            "actuator",
            "metrics",
            "ping",
          ].some((token) => endpoint.includes(token));
        };

        const cleanHost = (value: string): string =>
          value
            .trim()
            .toLowerCase()
            .replace(/^https?:\/\//, "")
            .replace(/\/.*$/, "")
            .replace(/:\d+$/, "");

        const friendlyDependency = (
          destination: string,
          url: string,
          dbNamespace: string,
          dbSystem: string,
          messagingSystem: string,
          messagingDestination: string,
        ): {
          label: string;
          role: string;
          kind: "database" | "messaging" | "external";
        } => {
          if (dbNamespace || dbSystem) {
            return {
              label: `${dbNamespace || dbSystem || "Database"}${destination ? ` (${destination})` : " (server not observed)"}`,
              role: dbSystem ? `Database • ${dbSystem}` : "Database",
              kind: "database",
            };
          }

          if (messagingSystem || messagingDestination) {
            return {
              label: messagingDestination || messagingSystem || "Messaging",
              role: messagingSystem
                ? `Messaging • ${messagingSystem}`
                : "Messaging",
              kind: "messaging",
            };
          }

          const host = cleanHost(destination || url);
          const lower = `${host} ${url}`.toLowerCase();

          if (lower.includes(".blob.core.windows.net")) {
            return {
              label: host.split(".")[0] || "Blob Storage",
              role: "Azure Blob Storage",
              kind: "external",
            };
          }

          const shortHost =
            host.split(".")[0]?.replace(/[-_]+/g, " ") ||
            host ||
            destination ||
            "Downstream dependency";

          if (
            lower.includes("apigtwy") ||
            lower.includes("apigateway") ||
            lower.includes("api-gateway") ||
            lower.includes("gateway")
          ) {
            return {
              label: shortHost,
              role: "API Gateway",
              kind: "external",
            };
          }

          if (lower.includes(".svc.cluster.local")) {
            return {
              label: shortHost,
              role: "Internal Kubernetes API",
              kind: "external",
            };
          }

          if (
            lower.includes("login.") ||
            lower.includes("oauth") ||
            lower.includes("openid") ||
            lower.includes("sso")
          ) {
            return {
              label: shortHost,
              role: "Identity / Authentication",
              kind: "external",
            };
          }

          return {
            label: shortHost,
            role: "Downstream API",
            kind: "external",
          };
        };

        // SERVER spans are entry evidence. We retain this evidence in the
        // service details instead of manufacturing a caller node.
        const entryRows = await topologyBatches([...visibleIds].filter(id=>id.startsWith('SERVICE-')),ids=>`
fetch spans
| fieldsAdd service_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))
| filter in(service_id,{${ids.map(dqlString).join(',')}}) AND span.kind == "server"
| fieldsAdd failed=coalesce(request.is_failed,false) OR lower(coalesce(span.status_code,"")) == "error" OR coalesce(http.response.status_code,0) >= 400
| fieldsAdd successful=failed == false AND (coalesce(request.is_failed,true) == false OR lower(coalesce(span.status_code,"")) == "ok" OR (coalesce(http.response.status_code,0) >= 200 AND coalesce(http.response.status_code,0) < 400))
| summarize requests=count(),failed=countIf(failed),successful=countIf(successful), endpoints=collectDistinct(coalesce(endpoint.name,http.route),maxLength:20), hosts=collectDistinct(server.address,maxLength:20), by:{service_id}
| limit 10000`,timeframe,()=>cancelled,message=>queryWarnings.push(message),'Service endpoint evidence');

        if (cancelled) return;

        const entryEvidence = new Map<
          string,
          {
            requests: number;
            endpoints: Set<string>;
            serverAddresses: Set<string>;
          }
        >();

        for (const row of entryRows) {
          const serviceId = asString(row.service_id);
          if (!serviceId || !owned.has(serviceId)) continue;

          const endpoint = asString(row.endpoint);
          if (endpoint && !isBusinessEndpoint(endpoint)) continue;

          const requests = Math.max(0, asNumber(row.requests));
          if (requests <= 0) continue;

          const current = entryEvidence.get(serviceId) ?? {
            requests: 0,
            endpoints: new Set<string>(),
            serverAddresses: new Set<string>(),
          };

          current.requests += requests;
          if (endpoint) current.endpoints.add(endpoint);

          const hostValues:unknown[]=Array.isArray(row.hosts)?row.hosts:[];
          const serverAddress = hostValues.length===1?asString(hostValues[0]):requestHost(row.server_address,row.url);
          if (
            serverAddress &&
            serverAddress !== "null" &&
            serverAddress !== "<host_unavailable>"
          ) {
            current.serverAddresses.add(serverAddress);
          }
          entryEvidence.set(serviceId, current);
        }

        for (const node of presentationNodes) {
          if (node.kind !== "component") continue;
          const evidence = entryEvidence.get(node.id);
          if (!evidence) continue;

          node.details = [
            ...(node.details ?? []),
            "ENTRY API",
            `${evidence.requests.toLocaleString()} inbound SERVER spans observed`,
            ...Array.from(evidence.endpoints)
              .slice(0, 8)
              .map((endpoint) => `Entry endpoint: ${endpoint}`),
          ];
        }

        const ingressNodes: TopologyNode[] = [];
        const ingressEdges: TopologyEdge[] = [];

        const internallyCalled=new Set(rawCalls.filter(edge=>owned.has(edge.source)).map(edge=>edge.target));
        const ingressByHost=new Map<string,{node:TopologyNode;edges:Map<string,TopologyEdge>}>();
        for(const row of entryRows){
          const serviceId=asString(row.service_id);
          if(!owned.has(serviceId)||!presentationIds.has(serviceId)||internallyCalled.has(serviceId))continue;
          const hostValues:unknown[]=Array.isArray(row.hosts)?row.hosts:[];
          const host=hostValues.length===1?asString(hostValues[0]):requestHost(row.server_address,row.url);
          const key=host||'unresolved',id=`ingress:${appCode}:${key}`;
          const group: {node:TopologyNode;edges:Map<string,TopologyEdge>}=ingressByHost.get(key)??{node:{id,label:host?`Entry host (${host})`:'Entry host (multiple / not recorded)',kind:'external' as const,health:'unknown' as const,traffic:0,details:['Observed HTTP server/request host, not proof of the caller domain.','Only services without a loaded APP-owned upstream caller are shown as entry candidates.']},edges:new Map<string,TopologyEdge>()};
          const counts=outcomes(row);
          const previous=group.node.requestOutcomes??{successful:0,failed:0,unknown:0};group.node.requestOutcomes={successful:previous.successful+counts.successful,failed:previous.failed+counts.failed,unknown:previous.unknown+counts.unknown};
          const calls=Math.max(0,asNumber(row.requests));group.node.traffic=(group.node.traffic??0)+calls;
          const edge:TopologyEdge=group.edges.get(serviceId)??{id:`${id}:${serviceId}`,source:id,target:serviceId,calls:0,health:'unknown' as const};edge.calls=(edge.calls??0)+calls;const previousEdge=edge.requestOutcomes??{successful:0,failed:0,unknown:0};edge.requestOutcomes={successful:previousEdge.successful+counts.successful,failed:previousEdge.failed+counts.failed,unknown:previousEdge.unknown+counts.unknown};group.edges.set(serviceId,edge);ingressByHost.set(key,group);
        }
        for(const group of ingressByHost.values()){ingressNodes.push(group.node);ingressEdges.push(...group.edges.values());}

        // CLIENT spans are the authoritative outbound dependency evidence.
        // Group by logical destination + DB/MQ identity so URL paths do not
        // explode into many duplicate nodes.
        const outboundRows = await topologyBatches([...owned.keys()],ids=>`
fetch spans
| fieldsAdd service_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))
| filter in(service_id,{${ids.map(dqlString).join(',')}})
| filter span.kind == "client"
| fieldsAdd failed=coalesce(request.is_failed,false) OR lower(coalesce(span.status_code,"")) == "error" OR coalesce(http.response.status_code,0) >= 400
| fieldsAdd successful=failed == false AND (coalesce(request.is_failed,true) == false OR lower(coalesce(span.status_code,"")) == "ok" OR (coalesce(http.response.status_code,0) >= 200 AND coalesce(http.response.status_code,0) < 400))
| summarize {
    calls=count(),
    errors=countIf(failed), successful=countIf(successful),
    latency_ms=avg(duration)/1000000
  }, by:{
    service_id,
    server.address,
    server.port,
    url.full,
    http.request.method,
    db.system=coalesce(db.system,db.system.name),
    db.namespace=coalesce(db.namespace,db.name),
    messaging.system,
    messaging.destination.name
  }
| fields
    service_id,
    destination=toString(server.address),
    port=toString(server.port),
    url=toString(url.full),
    method=toString(http.request.method),
    db_system=toString(db.system),
    db_namespace=toString(db.namespace),
    messaging_system=toString(messaging.system),
    messaging_destination=toString(messaging.destination.name),
    calls,
    errors,successful,
    latency_ms
| sort calls desc
| limit 10000
`,timeframe,()=>cancelled,message=>queryWarnings.push(message),'Outbound dependency evidence');

        if (cancelled) return;

        const spanNodes: TopologyNode[] = [];
        const spanEdges: TopologyEdge[] = [];
        const spanNodeIds = new Set<string>();

        const addSpanNode = (node: TopologyNode) => {
          if (spanNodeIds.has(node.id)) {
            const existing=spanNodes.find(item=>item.id===node.id);
            if(existing&&node.requestOutcomes){const previous=existing.requestOutcomes??{successful:0,failed:0,unknown:0};existing.requestOutcomes={successful:previous.successful+node.requestOutcomes.successful,failed:previous.failed+node.requestOutcomes.failed,unknown:previous.unknown+node.requestOutcomes.unknown};const total=(existing.traffic??0)+(node.traffic??0);existing.latencyMs=total?((existing.latencyMs??0)*(existing.traffic??0)+(node.latencyMs??0)*(node.traffic??0))/total:undefined;existing.traffic=total;}
            return;
          }
          spanNodeIds.add(node.id);
          spanNodes.push(node);
        };

        const outboundByKey = new Map<
          string,
          {
            serviceId: string;
            identity:string;
            destination: string;
            label: string;
            role: string;
            kind: "database" | "messaging" | "external";
            calls: number;
            errors: number;
            successful:number;
            weightedLatency: number;
            urls: Set<string>;
            methods: Set<string>;
            protocols: Set<string>;
          }
        >();

        for (const row of outboundRows) {
          const serviceId = asString(row.service_id);
          const host=identityValue(row.destination),port=identityValue(row.port);
          const destination = host&&port?`${host}:${port}`:host;
          const url = asString(row.url);
          const dbNamespace = identityValue(row.db_namespace);
          const dbSystem = identityValue(row.db_system);
          const messagingSystem = asString(row.messaging_system);
          const messagingDestination = asString(row.messaging_destination);

          if (!serviceId || !owned.has(serviceId)) continue;
          if (messagingSystem || messagingDestination) continue;
          if (
            !destination &&
            !url &&
            !dbNamespace &&
            !dbSystem &&
            !messagingSystem &&
            !messagingDestination
          ) {
            continue;
          }

          if (destination === "<host_unavailable>") continue;

          const calls = Math.max(0, asNumber(row.calls));
          if (calls <= 0) continue;

          const classification = friendlyDependency(
            destination,
            url,
            dbNamespace,
            dbSystem,
            messagingSystem,
            messagingDestination,
          );

          const logicalIdentity =
            classification.kind === "database"
              ? databaseIdentity(dbSystem,dbNamespace,destination,serviceId)
              : classification.kind === "messaging"
                ? `mq:${(messagingDestination || messagingSystem || destination).toLowerCase()}`
                : `ext:${cleanHost(destination || url)}`;

          const key = `${serviceId}|${logicalIdentity}`;
          const current = outboundByKey.get(key) ?? {
            serviceId,
            identity:logicalIdentity,
            destination: destination || url,
            label: classification.label,
            role: classification.role,
            kind: classification.kind,
            calls: 0,
            errors: 0,
            successful:0,
            weightedLatency: 0,
            urls: new Set<string>(),
            methods: new Set<string>(),
            protocols: new Set<string>(),
          };

          const latency = Math.max(0, asNumber(row.latency_ms));
          current.calls += calls;
          current.errors += Math.max(0, asNumber(row.errors));
          current.successful += Math.max(0,asNumber(row.successful));
          current.weightedLatency += latency * calls;

          if (url && url !== "null") current.urls.add(url);
          const method = asString(row.method);
          if (method && method !== "null") current.methods.add(method);

          if(dbSystem&&dbSystem!=="null")current.protocols.add(dbSystem.toUpperCase());
          else if((method&&method!=="null")||/^https?:\/\//i.test(url))current.protocols.add("HTTP");
          outboundByKey.set(key, current);
        }

        for (const outbound of outboundByKey.values()) {
          if (!presentationIds.has(outbound.serviceId)) continue;

          const identity =
            outbound.kind === "database"
              ? outbound.identity
              : outbound.kind === "messaging"
                ? `mq:${outbound.label.toLowerCase()}`
                : `external:${cleanHost(outbound.destination)}`;

          // Prefer an already-rendered DB/MQ node if it clearly represents
          // this same logical dependency.
          const existing = presentationNodes.find(node=>node.id===identity);

          const targetId = existing?.id ?? identity;
          const latency =
            outbound.calls > 0
              ? outbound.weightedLatency / outbound.calls
              : 0;
          const errorRate =
            outbound.calls > 0
              ? (outbound.errors / outbound.calls) * 100
              : 0;

          if (!existing) {
            addSpanNode({
              id: targetId,
              label: outbound.label,
              kind: outbound.kind,
              runtimeType: "unknown",
              health: telemetryHealth(
                outbound.calls,
                outbound.errors,
                latency,
              ),
              appCode,
              requestOutcomes:outcomes({calls:outbound.calls,errors:outbound.errors,successful:outbound.successful}),
              traffic: outbound.calls,
              latencyMs: latency,
              errorRate,
              details: [
                outbound.role,
                "Observed from CLIENT spans in Grail",
                `Destination: ${outbound.destination}`,
                ...Array.from(outbound.methods)
                  .slice(0, 4)
                  .map((method) => `Method: ${method}`),
                ...Array.from(outbound.urls)
                  .slice(0, 5)
                  .map((url) => `URL: ${url}`),
              ],
            });
          }

          const existingEdge = spanEdges.find(
            (edge) =>
              edge.source === outbound.serviceId &&
              edge.target === targetId,
          );

          if (existingEdge) {
            const previous=existingEdge.requestOutcomes??{successful:0,failed:0,unknown:existingEdge.calls??0};
            const counts=outcomes({calls:outbound.calls,errors:outbound.errors,successful:outbound.successful});
            existingEdge.requestOutcomes={successful:previous.successful+counts.successful,failed:previous.failed+counts.failed,unknown:previous.unknown+counts.unknown};
            existingEdge.calls =
              (existingEdge.calls ?? 0) + outbound.calls;
          } else {
            spanEdges.push({
              id: `client:${outbound.serviceId}:${targetId}`,
              requestOutcomes:outcomes({calls:outbound.calls,errors:outbound.errors,successful:outbound.successful}),
              protocol: [...outbound.protocols].sort().join(" / ")||undefined,
              interaction: outbound.methods.size>0 || outbound.urls.size>0 ? "request-response" : "unknown",
              source: outbound.serviceId,
              target: targetId,
              calls: outbound.calls,
              health: telemetryHealth(
                outbound.calls,
                outbound.errors,
                latency,
              ),
              latencyMs: latency,
              errorRate,
            });
          }
        }

        const messagingWarnings:string[]=[];
        let queueFlow:{nodes:TopologyNode[];edges:TopologyEdge[]}={nodes:[],edges:[]};
        const messagingServices=presentationNodes.filter(node=>node.id.startsWith('SERVICE-')).map(node=>node.id);
        if(messagingServices.length){try{
          const rows=await topologyBatches(messagingServices,ids=>`fetch spans
| fieldsAdd service_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))
| filter in(service_id,{${ids.map(dqlString).join(',')}})
| filter isNotNull(messaging.destination.name)
| summarize calls=count(), errors=countIf(request.is_failed == true OR lower(span.status_code) == "error" OR transaction.is_failed == true), latency_ms=avg(duration)/1ms,
  by:{service_id,kind=span.kind,operation=messaging.operation.type,system=messaging.system,destination=messaging.destination.name,manager=messaging.destination.manager_name,address=server.address,port=server.port}
| limit 10000`,timeframe,()=>cancelled,message=>messagingWarnings.push(message),'Application messaging');
          queueFlow=messagingFlow(rows,new Set(messagingServices),timeframeMinutes(timeframe));
        }catch(error){messagingWarnings.push(`Messaging coverage unavailable: ${error instanceof Error?error.message:'query failed'}`);}}
        if(cancelled)return;

        const windowMinutesV46 = timeframeMinutes(timeframe);
        if (windowMinutesV46 > 0) {
          for (const edge of spanEdges) {
            if (typeof edge.calls === "number" && edge.calls >= 0) {
              (
                edge as typeof edge & { ratePerMinute?: number }
              ).ratePerMinute = edge.calls / windowMinutesV46;
            }
          }
        }

        /*
         * V27: APP:<code> is FILTER/SCOPE, not an observed runtime hop.
         *
         * The Application Flow must start from real root backend services.
         * Therefore the logical app-scope node and its synthetic grouping
         * edges are removed from the rendered model. APP/ENV remain visible
         * in the page header/scope chips and still control all correlation.
         */
        const runtimePresentationNodes = [
          ...queueFlow.nodes,
          ...experienceNodes,
          ...ingressNodes,
          ...spanNodes,
          ...presentationNodes.filter(
            (node) => node.id !== scopeId,
          ),
        ];

        applyNetworkEvidence(runtimePresentationNodes,[...ownedRows,...inventoryRows],entryRows);
        enrichServiceLabels(runtimePresentationNodes,entryRows);
        for(const node of runtimePresentationNodes){
          if(node.kind==='database')node.details=[...(node.details??[]),`Health basis: observed database calls; ${node.errorRate===undefined?'error rate unavailable':`${node.errorRate.toFixed(2)}% errors`}; ${node.latencyMs===undefined?'latency unavailable':`${node.latencyMs.toFixed(1)} ms mean`}. Critical threshold in this topology: error rate >=5% or mean >=2000 ms. Database naming completeness does not determine health.`];
        }

        const runtimePresentationIds = new Set(
          runtimePresentationNodes.map((node) => node.id),
        );

        const runtimePresentationEdges = [
          ...queueFlow.edges,
          ...ingressEdges.filter(
            (edge) =>
              runtimePresentationIds.has(edge.source) &&
              runtimePresentationIds.has(edge.target),
          ),
          ...presentationEdges.filter(
            (edge) =>
              edge.source !== scopeId &&
              edge.target !== scopeId &&
              runtimePresentationIds.has(edge.source) &&
              runtimePresentationIds.has(edge.target),
          ),
          ...spanEdges.filter(
            (edge) =>
              runtimePresentationIds.has(edge.source) &&
              runtimePresentationIds.has(edge.target),
          ),
        ];

        console.log("Application Flow V47 - dynamic end-to-end topology", {
          appCode,
          environment: appOnly ? "APP_ONLY" : environment,
          timeframe,
          appOnlyFallback: appOnly,
          ownedApplications: applicationRows.length,
          ownedSyntheticTests: syntheticRows.length,
          ownedServices: owned.size,
          ownedServiceIds: Array.from(owned.keys()),
          selectedBackendIds: Array.from(selectedBackendIds),
          renderedOwnedServices: runtimePresentationNodes.filter(
            (node) => node.kind === "component",
          ).length,
          connectedServices: presentationNodes.filter((node) => node.kind === "component").length,
          observedConnections: presentationEdges.length,
          dependencies: presentationNodes.filter((node) => node.kind === "messaging" || node.kind === "database").length,
        });

        if (!cancelled) {
          const discovered:TopologyModel={nodes:runtimePresentationNodes,edges:runtimePresentationEdges.map(edge=>edge.source.startsWith('SERVICE-')&&edge.target.startsWith('SERVICE-')?{...edge,evidence:'smartscape' as const,calls:undefined,ratePerMinute:undefined}:edge),warnings:[...new Set([...queryWarnings,...messagingWarnings])],coverage:{ownedServices:[...owned.values()].map(service=>({id:service.id,name:service.name})),relationshipPairs:callRows.length},topologyQuality:['Discovery loaded; trace validation and connection metrics are loading in the background.']};
          published=true;setData(discovered);setLoading(false);
          const validated=await validateTraceTopology(discovered,[...owned.keys()],timeframe,()=>cancelled);
          if(!cancelled)setData(validated);
        }
      } catch (caught) {
        if (cancelled) return;

        console.error("Application Flow V44 query failed", caught);
        if(!published)setData({ nodes: [], edges: [] });
        else setData(previous=>({...previous,topologyQuality:[...(previous.topologyQuality??[]),'Further enrichment stopped after a query failure; discovered topology is retained.']}));
        setError(
          caught instanceof Error
            ? caught.message
            : "Unable to load Application Flow.",
        );
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    void load();

    return () => {
      cancelled = true;controller.abort();
    };
  }, [appCode, environment, timeframe]);

  return {
    data,
    loading,
    error,
  };
};
