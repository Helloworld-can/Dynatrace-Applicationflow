import {TopologyEdge} from '../types/observability';

const valid=(n:number|undefined):n is number=>n!==undefined&&Number.isFinite(n)&&n>=0;

/** Exact repeated edge IDs are duplicate evidence. Different sources/evidence remain separate. */
export function aggregateEdges(input:TopologyEdge[],summary=false):TopologyEdge[] {
  const unique=new Map<string,TopologyEdge>();
  for(const edge of input){
    const key=JSON.stringify([edge.id,edge.source,edge.target,edge.evidence,edge.interaction,edge.operation]);
    const previous=unique.get(key);
    if(!previous)unique.set(key,edge);
    else {
      const metrics=(e:TopologyEdge)=>JSON.stringify([e.calls,e.latencyMs,e.durationSamples,e.ratePerMinute,e.requestOutcomes,e.sampleCalls]);
      if(metrics(previous)!==metrics(edge))unique.set(key,{...previous,calls:undefined,latencyMs:undefined,durationSamples:undefined,ratePerMinute:undefined,requestOutcomes:undefined,sampleCalls:undefined,metricNote:'Conflicting duplicate evidence; metrics withheld'});
    }
  }
  const groups=new Map<string,TopologyEdge[]>();
  for(const edge of unique.values()){
    if(edge.source===edge.target)continue;
    const key=JSON.stringify([edge.source,edge.target,edge.evidence,edge.interaction,edge.protocol,summary?'':edge.operation]);
    const list=groups.get(key)??[];list.push(edge);groups.set(key,list);
  }
  return [...groups.values()].map(list=>{
    const measured=list.filter(e=>valid(e.calls));
    const calls=measured.length?measured.reduce((n,e)=>n+e.calls!,0):undefined;
    const notes=new Set(list.flatMap(e=>e.metricNote?[e.metricNote]:[]));
    if(measured.length&&measured.length<list.length)notes.add('Partial metrics: some grouped connections have no measurements');
    const outcomes={successful:0,failed:0,unknown:0};
    for(const edge of measured){
      const o=edge.requestOutcomes;
      if(o&&valid(o.successful)&&valid(o.failed)&&valid(o.unknown)&&Math.abs(o.successful+o.failed+o.unknown-edge.calls!)<0.001){
        outcomes.successful+=o.successful;outcomes.failed+=o.failed;outcomes.unknown+=o.unknown;
      }else{
        outcomes.unknown+=edge.calls!;
        if(o)notes.add('Outcome totals do not match call totals; classifications withheld');
      }
    }
    let durationSum=0,durationSamples=0;
    for(const edge of measured){
      const weight=edge.durationSamples??edge.calls;
      if(valid(edge.latencyMs)&&valid(weight)&&weight>0){durationSum+=edge.latencyMs*weight;durationSamples+=weight;}
    }
    const rates=list.filter(e=>valid(e.ratePerMinute));
    const samples=list.filter(e=>valid(e.sampleCalls));
    const health=list.some(e=>e.health==='critical')?'critical':list.some(e=>e.health==='warning')?'warning':list.every(e=>e.health==='healthy')?'healthy':'unknown';
    return {...list[0],calls,ratePerMinute:rates.length?rates.reduce((n,e)=>n+e.ratePerMinute!,0):undefined,
      sampleCalls:samples.length?samples.reduce((n,e)=>n+e.sampleCalls!,0):undefined,
      latencyMs:durationSamples?durationSum/durationSamples:undefined,durationSamples,
      requestOutcomes:calls===undefined?undefined:outcomes,
      errorRate:calls&&outcomes.unknown===0?100*outcomes.failed/calls:undefined,
      metricNote:[...notes].join('; ')||undefined,health};
  });
}
