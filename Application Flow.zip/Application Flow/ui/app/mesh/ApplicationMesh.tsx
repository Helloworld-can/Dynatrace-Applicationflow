import {useFlowPreferences} from './FlowPreferences';
import {FlowLegend} from './FlowLegend';
import {compactPositions} from './compactPositions';
import {EntityProperties} from './EntityProperties';
import { connectionLabel, connectionMetricLines } from './connectionEvidence';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Background, Controls, MarkerType, MiniMap, Node, ReactFlow, useNodesInitialized, useNodesState, useReactFlow } from '@xyflow/react';
import { Button } from '@dynatrace/strato-components/buttons';
import { DataEdge, meshEdgeTypes } from './DataFlowEdge';
import { ApplicationMesh as Model } from './model';

import '@xyflow/react/dist/style.css';

function FitVisibleGraph({identity}:{identity:string}) {
  const anchor=useRef<HTMLSpanElement>(null);
  const initialized=useNodesInitialized();
  const {fitView,zoomTo}=useReactFlow();
  const {settings}=useFlowPreferences();
  useEffect(()=>{
    if(!initialized)return;
    let frame=requestAnimationFrame(()=>{void fitView({padding:0.12,minZoom:0.05,maxZoom:1}).then(()=>{if(settings.zoom!=='fit')void zoomTo(Number(settings.zoom));});});
    const resize=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{void fitView({padding:0.12,minZoom:0.05,maxZoom:1}).then(()=>{if(settings.zoom!=='fit')void zoomTo(Number(settings.zoom));});});};
    const container=anchor.current?.closest('.react-flow');
    const observer=new ResizeObserver(resize);
    if(container)observer.observe(container);
    window.addEventListener('resize',resize);
    return()=>{observer.disconnect();cancelAnimationFrame(frame);window.removeEventListener('resize',resize);};
  },[initialized,identity,fitView,zoomTo,settings.zoom]);
  return <span ref={anchor} hidden/>;
}

const healthColours = {healthy:'#079465',warning:'#df9600',critical:'#d53343',unknown:'#8392a5'};
const metric=(value:number|undefined,suffix:string)=>value===undefined?'—':`${value.toLocaleString(undefined,{maximumFractionDigits:1})}${suffix}`;
export function ApplicationMesh({model, onOpen}:{model:Model; onOpen:(app:string)=>void}) {
  const [search, setSearch] = useState('');
  const [manualPositions,setManualPositions]=useState<Record<string,{x:number;y:number}>>({});
  const [layoutRevision,setLayoutRevision]=useState(0);
  const [connectedOnly,setConnectedOnly]=useState(false);
  const [selected, setSelected] = useState('');
  const {settings,change}=useFlowPreferences();
  const motion=settings.animation;
  const setMotion=(animation:boolean)=>change({animation});
  const [hovered,setHovered] = useState<{id:string;x:number;y:number}|null>(null);
  const [neighboursOnly, setNeighboursOnly] = useState(false);
  const graph = useMemo(() => {
    const term=search.trim().toLowerCase();
    const exact=model.apps.find(app=>app.id.toLowerCase()===term);
    const roots=new Set(term?(exact?[exact.id]:model.apps.filter(app=>app.id.toLowerCase().includes(term)).map(app=>app.id)):neighboursOnly&&selected?[selected]:[]);
    const focused=term.length>0||(neighboursOnly&&!!selected);
    const neighbourhood=new Set(roots);
    model.connections.forEach(edge=>{if(roots.has(edge.source))neighbourhood.add(edge.target);if(roots.has(edge.target))neighbourhood.add(edge.source);});
    const connected=new Set(model.connections.flatMap(edge=>[edge.source,edge.target]));
    const visible=model.apps.filter(app=>focused?neighbourhood.has(app.id):!connectedOnly||connected.has(app.id)||app.id===selected);
    const visibleIds = new Set(visible.map(app => app.id));
    const positions = compactPositions(visible.map(app => app.id), model.connections,exact?.id??(neighboursOnly?selected:undefined));
    const nodes: Node[] = visible.map(app => ({id:app.id, width:210, height:210, position:manualPositions[app.id] ?? positions.get(app.id) ?? {x:0,y:0},
      data:{label:<div className="mesh-circle-content" tabIndex={0} aria-label={`${app.id} golden signals`} onFocus={event=>{const r=event.currentTarget.getBoundingClientRect();setHovered({id:app.id,x:r.right,y:r.top});}} onBlur={()=>setHovered(null)}>
        <small>APPLICATION</small><strong className="mesh-circle-title">{app.id}</strong>
        <span className="mesh-circle-health" style={{color:healthColours[app.signals?.health ?? 'unknown']}}>{(app.signals?.health ?? 'unknown').toUpperCase()}</span>
        <small>{app.scopeNote??`${app.services.length} services`}</small>
      </div>},
      sourcePosition:'right' as Node['sourcePosition'], targetPosition:'left' as Node['targetPosition'],
      style:{width:210,height:210,borderRadius:'50%',padding:20,boxSizing:'border-box',display:'flex',alignItems:'center',justifyContent:'center',
        border:`4px solid ${healthColours[app.signals?.health ?? 'unknown']}`,
        background:'#fff',color:'#102f4d',boxShadow:app.id===selected?'0 0 0 5px #b6ddf7, 0 8px 24px #183c6020':'0 6px 20px #183c6012'},
      ariaLabel:`Application ${app.id}. Health ${app.signals?.health ?? 'unknown'}. ${app.services.length} services.`, selected:app.id === selected}));
    const directedPairs = new Set(model.connections.map(edge => JSON.stringify([edge.source, edge.target])));
    const edges: DataEdge[] = model.connections.filter(edge => visibleIds.has(edge.source) && visibleIds.has(edge.target) && (!focused || roots.has(edge.source) || roots.has(edge.target))).map(edge => {
      const a=nodes.find(node=>node.id===edge.source)!.position,b=nodes.find(node=>node.id===edge.target)!.position;
      const dx=b.x-a.x,dy=b.y-a.y,length=Math.hypot(dx,dy)||1;
      const circlePath={sx:a.x+105+dx/length*105,sy:a.y+105+dy/length*105,tx:b.x+105-dx/length*105,ty:b.y+105-dy/length*105};
      const focus=selected;
      const active = edge.source === focus || edge.target === focus;
      const reverse = directedPairs.has(JSON.stringify([edge.target, edge.source]));
      const format=(value:number|undefined)=>value===undefined?'—':value.toLocaleString(undefined,{maximumFractionDigits:1});
      const response=edge.metrics?.responseMs;
      const latency=response===undefined?'— ms':response>=1000?`${format(response/1000)} s`:`${format(response)} ms`;
      const aboveLabel=`${format(edge.metrics?.requestsPerMinute)} calls/min · ${latency}\n${format(edge.metrics?.requests)} total calls (observed)`;
      const protocol=connectionLabel(edge);
      const protocolLabel=protocol==='Type unknown'?'':protocol;
      const outcomes=edge.metrics?`${format(edge.metrics.successes)} successful · ${format(edge.metrics.errors)} failed${edge.metrics.unknown?` · ${format(edge.metrics.unknown)} unknown`:''}`:'Success / failure unavailable';
      const missing=model.connectionMetricsIncomplete?'Metrics query incomplete':'Topology only · no matching spans';
      const belowLabel=[protocolLabel,edge.metrics?outcomes:missing,edge.metrics?.incomplete?'Partial observations':undefined].filter(Boolean).join('\n');
      return {id:edge.id,source:edge.source,target:edge.target,type:'dataFlow',data:{aboveLabel,belowLabel,circlePath,colour:'#79a8ed',motion:motion && (!focus || active),curvature:0.35,labelsVisible:true,parallel:reverse},
        label:[`${edge.source} → ${edge.target}`,...(edge.scopeUnverified?['ENV scope unverified']:[]),...(connectionMetricLines(edge).length?connectionMetricLines(edge):['Call metrics unavailable']),...(edge.queues?.length?[`Async · ${edge.queues.join(', ')}`]:[])].join('\n'),
        markerEnd:{type:MarkerType.ArrowClosed,color:'#467bb5',width:18,height:18},
        style:{stroke:'#467bb5',strokeDasharray:edge.scopeUnverified?'7 4':undefined,strokeWidth:active ? 2.4 : 1.8,opacity:focus && !active ? 0.2 : 0.85},
        ariaLabel:`${edge.source} calls ${edge.target}; ${edge.servicePairs} service relationships`};
    });
    return {nodes,edges};
  }, [model, search, selected, neighboursOnly, motion, manualPositions, connectedOnly]);
  const [displayNodes,setDisplayNodes,onNodesChange]=useNodesState<Node>([]);
  useEffect(()=>{
    // Preserve measured dimensions and drag state while reconciling refreshed labels/layout.
    setDisplayNodes(previous=>{
      const known=new Map(previous.map(node=>[node.id,node]));
      return graph.nodes.map(node=>({...known.get(node.id),...node,measured:known.get(node.id)?.measured}));
    });
  },[graph.nodes,setDisplayNodes]);
  const linkedIds=new Set(model.connections.flatMap(edge=>[edge.source,edge.target]));
  const isolatedApps=model.apps.filter(app=>!linkedIds.has(app.id) && app.id.toLowerCase().includes(search.toLowerCase()));
  const hoverApp=model.apps.find(item=>item.id===hovered?.id);
  const app = model.apps.find(item => item.id === selected);
  const incoming = model.connections.filter(edge => edge.target === selected), outgoing = model.connections.filter(edge => edge.source === selected);
  return <>
    <div className="mesh-toolbar">
      <label>Find application <input aria-label="Find application" placeholder="Search APP code" value={search} onChange={event=>setSearch(event.target.value)}/></label>
      <label><input type="checkbox" checked={neighboursOnly} disabled={!app} onChange={event=>setNeighboursOnly(event.target.checked)}/> Selected application and neighbours</label>
<label><input type="checkbox" checked={motion} onChange={event=>setMotion(event.target.checked)}/> Animate flow direction</label>
      <label><input type="checkbox" checked={connectedOnly} onChange={event=>setConnectedOnly(event.target.checked)}/> Connected applications only</label>
      <Button onClick={()=>{setManualPositions({});setLayoutRevision(value=>value+1);}}>Reset layout</Button>
      <span>{graph.nodes.length} applications · {graph.edges.length} directed connections</span>
    </div>
    <div className="mesh-live-status" role="status">
      <span>● Application health refresh · 60s after completion</span>
      <span>{model.metricsRefreshing?'Refreshing metrics…':model.metricsUpdatedAt?`Updated ${new Date(model.metricsUpdatedAt).toLocaleTimeString()}`:'No successful metric refresh'}</span>
      <span>Health: last 5 minutes · Link metrics: selected timeframe, updated on Refresh</span>
      <span><b style={{color:healthColours.healthy}}>●</b> Healthy · <b style={{color:healthColours.warning}}>●</b> Warning · <b style={{color:healthColours.critical}}>●</b> Critical · <b style={{color:healthColours.unknown}}>●</b> Unknown</span>
    </div>
    {model.metricsWarning && <p className="mesh-warning" role="alert">Metrics unavailable or incomplete: {model.metricsWarning}</p>}
    {hoverApp && hovered && <div className="mesh-hover-card" role="tooltip" style={{left:Math.max(8,Math.min(hovered.x,window.innerWidth-370)),top:Math.max(8,Math.min(hovered.y,window.innerHeight-370))}}>
      <header><strong>{hoverApp.id} · Golden signals</strong><b style={{color:healthColours[hoverApp.signals?.health ?? 'unknown']}}>{(hoverApp.signals?.health ?? 'unknown').toUpperCase()}</b></header>
      <div className="signal-grid">
        <div><small>Traffic · observed requests</small><strong>{metric(hoverApp.signals?.requestsPerMinute,' /min')}</strong></div>
        <div><small>Latency · mean response</small><strong>{metric(hoverApp.signals?.latencyMs,' ms')}</strong></div>
        <div><small>Error rate</small><strong>{metric(hoverApp.signals?.errorRate,'%')}</strong></div>
        <div><small>Saturation</small><strong>Not available</strong></div>
      </div>
      <p>{hoverApp.signals?.reportingServices ?? 0}/{hoverApp.services.length} services reporting health in the last 5 minutes.</p>
      <small>Metrics: selected timeframe. Open Application Flow for service-level signals and host CPU. Motion illustrates connection direction, not measured packets or link volume.</small>
    </div>}
    <FlowLegend overview/>
    <p className="mesh-note">Drag circles to arrange · Click to inspect · Select “Selected application and neighbours” to focus · Double-click to open service flow · Scroll to zoom. Applications without observed connections are listed below. Search an APP code for a centred neighbourhood. Large maps keep readable text; drag to pan.</p>
    <div className="mesh-layout">
      <div className="mesh-canvas">
        {graph.nodes.length === 0 ? <p className="mesh-empty">No connected applications match this scope. Check the application list below or turn off “Connected applications only”.</p> : <ReactFlow key={JSON.stringify([layoutRevision,graph.nodes.map(node=>node.id).sort()])} nodes={displayNodes} onNodesChange={onNodesChange} edges={graph.edges} edgeTypes={meshEdgeTypes} autoPanOnNodeFocus={false} onNodeMouseEnter={(event,node)=>setHovered({id:node.id,x:event.clientX+16,y:event.clientY+16})} onNodeMouseLeave={()=>setHovered(null)} onMoveStart={()=>setHovered(null)} fitView fitViewOptions={{padding:0.12,minZoom:0.65,maxZoom:1}} minZoom={0.05} maxZoom={2} nodesDraggable={true} onNodeDragStart={()=>setHovered(null)} onNodeDragStop={(_event,node)=>{setHovered(null);setManualPositions(previous=>({...previous,[node.id]:node.position}));}} nodesConnectable={false} onNodeClick={(_event,node)=>{setHovered(null);setSelected(node.id);}} onNodeDoubleClick={(_event,node)=>onOpen(node.id)} onPaneClick={()=>setSelected('')}>
          <FitVisibleGraph identity={`${graph.nodes.map(item=>item.id).join(',')}:${layoutRevision}`} /><Background/><Controls showInteractive={false}/><MiniMap pannable zoomable/>
        </ReactFlow>}
      </div>
      {app && <aside className="mesh-side" aria-label="Application details">
        <Button onClick={()=>setSelected('')}>Close</Button><h2>{app.id}</h2>
        <p>{app.services.length} owned services · {incoming.length} upstream apps · {outgoing.length} downstream apps</p>
        <Button variant="emphasized" onClick={()=>onOpen(app.id)}>Open Application Flow →</Button>
        <h3>Live observed health · {(app.signals?.health ?? 'unknown').toUpperCase()}</h3>
        <p>{app.signals?.reportingServices ?? 0} / {app.services.length} services reporting in the last 5 minutes.</p>
        <p>{metric(app.signals?.requestsPerMinute,' req/min')} · {metric(app.signals?.latencyMs,' ms mean')} · {metric(app.signals?.errorRate,'% errors')}</p>
        <p className="mesh-note">Worst reporting service: critical at ≥5% errors or ≥1500 ms; warning at ≥1% or ≥700 ms. This is observed telemetry health, not Davis problem status. Missing samples do not prove health.</p>
        <EntityProperties observed={{'Application code':app.id,'Owned services':app.services.map(service=>service.id),'Grouping':'APP-tagged service inventory; not a separate entity'}}/>
        <h3>Receives calls from</h3>{incoming.length ? incoming.map(edge=><p key={edge.id}><button className="mesh-text-button" onClick={()=>setSelected(edge.source)}>{edge.source}</button> → {app.id}<small style={{display:"block"}}>{connectionLabel(edge)}</small><small style={{display:'block'}}>{connectionMetricLines(edge).join(' · ')}</small>{(edge.queues?.length??0)>1 && edge.queues?.map(queue=><small style={{display:"block"}} key={queue}>Via {queue}</small>)}</p>) : <p>No observed upstream application.</p>}
        <h3>Calls applications</h3>{outgoing.length ? outgoing.map(edge=><p key={edge.id}>{app.id} → <button className="mesh-text-button" onClick={()=>setSelected(edge.target)}>{edge.target}</button><small style={{display:"block"}}>{connectionLabel(edge)}</small><small style={{display:'block'}}>{connectionMetricLines(edge).join(' · ')}</small>{(edge.queues?.length??0)>1 && edge.queues?.map(queue=><small style={{display:"block"}} key={queue}>Via {queue}</small>)}</p>) : <p>No observed downstream application.</p>}
        <p className="mesh-note">Arrow direction represents calls; link metrics use matched request/response spans. Missing links can reflect missing APP tags or telemetry.</p>
      </aside>}
    </div>
    <details className="mesh-isolated-list" open={search.length>0?true:undefined}>
      <summary>Applications without observed connections · {isolatedApps.length} <small>Expand to inspect health and metrics</small></summary>
      <p className="mesh-note">These applications are in the inventory. No cross-application relationship was returned for this scope; this does not prove isolation.</p>
      <div className="mesh-isolated-grid">{isolatedApps.map(item=><button key={item.id} className="mesh-isolated-card" onClick={()=>{setSelected(item.id);setHovered(null);}}>
        <strong>{item.id}</strong><b style={{color:healthColours[item.signals?.health??'unknown']}}>● {(item.signals?.health??'unknown').toUpperCase()}</b>
        <span>{metric(item.signals?.requestsPerMinute,' req/min')}</span><span>{metric(item.signals?.latencyMs,' ms')} · {metric(item.signals?.errorRate,'% errors')}</span>
        <small>Inspect application →</small>
      </button>)}</div>
    </details>
    <p className="mesh-note">Request/response means a traced HTTP/RPC client/server relationship; it does not prove blocking application code. Link metrics count matched retained server spans between that pair of applications, with mean server duration; they are not end-to-end client latency. Missing link measurements show —, not zero. Request/response evidence refreshes when the scope changes or Refresh is clicked. Async links identify applications publishing/consuming the same broker destination, not confirmed individual message delivery. Type unknown means insufficient evidence. Moving dots illustrate observed connection direction; animation speed does not represent traffic volume. Metrics aggregate retained server/consumer spans across owned services, not unique end-user transactions; sampling can affect them. Application-to-application topology only. Internal calls are collapsed. Shared databases or queues do not imply an application connection. No observed connection does not prove isolation.</p>
    {(model.excludedServices > 0 || model.unmappedConnections > 0) && <p className="mesh-warning">Coverage: {model.excludedServices} services lack a single unambiguous APP tag; {model.unmappedConnections} relationships touching this scope could not be mapped at both ends.</p>}
  </>;
}
