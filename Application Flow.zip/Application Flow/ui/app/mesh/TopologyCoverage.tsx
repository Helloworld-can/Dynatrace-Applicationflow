import React from 'react';
import {TopologyModel} from '../types/observability';
import {EntityProperties} from './EntityProperties';

export function TopologyCoverage({model,timeframe,expectedIds}:{model:TopologyModel;timeframe:string;expectedIds?:string[]}){
  if(!model.coverage)return null;
  const individual=new Set<string>(),grouped=new Set<string>();
  for(const node of model.nodes){
    if(node.id.startsWith('app-scope:')||node.kind==='database'||node.kind==='messaging'||node.id.startsWith('rum:'))continue;
    const id=node.entityId??node.id;
    if(id.startsWith('SERVICE-'))individual.add(id);
    for(const service of node.services??[])if(service.id!==id)grouped.add(service.id);
  }
  const services=model.coverage.ownedServices;
  const found=new Set(services.map(service=>service.id));
  const expected=expectedIds?new Set(expectedIds):undefined;
  const missing=expectedIds?.filter(id=>!found.has(id))??[];
  const extra=expected?services.filter(service=>!expected.has(service.id)).map(service=>service.id):[];
  const count=(kind:'individual'|'grouped'|'list')=>services.filter(s=>kind==='individual'?individual.has(s.id):kind==='grouped'?!individual.has(s.id)&&grouped.has(s.id):!individual.has(s.id)&&!grouped.has(s.id)).length;
  return <details style={{margin:'8px 0',fontSize:12,maxWidth:900,pointerEvents:'auto',background:'white',position:'relative',zIndex:4}}>
    <summary>Service coverage: {services.length} discovered · {count('individual')} individual · {count('grouped')} grouped · {count('list')} list only · {model.warnings?.length?'Partial / warnings':'No query limits reported'}</summary>
    {expected&&<p role={missing.length||extra.length?'alert':undefined}>{missing.length||extra.length?`Inventory mismatch: ${missing.length} sidebar service IDs absent from topology discovery; ${extra.length} topology service IDs absent from sidebar inventory. Refresh and inspect tags/timeframe. IDs: ${[...missing,...extra].join(', ')}`:'Application service IDs match the sidebar inventory.'}</p>}
    <p>Counts cover the loaded application scope, before Focus service filtering. List-only services remain available below. No reported limits does not prove all tenant telemetry was captured. {model.coverage.relationshipPairs} observed service relationship pairs loaded.</p>
    <div style={{maxHeight:220,overflow:'auto',background:'white',padding:8}}>{services.map(service=><div key={service.id} style={{borderBottom:'1px solid #e1e8ee',padding:6}}><strong>{service.name}</strong> — {individual.has(service.id)?'Individual node':grouped.has(service.id)?'Grouped node':'List only'}<EntityProperties entityId={service.id} timeframe={timeframe}/></div>)}</div>
  </details>;
}
