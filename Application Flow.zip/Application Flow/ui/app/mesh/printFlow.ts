/** Print a frozen, fully fitted copy without changing the interactive viewport. */
export function printFlow(title: string, context: string): string | undefined {
  const source = document.querySelector<HTMLElement>('.mesh-page .react-flow');
  const viewport = source?.querySelector<HTMLElement>('.react-flow__viewport');
  const nodes = source?.querySelectorAll<HTMLElement>('.react-flow__node');
  if (!source || !viewport || !nodes?.length) return 'Wait for the flow to finish loading before printing.';
  const matrix = new DOMMatrix(getComputedStyle(viewport).transform);
  const origin = viewport.getBoundingClientRect();
  const bounds = [...source.querySelectorAll('.react-flow__node, .react-flow__edge-path, .react-flow__edge-textwrapper, .react-flow__edgelabel-renderer > *')]
    .map(element => element.getBoundingClientRect()).filter(rect => rect.width || rect.height);
  const left = Math.min(...bounds.map(rect => (rect.left - origin.left) / matrix.a));
  const top = Math.min(...bounds.map(rect => (rect.top - origin.top) / matrix.a));
  const right = Math.max(...bounds.map(rect => (rect.right - origin.left) / matrix.a));
  const bottom = Math.max(...bounds.map(rect => (rect.bottom - origin.top) / matrix.a));
  const preview = window.open('', '_blank');
  if (!preview) return 'Allow pop-ups for this app, then select Print / Save PDF again.';
  try {
    preview.opener = null;
    const doc = preview.document;
    doc.title = title;
    const style = doc.createElement('style');
    style.textContent = `@page{size:A4 landscape; margin:10mm}
body{margin:0; font:14px Arial,sans-serif; color:#163957; background:white}
h1{font-size:22px; margin:0 0 8px}
p{margin:0 0 10px}
.sheet{width:1100px; max-width:100%}
.diagram{width:1100px; height:650px; position:relative; overflow:hidden}
button{padding:10px 18px; margin:12px 0}
*{print-color-adjust:exact!important; -webkit-print-color-adjust:exact!important; animation:none!important; transition:none!important}
@media print{button,.instructions{display:none}
.sheet{width:277mm; max-width:none}
.diagram{zoom:0.95}
}
`; 
    doc.head.append(style);
    const sheet = doc.createElement('main'); sheet.className = 'sheet';
    const heading = doc.createElement('h1'); heading.textContent = title;
    const metadata = doc.createElement('p'); metadata.textContent = `${context} · Exported ${new Date().toLocaleString()} · Snapshot of current filtered flow`;
    const instructions = doc.createElement('p'); instructions.className = 'instructions';
    instructions.textContent = 'Select Print / Save PDF, then choose a printer or Save as PDF. Use landscape; for a dense flow, select A3 or a larger paper size. Close this tab to return to the live app.';
    const button = doc.createElement('button'); button.textContent = 'Print / Save PDF'; button.onclick = () => preview.print();
    const clone = source.cloneNode(true) as HTMLElement;
    const originals = [source, ...source.querySelectorAll<HTMLElement | SVGElement>('*')];
    const copies = [clone, ...clone.querySelectorAll<HTMLElement | SVGElement>('*')];
    originals.forEach((element, index) => {
      const computed = getComputedStyle(element);
      for (const property of computed) copies[index].style.setProperty(property, computed.getPropertyValue(property));
      copies[index].style.animation = 'none';
      copies[index].style.transition = 'none';
    });
    clone.querySelectorAll('.react-flow__panel, .react-flow__background, .react-flow__minimap').forEach(element => element.remove());
    Object.assign(clone.style, {width:'1100px',height:'650px',position:'relative',inset:'auto',background:'#fff',pointerEvents:'none'});
    const scale = Math.min(1060 / Math.max(1,right-left), 610 / Math.max(1,bottom-top), 1.5);
    const transform = `translate(${(1100-(right-left)*scale)/2-left*scale}px, ${(650-(bottom-top)*scale)/2-top*scale}px) scale(${scale})`;
    // Nodes, SVG edges and HTML edge labels share this viewport.
    clone.querySelectorAll<HTMLElement>('.react-flow__viewport').forEach(element => {
      element.style.transform = transform; element.style.transformOrigin = '0 0';
    });
    const diagram = doc.createElement('div'); diagram.className = 'diagram'; diagram.append(clone);
    sheet.append(heading,metadata,instructions,button,diagram); doc.body.replaceChildren(sheet);
    preview.focus();
    return undefined;
  } catch {
    preview.close();
    return 'The print preview could not be created. Try again once the flow has finished loading.';
  }
}
