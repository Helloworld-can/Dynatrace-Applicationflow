import {asString,DqlRecord} from '../hooks/query';
import {TopologyNode} from '../types/observability';

export function identityValue(value:unknown):string {
  const text=asString(value).trim();
  return /^(?:null|undefined|unknown(?: database)?|<unknown>|<host_unavailable>)$/i.test(text)?'':text;
}
export function databaseIdentity(system:string,namespace:string,server:string,emitter:string):string {
  // A namespace is qualified by its server; missing destination stays emitter-scoped.
  return `db:${JSON.stringify([identityValue(system).toLowerCase(),identityValue(namespace).toLowerCase(),identityValue(server).toLowerCase(),identityValue(server)?'':emitter])}`;
}
export function requestHost(address:unknown,url:unknown):string {
  let host=identityValue(address);
  try{if(identityValue(url))host=new URL(asString(url)).host||host;}catch{/* Keep the observed server address. */}
  return host;
}
export function endpointLabel(value:unknown):string {
  const raw=identityValue(value);
  if(!raw)return '';
  try{const url=new URL(raw);return `${url.host}${url.pathname}`;}catch{return raw.split(/[?#]/)[0];}
}
export function enrichServiceLabels(nodes:TopologyNode[],rows:DqlRecord[]):void {
  const byService=new Map<string,DqlRecord[]>();
  for(const row of rows){const id=asString(row.service_id),list=byService.get(id)??[];list.push(row);byService.set(id,list);}
  for(const node of nodes){
    const id=node.entityId??node.id;
    if(!id.startsWith('SERVICE-'))continue;
    const evidence=(byService.get(id)??[]).sort((a,b)=>Number(b.requests??0)-Number(a.requests??0));
    const endpoints=[...new Set([...evidence.flatMap(row=>Array.isArray(row.endpoints)?(row.endpoints as unknown[]).map(endpointLabel).filter(Boolean):[]),...evidence.map(row=>{
      const endpoint=endpointLabel(row.endpoint),host=requestHost(row.server_address,row.url),method=identityValue(row.method);
      if(!endpoint)return '';
      return `${method?`${method} `:''}${host?`${host}${endpoint.startsWith('/')?'':' · '}`:''}${endpoint}`;
    }).filter(Boolean)])];
    const hosts=[...new Set([...evidence.flatMap(row=>Array.isArray(row.hosts)?(row.hosts as unknown[]).map(identityValue).filter(Boolean):[]),...evidence.map(row=>requestHost(row.server_address,row.url)).filter(Boolean)])];
    const context=endpoints.length?endpoints:hosts;
    const original=node.label;
    node.details=[...(node.details??[]),`Service: ${original}`,'Endpoint and host samples: up to 20 each per service; totals cover all returned server spans. Raw URL paths are not grouped.',...endpoints.map(value=>`Observed endpoint: ${value}`),...hosts.map(value=>`Observed request host: ${value}`)];
    if(/localhost|127\.0\.0\.1|\[::1\]/i.test([original,...hosts].join(' ')))node.details.push('Localhost is a loopback/local server name reported by telemetry. It does not identify a separate business application.');
    if(!context.length)node.details.push('No endpoint/host evidence returned for this service in the selected timeframe.');
  }
}
