import React,{useEffect,useState} from 'react';
import {Button} from '@dynatrace/strato-components/buttons';
import {RumLinks} from './RumLinks';
import {asString,dqlString,runDql,DqlRecord} from '../hooks/query';
import {minutes} from './model';
import {FlowSymbol} from './FlowSymbols';
import {Health} from '../types/observability';
export function RumExperiencePanel({appCode,timeframe,onHealth,onLoadingChange}:{appCode?:string;timeframe:string;onHealth?:(health:Health)=>void;onLoadingChange?:(loading:boolean)=>void}) {
  const [state,setState]=useState<{row?:DqlRecord;query?:string;enabled?:boolean;error?:string}>({});
  const [revision,setRevision]=useState(0);
  useEffect(()=>{
    let cancelled=false;setState({});onLoadingChange?.(true);
    if(!appCode){setState({enabled:false});onLoadingChange?.(false);return;}
    void(async()=>{try{
      const checked=async(query:string)=>{const notices:string[]=[];const rows=await runDql(query,timeframe,s=>notices.push(s));if(notices.length)throw new Error(notices.join(' '));return rows;};
      const inventory=await Promise.all(['application','mobile_application','custom_application'].map(type=>checked(`fetch dt.entity.${type}\n| filter in(${dqlString(`APP:${appCode}`)}, tags)\n| fields id=toString(id)\n| limit 1000`)));
      if(inventory.some(rows=>rows.length>=1000))throw new Error('RUM inventory capped');
      const ids=inventory.flat().map(row=>asString(row.id)).filter(Boolean);
      const query=`fetch user.events, from:now()-${timeframe}\n| filter app.code == ${dqlString(appCode)} OR app_code == ${dqlString(appCode)}${ids.length?` OR in(dt.rum.application.entity,array(${ids.map(dqlString).join(',')}))`:''}`;
      const rows=await checked(`${query}\n| summarize events=count(), happy=countIf(experience.level == "satisfied"), tolerating=countIf(experience.level == "tolerating"), frustrated=countIf(experience.level == "frustrated"), errors=countIf(characteristics.has_error == true), requests=countIf(characteristics.has_request == true), failed_requests=countIf(characteristics.has_request == true AND characteristics.has_failed_request == true), latency=avg(if(characteristics.has_request == true,duration))/1ms`);
      if(!cancelled)setState({row:rows[0],query,enabled:ids.length>0||Number(rows[0]?.events??0)>0});
    }catch(error){if(!cancelled)setState({error:error instanceof Error?error.message:'RUM query unavailable'});}finally{if(!cancelled)onLoadingChange?.(false);}})();
    return()=>{cancelled=true;};
  },[appCode,timeframe,revision,onLoadingChange]);

  const n=(key:string)=>Number(state.row?.[key]??0);
  const classified=n('happy')+n('tolerating')+n('frustrated');
  const health=n('errors')>0||n('frustrated')>0?'critical':n('tolerating')>0?'warning':classified>0?'healthy':'unknown';
  useEffect(()=>{onHealth?.(health);},[health,onHealth]);
  if(state.enabled===false)return null;
  const color={critical:'#dc2626',warning:'#d69500',healthy:'#009768',unknown:'#718096'}[health];
  return <aside className="rum-experience-panel" aria-label="User experience" style={{borderTopColor:color}}>
    <FlowSymbol kind="rum" color={color}/><h3>User experience</h3><b style={{color}}>{health.toUpperCase()}</b><p>{appCode} · {timeframe}</p>
    {state.error?<p role="alert">{state.error}</p>:!state.row?<p>Checking RUM coverage…</p>:<>
      <div className="experience-faces"><div>🙂 Happy <b>{classified?n('happy'):'—'}</b></div><div>😐 Tolerating <b>{classified?n('tolerating'):'—'}</b></div><div>☹️ Frustrated <b>{classified?n('frustrated'):'—'}</b></div></div>
      {!classified&&<p>Experience classification unavailable.</p>}
      <dl><dt>Requests/min</dt><dd>{n('requests')?(n('requests')/minutes(timeframe)).toFixed(1):'No data'}</dd><dt>Mean request latency</dt><dd>{n('requests')&&state.row.latency!=null?`${n('latency').toFixed(1)} ms`:'No data'}</dd><dt>Failed requests</dt><dd>{n('requests')?`${(100*n('failed_requests')/n('requests')).toFixed(1)}%`:'No data'}</dd><dt>Error events</dt><dd>{n('events')?n('errors'):'No data'}</dd><dt>Saturation</dt><dd>Not applicable</dd></dl>
    </>}
    <RumLinks appCode={appCode} timeframe={timeframe}/><Button onClick={()=>setRevision(value=>value+1)}>Refresh experience</Button>
    <p className="mesh-note">APP-wide, all environments. Faces count classified events, not people. Red: any frustrated/error event; yellow: tolerating; green: satisfied with no detected errors. Unclassified events do not establish healthy experience.</p>
  </aside>;
}
