import {DqlRecord,dqlString,runDql} from '../hooks/query';
import {minutes} from './model';

/** Bound messaging discovery to relevant services and one fixed time window. */
export async function loadMessagingEvidence(
  serviceIds:string[], timeframe:string, cancelled:()=>boolean,
  publish:(rows:DqlRecord[])=>void, execute:typeof runDql=runDql,
  timeoutMs=120000,
):Promise<string[]> {
  const ids=[...new Set(serviceIds)].sort();
  if(!ids.length)return [];
  const end=Date.now();

  const pending:{ids:string[];from:number;to:number}[]=[];
  for(let i=0;i<ids.length;i+=100)pending.push({ids:ids.slice(i,i+100),from:end-minutes(timeframe)*60000,to:end});
  const controller=new AbortController();
  let stopped=false,attempts=0;
  const rows:DqlRecord[]=[],warnings=new Set<string>();
  let timer:ReturnType<typeof setTimeout>|undefined;
  const active=()=>!stopped&&!cancelled();
  const collect=async()=>{
    while(pending.length&&active()){
      if(attempts++>=64){warnings.add('Messaging discovery reached its query budget; remaining services were not checked.');break;}
      const task=pending.shift()!;const batch=task.ids;
      const window=`${new Date(task.from).toISOString()}/${new Date(task.to).toISOString()}`;
      const notices:string[]=[];
      try{
        const result=await execute(`fetch spans, timeframe: ${dqlString(window)}
| filter isNotNull(messaging.destination.name)
| fieldsAdd service_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))
| filter in(service_id, {${batch.map(dqlString).join(',')}})
| fields service_id,kind=span.kind,operation=messaging.operation.type,system=messaging.system,destination=messaging.destination.name,manager=messaging.destination.manager_name,address=server.address,port=toString(server.port)
| dedup service_id,kind,operation,system,destination,manager,address,port
| limit 10000`,timeframe,message=>notices.push(message),controller.signal);
        if(!active())break;
        if(result.length>=10000||notices.length){
          if(batch.length>1){const middle=Math.ceil(batch.length/2);pending.push({...task,ids:batch.slice(0,middle)},{...task,ids:batch.slice(middle)});continue;}
          if(task.to-task.from>60000){const middle=Math.floor((task.from+task.to)/2);pending.push({...task,to:middle},{...task,from:middle});continue;}
          warnings.add(`Messaging evidence incomplete for ${batch[0]}; that service was omitted. ${notices.join(' ')||'10,000-row cap reached.'}`);
          continue;
        }
        rows.push(...result);publish([...rows]);
      }catch(error){
        if(!active())break;
        warnings.add(`Messaging evidence incomplete; ${batch.length + pending.reduce((total,item)=>total+item.ids.length,0)} service checks did not complete: ${error instanceof Error?error.message:'Query failed'}`);
        pending.length=0;
        break;
      }
    }
    return [...warnings];
  };
  const deadline=new Promise<string[]>(resolve=>{
    timer=setTimeout(()=>{stopped=true;controller.abort();resolve([...warnings,'Messaging discovery timed out; completed batches were retained, but coverage is incomplete.']);},timeoutMs);
  });
  try{return await Promise.race([Promise.all([collect(),collect()]).then(()=>[...warnings]),deadline]);}
  finally{stopped=true;if(timer)clearTimeout(timer);controller.abort();}
}
