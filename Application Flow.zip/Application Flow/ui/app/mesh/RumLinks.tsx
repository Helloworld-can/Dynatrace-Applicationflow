import React,{useEffect,useState} from 'react';
import {Button} from '@dynatrace/strato-components/buttons';
import {asString,dqlString,runDql} from '../hooks/query';
import {openInvestigation,rumLink} from './investigationLinks';
export function RumLinks({appCode,timeframe}:{appCode?:string;timeframe:string}){
  const [state,setState]=useState<{names:string[];message:string}>({names:[],message:'Loading RUM frontend mapping…'});
  useEffect(()=>{
    let cancelled=false;
    setState({names:[],message:'Loading RUM frontend mapping…'});
    if(!appCode){setState({names:[],message:'No AppCode is available for RUM mapping.'});return;}
    const checked=async(query:string)=>{const warnings:string[]=[];const rows=await runDql(query,timeframe,message=>warnings.push(message));if(warnings.length||rows.length>=1000)throw new Error(warnings.join(' ')||'RUM inventory limit reached');return rows;};
    void Promise.all(['application','mobile_application','custom_application'].map(type=>checked(`fetch dt.entity.${type}\n| filter in(${dqlString(`APP:${appCode}`)}, tags)\n| fields name=entity.name\n| limit 1000`))).then(results=>{
      if(cancelled)return;
      const names=[...new Set(results.flat().map(row=>asString(row.name)).filter(Boolean))].sort();
      setState({names,message:names.length?'APP-tagged frontends · all environments':'No APP-tagged RUM frontend mapping found.'});
    }).catch((e:unknown)=>{if(!cancelled)setState({names:[],message:`RUM mapping unavailable: ${e instanceof Error?e.message:'Query failed'}`});});
    return()=>{cancelled=true;};
  },[appCode,timeframe]);
  return <div><small>{state.message}</small>{state.names.map(name=><Button key={name} disabled={!rumLink(name,timeframe)} onClick={()=>openInvestigation(rumLink(name,timeframe))}>Sessions · {name} ↗</Button>)}</div>;
}
