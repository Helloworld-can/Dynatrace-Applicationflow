import {useEffect,useState} from 'react';
import {stateClient} from '@dynatrace-sdk/client-state';
export const layoutColours=[
 {id:'blue',label:'Blue',start:'#163957',end:'#0e2645'},
 {id:'teal',label:'Teal',start:'#17545b',end:'#10383e'},
 {id:'purple',label:'Purple',start:'#503671',end:'#33224e'},
 {id:'burgundy',label:'Burgundy',start:'#71384e',end:'#472235'},
 {id:'light-pink',label:'Light pink',start:'#fce4ee',end:'#f3c8da'},
 {id:'green',label:'Green',start:'#24563c',end:'#153b29'},
 {id:'slate',label:'Slate',start:'#394b5c',end:'#253240'},
] as const;
const key='observability-layout-colour-v1';
export function useLayoutColour(){
 const [colour,setColour]=useState<string>('blue'),[loading,setLoading]=useState(true),[saving,setSaving]=useState(false),[message,setMessage]=useState(''),[saveFailed,setSaveFailed]=useState(false);
 useEffect(()=>{
  let cancelled=false;
  void stateClient.getUserAppStates({filter:`key = '${key}'`,addFields:'value'}).then(states=>{const value=states.find(state=>state.key===key)?.value;if(!cancelled&&value&&layoutColours.some(item=>item.id===value))setColour(value);}).catch(()=>{if(!cancelled)setMessage('Could not load your saved colour.');}).finally(()=>{if(!cancelled)setLoading(false);});
  return()=>{cancelled=true;};
 },[]);
 const choose=async(value:string)=>{
  if(!layoutColours.some(item=>item.id===value)||loading||saving)return;
  setColour(value);setSaving(true);setSaveFailed(false);setMessage('Saving…');
  try{await stateClient.setUserAppState({key,body:{value}});setMessage('Saved to your account');}
  catch{setMessage('Colour applied, but not saved to your account.');setSaveFailed(true);}
  finally{setSaving(false);}
 };
 return {colour,palette:layoutColours.find(item=>item.id===colour)??layoutColours[0],loading,saving,message,saveFailed,choose};
}
