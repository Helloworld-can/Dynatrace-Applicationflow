import React, { useState } from "react";
import { useAppCodes } from "../hooks/useAppCodes";

import { Flex } from "@dynatrace/strato-components/layouts";
import {
  Heading,
  Paragraph,
  Strong,
} from "@dynatrace/strato-components/typography";

const MetricCard = ({
  title,
  value,
  description,
}: {
  title: string;
  value: string;
  description: string;
}) => {
  return (
    <div
      style={{
        minWidth: "210px",
        flex: "1 1 210px",
        padding: "20px",
        border: "1px solid #3d4652",
        borderRadius: "8px",
      }}
    >
      <Paragraph>{title}</Paragraph>

      <div
        style={{
          fontSize: "32px",
          fontWeight: 700,
          margin: "8px 0",
        }}
      >
        {value}
      </div>

      <Paragraph>{description}</Paragraph>
    </div>
  );
};

const Section = ({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) => {
  return (
    <div
      style={{
        width: "100%",
        padding: "20px",
        border: "1px solid #3d4652",
        borderRadius: "8px",
      }}
    >
      <Heading level={3}>{title}</Heading>
      <div style={{ marginTop: "16px" }}>{children}</div>
    </div>
  );
};

export const Home = () => {
    const { appCodes, loading, error } = useAppCodes();
  const [selectedAppCode, setSelectedAppCode] = useState("ALL");
  return (
    <Flex
      flexDirection="column"
      gap={24}
      padding={32}
      alignItems="stretch"
    >
      {/* Header */}
      <div>
        <Heading>Executive Observability</Heading>

        <Paragraph>
          Business health, application experience and end-to-end
          observability across the enterprise.
        </Paragraph>
      </div>

      {/* Filters */}
      <Section title="Scope">
        <Flex gap={24} flexFlow="wrap">
          <div>
            <Strong>Business Category</Strong>
            <Paragraph>All Business Categories</Paragraph>
          </div>

        <div>
          <Strong>AppCode</Strong>

          <div style={{ marginTop: "8px" }}>
            {loading ? (
              <Paragraph>Loading AppCodes...</Paragraph>
            ) : error ? (
              <Paragraph>Unable to load AppCodes: {error}</Paragraph>
            ) : (
              <select
                value={selectedAppCode}
                onChange={(event) => setSelectedAppCode(event.target.value)}
                style={{
                  minWidth: "220px",
                  padding: "8px 12px",
                  borderRadius: "4px",
                }}
              >
                <option value="ALL">All Applications</option>

                {appCodes.map((app) => (
                  <option key={app.app_code} value={app.app_code}>
                    {app.app_code}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>

          <div>
            <Strong>Environment</Strong>
            <Paragraph>PROD</Paragraph>
          </div>

          <div>
            <Strong>Timeframe</Strong>
            <Paragraph>Last 30 minutes</Paragraph>
          </div>
        </Flex>
      </Section>

      {/* Executive KPIs */}
      <div>
        <Heading level={2}>Executive Health</Heading>

        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "16px",
            marginTop: "16px",
          }}
        >
          <MetricCard
            title="Healthy Applications"
            value="--"
            description="Applications operating normally"
          />

          <MetricCard
            title="Attention Required"
            value="--"
            description="Applications requiring investigation"
          />

          <MetricCard
            title="Critical"
            value="--"
            description="Applications with critical impact"
          />

          <MetricCard
            title="Active Problems"
            value="--"
            description="Current detected problems"
          />

          <MetricCard
            title="Applications"
            value="--"
            description="AppCodes in selected scope"
          />
        </div>
      </div>

      {/* Business Health */}
      <Section title="Business Category Health">
        <Paragraph>
          Business Category → AppCode health visualization will appear here.
        </Paragraph>
      </Section>

      {/* Golden Signals */}
      <Section title="Golden Signals">
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
            gap: "16px",
          }}
        >
          <MetricCard
            title="Availability"
            value="--"
            description="Service availability"
          />

          <MetricCard
            title="Traffic"
            value="--"
            description="Requests and transactions"
          />

          <MetricCard
            title="Errors"
            value="--"
            description="Request error rate"
          />

          <MetricCard
            title="Latency"
            value="--"
            description="Service response time"
          />
        </div>
      </Section>

      {/* User Experience */}
      <Section title="Digital User Experience">
        <Flex gap={24} flexFlow="wrap">
          <MetricCard
            title="User Sessions"
            value="--"
            description="RUM sessions"
          />

          <MetricCard
            title="Satisfied"
            value="--"
            description="Satisfied user experience"
          />

          <MetricCard
            title="Frustrated"
            value="--"
            description="Frustrated user experience"
          />

          <MetricCard
            title="User Errors"
            value="--"
            description="Frontend and user-action errors"
          />
        </Flex>
      </Section>

      {/* Dependency Flow */}
      <Section title="End-to-End Service Flow">
        <Paragraph>
          Application → Service → API → Database → MQ → External dependency
        </Paragraph>

        <Paragraph>
          Distributed traces and Smartscape relationships will populate this
          section.
        </Paragraph>
      </Section>

      {/* Coverage */}
      <Section title="Observability Coverage">
        <Paragraph>
          OneAgent | RUM | Synthetic | Logs | Traces | Database | MQ |
          Extensions
        </Paragraph>
      </Section>

      {/* RCA */}
      <Section title="Problems, Root Cause & Remediation">
        <Paragraph>
          Davis problems, impacted services, traces, correlated logs and
          remediation guidance will appear here.
        </Paragraph>
      </Section>
    </Flex>
  );
};