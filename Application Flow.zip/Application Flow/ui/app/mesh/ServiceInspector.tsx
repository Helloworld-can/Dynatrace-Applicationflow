import {serviceLink,hostLink,logsLink,syntheticLink,openInvestigation} from './investigationLinks';
import { InvestigationAreas } from './InvestigationAreas';
import React, { useEffect, useState } from 'react';
import { Button } from '@dynatrace/strato-components/buttons';
import { sendIntent } from '@dynatrace-sdk/navigation';
import { asString, dqlString, runDql, DqlRecord } from '../hooks/query';
import { minutes } from './model';

interface Signals { count?: number; errors?: number; latency?: number; p95?: number; cpu?: number }
const number = (value: unknown): number | undefined => {
  if (value === null || value === undefined) return undefined;
  const result = Number(value); return Number.isFinite(result) ? result : undefined;
};
const fmt = (value?: number, suffix = '') => value === undefined ? 'No data' : `${value.toLocaleString(undefined, {maximumFractionDigits:2})}${suffix}`;
export function ServiceInspector({ serviceId, name, appCode, timeframe }: {serviceId:string; name:string; appCode?:string; timeframe:string}) {
  const [signals, setSignals] = useState<Signals>({});
  const [hosts, setHosts] = useState<string[]>([]);
  const [monitors, setMonitors] = useState<{id:string; name:string; field:string}[]>([]);
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<string[]>([]);
  const serviceFilter = `coalesce(toString(dt.entity.service), toString(dt.smartscape.service)) == ${dqlString(serviceId)}`;
  const spans = `fetch spans, from:now()-${timeframe}\n| filter ${serviceFilter}`;

  useEffect(() => {
    let cancelled = false;
    setSignals({}); setHosts([]); setMonitors([]); setMessages([]); setLoading(true);
    void (async () => {
      const issues: string[] = [];
      const checked=async(query:string,window:string)=>{
        const notices:string[]=[];
        const rows=await runDql(query,window,message=>notices.push(message));
        if(notices.length)throw new Error(notices.join(' '));
        return rows;
      };
      const [metrics, hostResult, syntheticResults] = await Promise.all([
        checked(`${spans}\n| filter span.kind == "server" OR span.kind == "consumer"\n| summarize requests=count(), errors=countIf(request.is_failed == true OR lower(span.status_code) == "error"), latency=avg(duration)/1ms, p95=percentile(duration,95)/1ms`, timeframe)
          .catch((error: unknown): DqlRecord[] => { issues.push(`Signals: ${error instanceof Error ? error.message : 'query failed'}`); return []; }),
        checked(`${spans}\n| filter isNotNull(dt.entity.host)\n| fields id=toString(dt.entity.host)\n| dedup id\n| limit 1000`, timeframe)
          .catch((error: unknown): DqlRecord[] => { issues.push(`Host correlation: ${error instanceof Error ? error.message : 'query failed'}`); return []; }),
        appCode ? Promise.allSettled(['http_check', 'synthetic_test', 'multiprotocol_monitor'].map(type =>
          checked(`fetch dt.entity.${type}\n| filter in(${dqlString(`APP:${appCode}`)}, tags)\n| fields id=toString(id), name=entity.name\n| limit 500`, timeframe)
            .then(rows => rows.map(row => ({id:asString(row.id), name:asString(row.name), field:`dt.entity.${type}`}))))) : Promise.resolve([]),
      ]);
      const row = metrics[0];
      const count = number(row?.requests);
      const result: Signals = {count: count && count > 0 ? count : undefined,
        errors:count && count > 0 ? number(row?.errors) : undefined,
        latency:count && count > 0 ? number(row?.latency) : undefined,
        p95:count && count > 0 ? number(row?.p95) : undefined};
      const hostIds = hostResult.map(row => asString(row.id)).filter(Boolean);
      if (hostIds.length) {
        try {
          const cpu = await checked(`timeseries cpu=avg(dt.host.cpu.usage, scalar:true), by:{dt.entity.host}, filter:in(dt.entity.host, array(${hostIds.map(dqlString).join(',')}))\n| summarize cpu=max(cpu)`, timeframe);
          result.cpu = number(cpu[0]?.cpu);
        } catch (error) { issues.push(`CPU: ${error instanceof Error ? error.message : 'query failed'}`); }
      }
      if (hostIds.length >= 1000) issues.push('Host correlation reached its 1,000-host cap.');
      const associated: {id:string; name:string; field:string}[] = [];
      syntheticResults.forEach(item => {
        if (item.status === 'fulfilled') associated.push(...item.value);
        else issues.push(`Some synthetic inventory could not be queried: ${item.reason instanceof Error ? item.reason.message : 'query failed'}`);
      });
      if (associated.length >= 500) issues.push('Synthetic inventory may be capped.');
      if (!cancelled) { setSignals(result); setHosts(hostIds); setMonitors(associated); setMessages(issues); setLoading(false); }
    })();
    return () => { cancelled = true; };
  }, [serviceId, appCode, timeframe, spans]);
  const payloadTime = {'dt.timeframe':{from:`now-${timeframe}`,to:'now'}};
  return <section className="mesh-inspector" aria-label={`Golden signals for ${name}`}>
    <h3>{name}</h3><small>{serviceId}</small>
    <h4>Golden signals · {timeframe}</h4>
    {loading ? <p role="status">Loading service signals…</p> : <div className="signal-grid">
      <div><small>Traffic · observed requests/min</small><strong>{fmt(signals.count === undefined ? undefined : signals.count / minutes(timeframe))}</strong></div>
      <div data-health={(signals.latency??0)>=700?'critical':'unknown'}><small>Latency · mean / p95</small><strong>{fmt(signals.latency,' ms')} / {fmt(signals.p95,' ms')}</strong></div>
      <div data-health={(signals.errors??0)>0?'critical':'unknown'}><small>Errors · observed requests</small><strong>{fmt(signals.count && signals.errors !== undefined ? 100 * signals.errors / signals.count : undefined,'%')}</strong></div>
      <div data-health={(signals.cpu??0)>=90?'critical':'unknown'}><small>Saturation proxy · host CPU</small><strong>{fmt(signals.cpu,'%')}</strong></div>
    </div>}
    <p className="mesh-note">Traffic, errors and latency use retained server/consumer spans; sampling may affect results. CPU is the highest mean CPU of hosts linked by those spans, not service saturation.</p>
    <InvestigationAreas serviceId={serviceId} appCode={appCode} timeframe={timeframe} impacted={signals.count === undefined ? undefined : (signals.errors ?? 0)>0 || (signals.latency ?? 0)>=700} cpu={signals.cpu}/>
    <div className="mesh-actions">
      <Button onClick={() => openInvestigation(serviceLink(undefined,timeframe,serviceId))}>Service details ↗</Button>
      <Button onClick={() => openInvestigation(logsLink(appCode,timeframe,serviceId))}>Logs ↗</Button>
      <Button onClick={() => sendIntent({'dt.query':`${spans}\n| sort start_time desc\n| limit 1000`, ...payloadTime})}>Distributed traces ↗</Button>
    </div>
    <p className="mesh-note">Services, logs and host links open directly in a new tab. Trace queries use the Dynatrace chooser.</p>
    {hosts.length > 0 && <details><summary>Infrastructure · {hosts.length} linked hosts</summary>{hosts.map(id => <Button key={id} onClick={() => openInvestigation(hostLink(timeframe,id))}>{id} ↗</Button>)}</details>}
    <details><summary>Synthetic monitors · {monitors.length}</summary>
      <p className="mesh-note">APP:{appCode || 'unassigned'} tagged monitors. Application association does not prove that a monitor exercises this service.</p>
      {monitors.length === 0 && <p>No associated monitors returned.</p>}
      {appCode&&<Button onClick={()=>openInvestigation(syntheticLink(appCode,timeframe))}>Open application monitors ↗</Button>}
    </details>
    {messages.map(message => <p role="alert" className="mesh-warning" key={message}>{message}</p>)}
  </section>;
}
