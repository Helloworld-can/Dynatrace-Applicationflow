import { useEffect, useState } from "react";
import { asString, runDql } from "./query";

export interface AppCodeRecord {
  app_code: string;
  business_category?: string;
}

export const useAppCodes = () => {
  const [appCodes, setAppCodes] = useState<AppCodeRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadAppCodes = async () => {
      try {
        setLoading(true);
        setError(null);

        const query = `
          fetch dt.entity.service
          | fieldsAdd tags
          | expand tags
          | filter startsWith(tags, "APP:")
          | parse tags, "LD:'APP:' LD:app_code"
          | filter isNotNull(app_code)
          | fields app_code
          | dedup app_code
          | sort app_code asc
        `;

        const records = await runDql(query);

        const values: AppCodeRecord[] = records
          .map((record) => ({
            app_code: asString(record.app_code),
          }))
          .filter((record) => record.app_code.length > 0);

        setAppCodes(values);
      } catch (err) {
        console.error("Failed to load AppCodes", err);

        setError(
          err instanceof Error
            ? err.message
            : "Unable to retrieve AppCodes from Dynatrace.",
        );
      } finally {
        setLoading(false);
      }
    };

    void loadAppCodes();
  }, []);

  return {
    appCodes,
    loading,
    error,
  };
};