import {getAppVersion} from '@dynatrace-sdk/app-environment';
import {FlowPreferencesContext,FlowPreferenceControls,useSavedFlowPreferences} from '../mesh/FlowPreferences';
import {printFlow} from '../mesh/printFlow';
import {layoutColours,useLayoutColour} from '../mesh/useLayoutColour';
import {DataInfrastructure} from '../mesh/DataInfrastructure';
import React, { useState } from 'react';
import { Button } from '@dynatrace/strato-components/buttons';
import { ObservabilityFlow } from '../components/flow/ObservabilityFlow';
import { useApplicationTopology } from '../hooks/useApplicationTopology';
import { useMesh } from '../mesh/useMesh';
import { ApplicationMesh } from '../mesh/ApplicationMesh';
import { timeframes, ServiceOwner } from '../mesh/model';
import {WorkspaceIcon} from '../mesh/WorkspaceIcon';
import '../mesh/mesh.css';

function DetailFlow({appCode,environment,timeframe,services,toolbar}:{appCode:string;environment:string;timeframe:string;services:ServiceOwner[];toolbar:React.ReactNode}) {
  const topology = useApplicationTopology(appCode, environment, timeframe);
  return <>
    {topology.error && <p className="mesh-warning" role="alert">{topology.error}</p>}
    <ObservabilityFlow key={`${appCode}:${environment}:${timeframe}`} model={topology.data} loading={topology.loading} timeframe={timeframe} appCode={appCode} environment={environment} applicationServices={services} toolbar={toolbar}
      emptyText="No observed service topology returned for this application and environment."/>
  </>;
}
export const ApplicationFlow = () => {
  const [appVersion]=useState(()=>getAppVersion());
  const layout=useLayoutColour();
  const preferences=useSavedFlowPreferences();
  // Read entry parameters once; subsequent dropdown selections remain authoritative.
  const [entry] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    const app = (params.get('appCode') ?? '').trim();
    const environment = (params.get('environment') ?? '').trim();
    const tab = ['overview','application','databases','mq'].indexOf((params.get('tab') ?? '').trim().toLowerCase());
    return {app,environment,tab:tab >= 0 ? tab : app ? 1 : 0};
  });
  const [printError,setPrintError]=useState<string>();
  const [tab,setTab] = useState(entry.tab), [environment,setEnvironment] = useState(entry.environment || 'PROD'), [timeframe,setTimeframe] = useState('2h');
  const [appCode,setAppCode] = useState(entry.app), [detailEnvironment,setDetailEnvironment] = useState(entry.environment);
  const [revision,setRevision] = useState(0);
  const result = useMesh(environment,timeframe,revision,tab===0);
  const allApps = [...new Set(result.applicationServices.map(service=>service.app))].sort();
  const selectedApp = allApps.find(app=>app.toLowerCase()===appCode.toLowerCase()) || appCode || allApps[0] || '';
  const missingApp = !!appCode && !allApps.includes(selectedApp);
  const appServices = result.applicationServices.filter(service=>service.app === selectedApp);
  const detailEnvironments = [...new Set(appServices.flatMap(service=>service.environments))].sort();
  if (appServices.some(service=>service.environments.length === 0)) detailEnvironments.push('__APP_ONLY__');
  const currentEnvironment = detailEnvironment ? detailEnvironments.find(env=>env.toLowerCase()===detailEnvironment.toLowerCase()) || detailEnvironment : detailEnvironments.includes(environment) ? environment : detailEnvironments[0] || '';
  const missingEnvironment = !!currentEnvironment && !detailEnvironments.includes(currentEnvironment) && currentEnvironment !== 'ALL';
  const openApp = (app:string) => { setAppCode(app); setDetailEnvironment(environment === '__UNTAGGED__' ? '__APP_ONLY__' : environment); setTab(1); };
  const toolbar=<div className="mesh-toolbar workspace-filterbar">
    {tab===0?<label>Environment <select value={environment} onChange={e=>setEnvironment(e.target.value)}><option value="ALL">All environments</option>{[...new Set(['PROD',...result.environments])].map(item=><option key={item}>{item}</option>)}<option value="__UNTAGGED__">Not tagged</option></select></label>:<>
      <label>Application <select value={selectedApp} onChange={e=>{setAppCode(e.target.value);setDetailEnvironment('');}}>{missingApp&&<option value={selectedApp}>{selectedApp}</option>}{allApps.map(app=><option key={app}>{app}</option>)}</select></label>
      <label>Environment <select value={currentEnvironment} onChange={e=>setDetailEnvironment(e.target.value)}>{!detailEnvironments.includes(currentEnvironment)&&currentEnvironment&&<option value={currentEnvironment}>{currentEnvironment}</option>}{detailEnvironments.map(env=><option key={env} value={env}>{env==='__APP_ONLY__'?'APP only':env}</option>)}</select></label>
    </>}
    <label><WorkspaceIcon kind="latency" size={19}/><select aria-label="Timeframe" value={timeframe} onChange={e=>setTimeframe(e.target.value)}>{timeframes.map(item=><option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
    <Button disabled={result.loading} onClick={()=>setRevision(value=>value+1)}><WorkspaceIcon kind="refresh" size={18}/> Refresh</Button>
    <Button onClick={()=>setPrintError(printFlow(tab===0?'Application Overview':`${selectedApp} · Application flow`, `Environment: ${tab===0?environment:currentEnvironment} · Timeframe: ${timeframes.find(item=>item.value===timeframe)?.label || timeframe}`))}>Print / Save PDF</Button>
    {printError&&<span role="alert">{printError}</span>}
  </div>;
  return <FlowPreferencesContext.Provider value={preferences}><main data-layout-colour={layout.colour} style={{'--flow-font-size':`${preferences.settings.fontSize}px`,'--layout-colour-start':layout.palette.start,'--layout-colour-end':layout.palette.end} as React.CSSProperties} className={`mesh-page workspace-page ${tab===1?'workspace-application':''}`}>
    <header className="workspace-topbar"><div className="workspace-brand"><img src="./assets/Dynatrace_Logo.svg" alt="Dynatrace" width={34} height={34}/><h1>Application Observability</h1></div><nav aria-label="Observability views">{['Overview','Application','Databases','MQ'].map((name,index)=><Button key={name} aria-pressed={tab===index} onClick={()=>setTab(index)}>{name}</Button>)}</nav><div className="workspace-preferences"><details className="flow-preferences-menu personal-preferences-menu" onMouseLeave={event=>{event.currentTarget.open=false;}}><summary>Personal Preferences</summary><div className="personal-preferences-panel"><div className="layout-colour-picker"><label><i style={{background:layout.palette.start}} aria-hidden="true"/>Layout colour <select aria-label="Layout colour" value={layout.colour} disabled={layout.loading||layout.saving} onChange={e=>{void layout.choose(e.target.value);}}>{layoutColours.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select></label><small role="status">{layout.loading?'Loading preference…':layout.message||'Personal preference'}</small>{layout.saveFailed&&<Button onClick={()=>{void layout.choose(layout.colour);}}>Retry save</Button>}</div><FlowPreferenceControls value={preferences}/><small>Colour saves automatically. Use Save preferences for flow settings.</small></div></details></div></header>
    {result.error && <p className="mesh-warning" role="alert">Unable to load application inventory: {result.error}</p>}
    {tab>=2?<DataInfrastructure key={tab} resourceKind={tab===2?'database':'messaging'} services={result.services}/>:tab===0?<section className="workspace-overview" aria-label="Overview">{toolbar}
      {result.warnings.map(message=><p className={message.startsWith('Loading request/response')?'mesh-loading-status':'mesh-warning'} role={message.startsWith('Loading request/response')?'status':'alert'} key={message}>{message}</p>)}
      <div className="mesh-summary"><div>Applications<strong>{result.mesh.apps.length}</strong></div><div>Application connections<strong>{result.mesh.connections.length}</strong></div></div>
      {result.loading?<p role="status">Loading application ownership and connections…</p>:!result.error&&<ApplicationMesh key={`${environment}:${timeframe}:${revision}`} model={result.mesh} onOpen={openApp}/>}
    </section>:<section aria-label="Application workspace">
      {!result.loading&&missingApp?<>{toolbar}<p className="mesh-warning" role="alert">Application {selectedApp} was not found in the accessible inventory. Choose an application above.</p></>:!result.loading&&missingEnvironment?<>{toolbar}<p className="mesh-warning" role="alert">Environment {currentEnvironment} is not present in the discovered tags for {selectedApp}. Choose an available environment or APP only where offered.</p></>:!result.loading&&selectedApp&&currentEnvironment?<DetailFlow key={`${selectedApp}:${currentEnvironment}:${timeframe}:${revision}`} appCode={selectedApp} environment={currentEnvironment} timeframe={timeframe} services={appServices.filter(service=>currentEnvironment==='__APP_ONLY__'||currentEnvironment==='ALL'||service.environments.includes(currentEnvironment))} toolbar={toolbar}/>:<>{toolbar}<p className="mesh-empty">{result.loading?'Loading application inventory…':'No application inventory available for drilldown.'}</p></>}
    </section>}
    <footer className="workspace-footer"><span>{appVersion && appVersion!=='dt.missing.app.version'?`Version ${appVersion}`:'Development build'}</span><span>Powered by <strong>Dynatrace</strong></span></footer>
  </main></FlowPreferencesContext.Provider>;
};
