import {DqlRecord,runDql} from '../hooks/query';

/** Retain complete service batches; split capped responses instead of drawing partial ones. */
export async function topologyBatches(ids:string[],query:(ids:string[])=>string,timeframe:string,
  cancelled:()=>boolean,warn:(message:string)=>void,label:string,execute:typeof runDql=runDql):Promise<DqlRecord[]> {
  const unique=[...new Set(ids)].sort(),pending:string[][]=[];
  for(let i=0;i<unique.length;i+=50)pending.push(unique.slice(i,i+50));
  const rows:DqlRecord[]=[];
  const controller=new AbortController();
  let stopped=false,attempts=0,timer:ReturnType<typeof setTimeout>|undefined;
  const active=()=>!stopped&&!cancelled();
  const work=async()=>{
    while(pending.length&&active()){
      if(attempts++>=128){warn(`${label}: query budget reached; coverage is incomplete.`);break;}
      const batch=pending.shift()!,notices:string[]=[];
      try{
        const result=await execute(query(batch),timeframe,message=>notices.push(message),controller.signal);
        if(!active())break;
        if(result.length>=10000||notices.length){
          if(batch.length>1){const middle=Math.ceil(batch.length/2);pending.unshift(batch.slice(0,middle),batch.slice(middle));continue;}
          warn(`${label}: incomplete result for ${batch[0]} omitted. ${notices.join(' ')||'10,000-row cap reached.'}`);continue;
        }
        rows.push(...result);
      }catch(error){if(active())warn(`${label}: batch of ${batch.length} services failed: ${error instanceof Error?error.message:'Unknown error'}`);}
    }
    return rows;
  };
  const deadline=new Promise<DqlRecord[]>(resolve=>{timer=setTimeout(()=>{stopped=true;controller.abort();if(!cancelled())warn(`${label}: timed out; completed batches retained, coverage is incomplete.`);resolve(rows);},120000);});
  try{return await Promise.race([Promise.all([work(),work()]).then(()=>rows),deadline]);}finally{stopped=true;if(timer)clearTimeout(timer);controller.abort();}
}
