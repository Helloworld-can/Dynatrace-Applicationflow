import {
  queryExecutionClient,
} from "@dynatrace-sdk/client-query";

export type DqlRecord =
  Record<string, unknown>;

/* =========================================================
   SLEEP
========================================================= */

const sleep = (
  milliseconds: number,
): Promise<void> =>
  new Promise((resolve) => {
    setTimeout(
      resolve,
      milliseconds,
    );
  });

/* =========================================================
   RUN DQL
========================================================= */

export const runDql = async (
  query: string,
  timeframe?: string,
  onWarning?: (message: string) => void,
  signal?: AbortSignal,
): Promise<DqlRecord[]> => {
  signal?.throwIfAborted();
  const startedAt = Date.now();
  const match = timeframe ? /^(\d+)(m|h)$/.exec(timeframe) : null;
  if (timeframe && !match) throw new Error("Unsupported timeframe");
  const windowMs = match ? Number(match[1]) * (match[2] === "h" ? 3600000 : 60000) : 0;
  const bounds = windowMs ? {
    defaultTimeframeStart: new Date(startedAt - windowMs).toISOString(),
    defaultTimeframeEnd: new Date(startedAt).toISOString(),
  } : {};

  console.log(
    "Executing DQL:",
    query,
  );

  /*
   * Start query execution.
   */
  let response =
    await queryExecutionClient.queryExecute({
      abortSignal: signal,
      body: {
        query,
        maxResultRecords: 100000,
        ...bounds,
      },
    });

  console.log(
    "Initial Dynatrace query response:",
    response,
  );

  /* =======================================================
     IMMEDIATE SUCCESS
  ======================================================= */

  if (
    response.state ===
    "SUCCEEDED"
  ) {
    for (const notice of response.result?.metadata?.grail?.notifications ?? []) {
      if (notice.severity === "WARN" || notice.severity === "ERROR") onWarning?.(notice.message ?? notice.notificationType ?? "Query returned a warning; results may be partial.");
    }
    const records =
      response.result
        ?.records ?? [];

    console.log(
      "Dynatrace query completed immediately:",
      records.length,
      "records",
      `${Date.now() - startedAt} ms`,
    );

    return records as DqlRecord[];
  }

  /* =======================================================
     REQUEST TOKEN
  ======================================================= */

  const requestToken =
    response.requestToken;

  if (!requestToken) {
    throw new Error(
      `Dynatrace query returned state '${response.state}' without a request token.`,
    );
  }

  /*
   * Give Dynatrace substantially more time.
   *
   * 120 attempts * 2 seconds
   * = approximately 4 minutes maximum.
   *
   * This is intentionally generous while we establish
   * actual query execution times in the TEST tenant.
   */
  const maxAttempts = 120;
  const pollIntervalMs = 2000;

  /* =======================================================
     POLL
  ======================================================= */

  for (
    let attempt = 1;
    attempt <= maxAttempts;
    attempt += 1
  ) {
    await sleep(
      pollIntervalMs,
    );

    signal?.throwIfAborted();
    response =
      await queryExecutionClient.queryPoll({
        abortSignal: signal,
        requestToken,
      });

    const elapsedSeconds =
      Math.round(
        (
          Date.now() -
          startedAt
        ) / 1000,
      );

    console.log(
      `Dynatrace poll ${attempt}/${maxAttempts}:`,
      response.state,
      `(${elapsedSeconds}s)`,
    );

    /* =====================================================
       SUCCESS
    ===================================================== */

    if (
      response.state ===
      "SUCCEEDED"
    ) {
      for (const notice of response.result?.metadata?.grail?.notifications ?? []) {
      if (notice.severity === "WARN" || notice.severity === "ERROR") onWarning?.(notice.message ?? notice.notificationType ?? "Query returned a warning; results may be partial.");
    }
    const records =
        response.result
          ?.records ?? [];

      console.log(
        "Dynatrace query completed:",
        records.length,
        "records",
        `after ${elapsedSeconds}s`,
      );

      return records as DqlRecord[];
    }

    /* =====================================================
       STILL RUNNING
    ===================================================== */

    if (
      response.state ===
      "RUNNING"
    ) {
      continue;
    }

    /* =====================================================
       OTHER TERMINAL STATE
    ===================================================== */

    console.error(
      "Dynatrace query terminal response:",
      response,
    );

    throw new Error(
      `Dynatrace query failed with state '${response.state}'.`,
    );
  }

  const elapsedSeconds =
    Math.round(
      (
        Date.now() -
        startedAt
      ) / 1000,
    );

  throw new Error(
    `Dynatrace query timed out after ${elapsedSeconds} seconds while waiting for completion.`,
  );
};

/* =========================================================
   VALUE HELPERS
========================================================= */

export const asString = (
  value: unknown,
): string => {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  if (
    typeof value === "number" ||
    typeof value === "boolean" ||
    typeof value === "bigint" ||
    typeof value === "symbol"
  ) return String(value);

  // Keep the existing comma-separated representation for array values.
  if (Array.isArray(value)) return value.map(asString).join(",");
  if (value instanceof Date) return value.toString();

  // Serialize records explicitly instead of displaying [object Object].
  try {
    return JSON.stringify(value) ?? "";
  } catch {
    return "";
  }
};

export const asNumber = (
  value: unknown,
): number => {
  const number =
    Number(value);

  return Number.isFinite(
    number,
  )
    ? number
    : 0;
};

/* =========================================================
   DQL STRING ESCAPING
========================================================= */

export const dqlString = (
  value: string,
): string =>
  `"${value
    .replaceAll(
      "\\",
      "\\\\",
    )
    .replaceAll(
      '"',
      '\\"',
    )}"`;