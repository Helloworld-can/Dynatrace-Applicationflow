import {useFlowPreferences} from './FlowPreferences';
import React, {useState} from 'react';
import {routePath,RouteData} from './routedLayout';
import { useInternalNode, getBezierPath, BaseEdge, EdgeLabelRenderer, Edge, EdgeProps } from '@xyflow/react';
export type DataEdge = Edge<RouteData & { colour:string; motion:boolean; curvature:number; parallel?:boolean; aboveLabel?:string; belowLabel?:string; labelOffsetY?:number; labelSide?:'above'|'below'; circlePath?:{sx:number;sy:number;tx:number;ty:number} }>;
export function DataFlowEdge(props:EdgeProps<DataEdge>) {
  const {settings}=useFlowPreferences();
  const [hovered,setHovered]=useState(false);
  const dx=props.targetX-props.sourceX,dy=props.targetY-props.sourceY;
  const distance=Math.hypot(dx,dy)||1;
  // Opposite directed links use opposite normals, preserving two visible paths.
  const offset=props.data?.parallel?10:0;
  const nx=-dy/distance*offset,ny=dx/distance*offset;
  const sx=props.sourceX+nx,sy=props.sourceY+ny,tx=props.targetX+nx,ty=props.targetY+ny;
  const straightPath=`M${props.sourceX},${props.sourceY} L${sx},${sy} L${tx},${ty} L${props.targetX},${props.targetY}`;
  const curved=getBezierPath({sourceX:sx,sourceY:sy,targetX:tx,targetY:ty,sourcePosition:props.sourcePosition,targetPosition:props.targetPosition,curvature:0.35});
  const sourceNode=useInternalNode(props.source),targetNode=useInternalNode(props.target);
  let circle=props.data?.circlePath;
  // Overview nodes always use perimeter routing, including restored edge state.
  if(!circle&&(sourceNode?.measured.width??sourceNode?.width)===210&&(targetNode?.measured.width??targetNode?.width)===210)circle={sx:0,sy:0,tx:0,ty:0};
  if(circle&&sourceNode&&targetNode){
    const a=sourceNode.internals.positionAbsolute,b=targetNode.internals.positionAbsolute;
    const overview=(sourceNode.measured.width??sourceNode.width??180)>=200;
    const radius=overview?105:38,ox=overview?105:90,oy=overview?105:38;
    const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1;
    circle={sx:a.x+ox+dx/d*radius,sy:a.y+oy+dy/d*radius,tx:b.x+ox-dx/d*radius,ty:b.y+oy-dy/d*radius};
  }
  const bend=circle?Math.min(70,Math.hypot(circle.tx-circle.sx,circle.ty-circle.sy)*0.12):0;
  const length=circle?Math.hypot(circle.tx-circle.sx,circle.ty-circle.sy)||1:1;
  const cx=circle?(circle.sx+circle.tx)/2-(circle.ty-circle.sy)/length*bend:0;
  const cy=circle?(circle.sy+circle.ty)/2+(circle.tx-circle.sx)/length*bend:0;
  const path=circle?`M${circle.sx},${circle.sy} Q${cx},${cy} ${circle.tx},${circle.ty}`:props.data?.route?.length?routePath(props.data.route):(props.data?.curvature??0)>0?curved[0]:straightPath;
  const position=props.data?.labelPosition;
  const x=circle?(circle.sx+2*cx+circle.tx)/4:position?position.x+position.width/2:((props.data?.curvature??0)>0?curved[1]:(sx+tx)/2),y=circle?(circle.sy+2*cy+circle.ty)/4:position?position.y+position.height/2:((props.data?.curvature??0)>0?curved[2]:(sy+ty)/2)-24;
  const splitLabels=props.data?.aboveLabel!==undefined;
  // Offset vertical-link labels sideways so the line remains visible between the two blocks.
  const vertical=circle?Math.abs(circle.ty-circle.sy)>Math.abs(circle.tx-circle.sx)*2:false;
  const splitX=x+(vertical?130:0);
  const splitY=y+(circle?0:24);
  const gap=6;
  const splitStyle:React.CSSProperties={position:'absolute',fontSize:settings.fontSize,lineHeight:1.3,fontWeight:400,color:'#4679b8',background:'rgba(255,255,255,0.9)',padding:'1px 3px',whiteSpace:'pre-line',textAlign:'center',width:230,overflowWrap:'anywhere',opacity:props.style?.opacity,pointerEvents:'none'};
  const showLabel=props.data?.labelsVisible!==false||hovered||props.selected;
  return <>
    <g onMouseEnter={()=>setHovered(true)} onMouseLeave={()=>setHovered(false)}><title>{typeof props.label==='string'&&props.label?props.label:'No measured call metrics or protocol available'}</title><BaseEdge id={props.id} path={path} markerEnd={props.markerEnd} style={props.style}/></g>
    {splitLabels && showLabel && <EdgeLabelRenderer>
      <div className="nodrag nopan workspace-call-label" data-label-position="above" title={typeof props.label==='string'?props.label:undefined} style={{...splitStyle,transform:`translate(-50%, -100%) translate(${splitX}px,${splitY-gap}px)`}}>{props.data?.aboveLabel}</div>
      <div className="nodrag nopan workspace-call-label" data-label-position="below" style={{...splitStyle,transform:`translate(-50%, 0) translate(${splitX}px,${splitY+gap}px)`}}>{props.data?.belowLabel}</div>
    </EdgeLabelRenderer>}
    {!splitLabels && props.label && showLabel && <EdgeLabelRenderer><div className="nodrag nopan workspace-call-label" style={{position:'absolute',transform:`translate(-50%, -50%) translate(${x}px,${y}px)`,
      fontSize:settings.fontSize,lineHeight:1.3,fontWeight:400,color:'#244d75',background:'rgba(255,255,255,0.92)',textShadow:'1px 1px 2px white,-1px -1px 2px white',border:0,borderRadius:0,
      padding:'1px 3px',whiteSpace:'pre-line',textAlign:'center',width:position?.width,maxWidth:230,overflowWrap:'anywhere',opacity:props.style?.opacity,pointerEvents:'none'}}>{props.label}</div></EdgeLabelRenderer>}
    {settings.animation && props.data?.motion && <g className="mesh-flow-particles" pointerEvents="none" opacity={props.style?.opacity}>
      {[0,-2].map(begin=><path key={begin} d="M-6,-4 L6,0 L-6,4 Z" fill={props.data?.colour??'#79a8ed'}>
        <animateMotion dur="4s" begin={`${begin}s`} repeatCount="indefinite" path={path} rotate="auto"/>
      </path>)}
    </g>}
  </>;
}
export const meshEdgeTypes={dataFlow:DataFlowEdge};
