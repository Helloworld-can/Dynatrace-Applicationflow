import React,{useEffect,useState} from 'react';
import {DataResource} from './dataInventory';
import {CapacityReading,capacityMetrics,loadCapacity} from './resourceMetrics';
const display=(row:CapacityReading)=>row.value===undefined?'Unavailable':row.metric.unit==='bytes'?`${(row.value/1024**3).toLocaleString(undefined,{maximumFractionDigits:2})} GiB`:`${row.value.toLocaleString()} pages`;
export function DatabaseCapacity({item,timeframe}:{item:DataResource;timeframe:string}){
 const [rows,setRows]=useState<CapacityReading[]>([]),[loading,setLoading]=useState(true),[warnings,setWarnings]=useState<string[]>([]);
 useEffect(()=>{let cancelled=false;const controller=new AbortController();setRows([]);setWarnings([]);setLoading(true);void loadCapacity(item,timeframe,message=>{if(!cancelled)setWarnings(previous=>[...new Set([...previous,message])]);},controller.signal).then(result=>{if(!cancelled)setRows(result);}).catch(()=>{if(!cancelled)setWarnings(['Storage metrics could not be loaded. Check metric permissions and extension coverage.']);}).finally(()=>{if(!cancelled)setLoading(false);});return()=>{cancelled=true;controller.abort();};},[item,timeframe]);
 return <section className="database-capacity"><h3>Database storage / tablespace capacity</h3>
 <p className="mesh-note">Peak observed gauges in the selected timeframe, per metric series. Capacity, used and free peaks may occur at different times; they are not summed or used to calculate a utilization percentage.</p>
 {loading?<p role="status">Loading storage metrics…</p>:rows.length?<div className="capacity-metrics">{rows.map((row,index)=><article key={index}><small>{row.metric.label}</small><strong>{display(row)}</strong><p>{row.scope}</p><details><summary>Metric source</summary><code>{row.metric.key}</code></details></article>)}</div>:<p>{capacityMetrics(item.system).length?'Storage capacity unavailable for this endpoint.':'Storage metric mapping is not yet available for this database technology.'}</p>}
 {warnings.map(message=><p className="mesh-note" key={message}>{message}</p>)}
 </section>;
}
