import { DqlRecord, asString } from '../hooks/query';

export interface ServiceOwner { id: string; name: string; app: string; environments: string[] }
export interface AppNode { scopeNote?:string; id: string; services: ServiceOwner[]; signals?: import('./appSignals').AppSignals }
export interface ConnectionMetrics { incomplete?:boolean; requests:number; errors:number; successes?:number; unknown?:number; durationSumMs:number; durationSamples:number; requestsPerMinute:number; responseMs?:number; errorRate:number }
export interface AppConnection { scopeUnverified?:boolean; metrics?:ConnectionMetrics; queues?:string[]; requestResponse?:boolean; id: string; source: string; target: string; servicePairs: number }
export interface ApplicationMesh { connectionMetricsIncomplete?:boolean; metricsUpdatedAt?: number; metricsRefreshing?: boolean; metricsWarning?: string; apps: AppNode[]; connections: AppConnection[]; excludedServices: number; unmappedConnections: number }

export function tagValues(value: unknown, prefix: string): string[] {
  // Only exact APP:/ENV: tags. Never infer ownership from service/host names.
  const tags = Array.isArray(value) ? value : typeof value === 'string' ? [value] : [];
  return [...new Set(tags.filter((tag): tag is string => typeof tag === 'string')
    .filter(tag => tag.startsWith(prefix)).map(tag => tag.slice(prefix.length).trim()).filter(Boolean))];
}
/** Application membership is independent of unambiguous Overview ownership. */
export function applicationInventory(rows: DqlRecord[]): ServiceOwner[] {
  return rows.flatMap(row => {
    const id = asString(row.id);
    if (!id) return [];
    return tagValues(row.tags, 'APP:').map(app => ({
      id, name: asString(row.name) || id, app, environments: tagValues(row.tags, 'ENV:'),
    }));
  });
}
export function inventory(rows: DqlRecord[]): { services: ServiceOwner[]; excluded: number } {
  const services: ServiceOwner[] = [];
  let excluded = 0;
  for (const row of rows) {
    const apps = tagValues(row.tags, 'APP:');
    const id = asString(row.id);
    if (!id || apps.length !== 1) { excluded++; continue; }
    services.push({ id, name: asString(row.name) || id, app: apps[0], environments: tagValues(row.tags, 'ENV:') });
  }
  return { services, excluded };
}
export function buildMesh(services: ServiceOwner[], rows: DqlRecord[], environment: string, excludedServices = 0): ApplicationMesh {
  const eligible = services.filter(service => environment === 'ALL' ||
    (environment === '__UNTAGGED__' ? service.environments.length === 0 : service.environments.includes(environment)||service.environments.length===0));
  const owners = new Map(eligible.map(service => [service.id, service]));
  const apps = new Map<string, AppNode>();
  eligible.forEach(service => {
    const app = apps.get(service.app) ?? { id: service.app, services: [] };
    app.services.push(service);
    if(environment!=='ALL'&&environment!=='__UNTAGGED__'&&service.environments.length===0)app.scopeNote='Includes services without ENV — scope unverified';
    apps.set(app.id, app);
  });
  const connections = new Map<string, AppConnection>();
  const seen = new Set<string>();
  let unmappedConnections = 0;
  for (const row of rows) {
    const sourceId = asString(row.source_id), targetId = asString(row.target_id);
    const pair = JSON.stringify([sourceId, targetId]);
    if (seen.has(pair)) continue;
    seen.add(pair);
    const source = owners.get(sourceId), target = owners.get(targetId);
    if (!source || !target) { if (source || target) unmappedConnections++; continue; }
    if (source.app === target.app) continue;
    const id = JSON.stringify([source.app, target.app]);
    const edge = connections.get(id) ?? { id, source: source.app, target: target.app, servicePairs: 0 };
    if(environment!=='ALL'&&environment!=='__UNTAGGED__'&&(!source.environments.length||!target.environments.length))edge.scopeUnverified=true;
    edge.servicePairs++; connections.set(id, edge);
  }
  return { apps: [...apps.values()].sort((a, b) => a.id.localeCompare(b.id)),
    connections: [...connections.values()], excludedServices, unmappedConnections };
}

export const timeframes = [{value:'15m',label:'Last 15 minutes'}, {value:'30m',label:'Last 30 minutes'},
  {value:'1h',label:'Last hour'}, {value:'2h',label:'Last 2 hours'}, {value:'6h',label:'Last 6 hours'}, {value:'24h',label:'Last 24 hours'}];
export function minutes(value: string): number {
  const match = /^(\d+)(m|h)$/.exec(value);
  if (!match) throw new Error('Unsupported timeframe');
  return Number(match[1]) * (match[2] === 'h' ? 60 : 1);
}
