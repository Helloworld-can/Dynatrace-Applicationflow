import {DatabaseCapacity} from './DatabaseCapacity';
import {finite,mqIdentity,queueDepthQuery} from './resourceMetrics';
import {serviceLink,openInvestigation} from './investigationLinks';
import React,{useEffect,useMemo,useState} from 'react';
import {Button} from '@dynatrace/strato-components/buttons';
import {SimpleTable,SimpleTableColumnDef} from '@dynatrace/strato-components/tables';
import {sendIntent} from '@dynatrace-sdk/navigation';
import {asString,DqlRecord,dqlString,runDql} from '../hooks/query';
import {ServiceOwner,timeframes,minutes} from './model';
import {DataResource,inventoryQuery,resourcesFromRows,serviceScope,slowQueries} from './dataInventory';
import {DatabaseSetup} from './DatabaseSetup';
import {EntityProperties,propertyText} from './EntityProperties';
import {WorkspaceIcon} from './WorkspaceIcon';

const numberText=(value:number|undefined,suffix='')=>value===undefined?'—':`${value.toLocaleString(undefined,{maximumFractionDigits:1})}${suffix}`;
function ResourceDetails({item,timeframe,onClose}:{item:DataResource;timeframe:string;onClose:()=>void}) {
 const [threshold,setThreshold]=useState(700),[rows,setRows]=useState<DqlRecord[]>([]),[loading,setLoading]=useState(false),[error,setError]=useState(''),[depth,setDepth]=useState<number>();
 const query=item.kind==='database'?slowQueries(item,threshold):item.system==='mqseries'&&item.manager&&item.destination?`timeseries depth=max(ibmmq.queue.depth,scalar:true),by:{actual_qm_name,queue_name},filter:actual_qm_name == ${dqlString(item.manager)} AND queue_name == ${dqlString(item.destination)}\n| fields depth`:'';
 useEffect(()=>{
  let cancelled=false;setRows([]);setDepth(undefined);setError('');setLoading(Boolean(query));
  if(query)void runDql(query,timeframe,m=>{if(!cancelled)setError(m);}).then(result=>{if(cancelled)return;if(item.kind==='database')setRows(result);else {const value=result[0]?.depth;if(value!=null&&Number.isFinite(Number(value)))setDepth(Number(value));}}).catch((e:unknown)=>{if(!cancelled)setError(e instanceof Error?e.message:'Data unavailable');}).finally(()=>{if(!cancelled)setLoading(false);});
  return()=>{cancelled=true;};
 },[query,timeframe,item.kind]);
 const health=!item.calls?'unknown':item.errors/item.calls>=.05?'critical':item.errors/item.calls>=.01?'warning':'healthy';
 return <aside className="data-resource-details" aria-label={item.kind==='database'?'Database details':'Queue details'}><Button onClick={onClose}>Close</Button>
  <DatabaseSetup node={{id:item.id,label:item.name,kind:item.kind,health}} identity={{system:item.system,address:item.address,port:item.port,namespace:item.namespace}}/>
  <EntityProperties observed={item.properties}/>
  <div className="signal-grid">{item.kind==='messaging'&&<div><small>Peak queue depth</small><strong>{loading?'Loading…':depth===undefined?'Unavailable':numberText(depth)}</strong></div>}<div><small>Observed calls/min</small><strong>{numberText(item.calls/minutes(timeframe))}</strong></div><div><small>Mean operation time</small><strong>{numberText(item.durationCount?item.durationSum/item.durationCount:undefined,' ms')}</strong></div><div><small>Observed errors</small><strong>{numberText(item.calls?100*item.errors/item.calls:undefined,'%')}</strong></div></div>
  {item.kind==='database'&&<DatabaseCapacity item={item} timeframe={timeframe}/>}
  {item.kind==='database'?<section><h3>Slow query executions</h3><label>Minimum duration <select aria-label="Slow query threshold" value={threshold} onChange={e=>setThreshold(Number(e.target.value))}><option value={100}>100 ms</option><option value={700}>700 ms</option><option value={1000}>1 second</option><option value={5000}>5 seconds</option></select></label><p className="mesh-note">Up to 100 slowest retained client spans for this endpoint and emitting services. SQL text appears only when captured. These are completed observed executions, not currently running database sessions.</p>
   {loading?<p role="status">Loading slow queries…</p>:!rows.length?<p>No captured executions above this threshold.</p>:rows.map((row,i)=><article className="slow-query" key={i}><strong>{numberText(Number(row.duration_ms),' ms')}</strong><span> · {propertyText(row.start_time)}</span><pre>{asString(row.query)||'SQL text not captured'}</pre><small>{asString(row.operation)} · {asString(row.service_id)}</small>{asString(row.trace_id)&&<Button onClick={()=>sendIntent({'trace.id':asString(row.trace_id),'dt.timeframe':{from:`now-${timeframe}`,to:'now'}})}>Open trace</Button>}</article>)}
   <Button onClick={()=>sendIntent({'dt.query':query,'dt.timeframe':{from:`now-${timeframe}`,to:'now'}})}>Investigate queries ↗</Button>
  </section>:<section><h3>MQ information</h3><p>Broker / queue manager: {item.manager||item.address||'Unresolved'}</p><p>Destination: {item.destination||'Not captured'}</p><p>Peak queue depth: {loading?'Loading…':numberText(depth)}</p><p className="mesh-note">Depth requires IBM MQ extension metrics and an exact queue-manager/destination match. Messaging call counts include observed operations, not unique messages. No depth data does not mean an empty queue.</p></section>}
  {error&&<p role="alert" className="mesh-warning">{error}</p>}
  <h3>Emitting services</h3>{item.services.map(id=><div key={id}><Button onClick={()=>openInvestigation(serviceLink(undefined,timeframe,id))}>{id} ↗</Button><EntityProperties entityId={id} timeframe={timeframe}/></div>)}
 </aside>;
}
export function DataInfrastructure({services,resourceKind}:{services:ServiceOwner[];resourceKind:'database'|'messaging'}) {
 const database=resourceKind==='database';
 const title=database?'Databases':'Messaging queues';
 const [technology,setTechnology]=useState(''),[group,setGroup]=useState('');
 const [depths,setDepths]=useState<Map<string,number>>(new Map()),[depthLoading,setDepthLoading]=useState(false),[depthError,setDepthError]=useState('');
 const [app,setApp]=useState(''),[environment,setEnvironment]=useState('ALL'),[timeframe,setTimeframe]=useState('2h'),[revision,setRevision]=useState(0),[search,setSearch]=useState(''),[page,setPage]=useState(0);
 const [resources,setResources]=useState<DataResource[]>([]),[loading,setLoading]=useState(true),[warnings,setWarnings]=useState<string[]>([]),[selected,setSelected]=useState('');
 const scope=serviceScope(services,app,environment);
 useEffect(()=>{
  let cancelled=false;setResources([]);setWarnings([]);setSelected('');setGroup('');setLoading(true);setPage(0);
  void(async()=>{
   const issues:string[]=[];
   const results=await Promise.all([resourceKind].map(async type=>{try{
    const rows=await runDql(inventoryQuery(type,scope,technology),timeframe,m=>issues.push(`${type}: ${m}`));
    if(rows.length>=10000)issues.push(`${type}: reached the 10,000-row limit; inventory is incomplete or at the limit. Select an application/environment or shorter timeframe and refresh.`);
    return resourcesFromRows(rows,type);
   }catch(e){issues.push(`${type}: ${e instanceof Error?e.message:'Query failed'}`);return [];}}));
   if(!cancelled){setResources(results.flat());setWarnings(issues);setLoading(false);}
  })();return()=>{cancelled=true;};
 },[scope,timeframe,revision,resourceKind,technology]);
 const filtered=useMemo(()=>resources.filter(item=>(!technology||item.system===technology)&&`${item.name} ${item.system} ${item.address} ${item.manager}`.toLowerCase().includes(search.toLowerCase())),[resources,search,technology]);
 const groupId=(item:DataResource)=>JSON.stringify([item.system,item.manager||item.address||'Unresolved broker',item.manager?'':item.port]);
 const groups=useMemo(()=>{const grouped=new Map<string,{id:string;system:string;broker:string;count:number;calls:number}>();for(const item of filtered){const id=groupId(item);const current=grouped.get(id)??{id,system:item.system||'Unknown',broker:item.manager||`${item.address||'Unresolved broker'}${item.port?`:${item.port}`:''}`,count:0,calls:0};current.count++;current.calls+=item.calls;grouped.set(id,current);}return [...grouped.values()].sort((a,b)=>b.calls-a.calls);},[filtered]);
 const scoped=useMemo(()=>database?filtered:filtered.filter(item=>groupId(item)===group),[database,filtered,group]);
 const visible=useMemo(()=>scoped.slice(page*50,(page+1)*50),[scoped,page]);
 useEffect(()=>{
  let cancelled=false;setDepths(new Map());setDepthError('');
  const query=database?'':queueDepthQuery(visible);setDepthLoading(Boolean(query));
  if(query)void runDql(query,timeframe,m=>{if(!cancelled)setDepthError(m);}).then(rows=>{if(cancelled)return;const next=new Map<string,number>();for(const row of rows){const depth=finite(row.depth);if(depth!==undefined)next.set(mqIdentity(asString(row.actual_qm_name),asString(row.queue_name)),depth);}setDepths(next);}).catch(()=>{if(!cancelled)setDepthError('Queue depth unavailable. Check IBM MQ extension metrics and metric access.');}).finally(()=>{if(!cancelled)setDepthLoading(false);});
  return()=>{cancelled=true;};
 },[database,visible,timeframe,revision]);
 const groupColumns:SimpleTableColumnDef<(typeof groups)[number]>[]=[
  {id:'system',header:'Messaging technology',accessor:'system'},
  {id:'broker',header:'Queue manager / broker',accessor:'broker',cell:({rowData})=><Button onClick={()=>{setGroup(rowData.id);setPage(0);setSelected('');}}>{rowData.broker}</Button>},
  {id:'count',header:'Observed destinations',accessor:'count'},
  {id:'calls',header:'Operations/min',accessor:row=>numberText(row.calls/minutes(timeframe))},
 ];
 const displayRows=useMemo(()=>visible.map(row=>({...row,depthText:depthLoading?'Loading…':numberText(depths.get(mqIdentity(row.manager,row.destination)))})),[visible,depthLoading,depths]);
 const columns=useMemo<SimpleTableColumnDef<DataResource & {depthText:string}>[]>(()=>[
  {id:'name',header:database?'Database':'Queue / destination',accessor:'name',cell:({rowData})=><Button onClick={()=>setSelected(rowData.id)}><WorkspaceIcon kind={rowData.kind==='database'?'database':'queue'} size={18}/>{rowData.name}</Button>},
  {id:'system',header:'Technology',accessor:'system'},
  {id:'endpoint',header:database?'Endpoint':'Queue manager / broker',accessor:(row:DataResource)=>row.manager||`${row.address||'Unresolved'}${row.port?`:${row.port}`:''}`},
  {id:'services',header:'Services',accessor:(row:DataResource)=>row.services.length},
  {id:'calls',header:database?'Calls/min':'Operations/min',accessor:(row:DataResource)=>numberText(row.calls/minutes(timeframe))},
  {id:'response',header:'Mean operation',accessor:(row:DataResource)=>numberText(row.durationCount?row.durationSum/row.durationCount:undefined,' ms')},
  {id:'errors',header:'Error rate',accessor:(row:DataResource)=>numberText(row.calls?100*row.errors/row.calls:undefined,'%')},
 ...(!database?[{id:'depth',header:'Peak queue depth',accessor:(row:DataResource & {depthText:string})=>row.depthText}]:[]),
 ],[timeframe,database]);
 const item=resources.find(resource=>resource.id===selected);
 return <section className="data-infrastructure"><header><h2>{title}</h2><p>{database?'Observed database dependencies':'Observed queues grouped by technology and queue manager'} · selected timeframe</p></header>
 <div className="mesh-toolbar"><label>Application <select value={app} onChange={e=>{setApp(e.target.value);setPage(0);}}><option value="">All applications</option>{[...new Set(services.map(s=>s.app))].sort().map(code=><option key={code}>{code}</option>)}</select></label>
 <label>Environment <select value={environment} onChange={e=>setEnvironment(e.target.value)}><option value="ALL">All environments</option>{[...new Set(services.flatMap(s=>s.environments))].sort().map(env=><option key={env}>{env}</option>)}<option value="__APP_ONLY__">No ENV tag</option></select></label>
 <label>Timeframe <select value={timeframe} onChange={e=>setTimeframe(e.target.value)}>{timeframes.map(tf=><option value={tf.value} key={tf.value}>{tf.label}</option>)}</select></label><Button disabled={loading} onClick={()=>setRevision(v=>v+1)}>Refresh</Button></div>
 <p className="mesh-note">All applications / All environments includes accessible untagged span data. APP or ENV filters use tagged service ownership. Inventory is discovered from spans; idle or extension-only {database?'databases':'queues'} may not appear. Endpoint identity is kept separate by technology, namespace, address and port.</p>
 <div className="mesh-toolbar"><input aria-label={`Search ${title}`} placeholder="Search name, technology, endpoint…" value={search} onChange={e=>{setSearch(e.target.value);setPage(0);setSelected('');}}/><label>Technology <select aria-label="Resource technology" value={technology} onChange={e=>{setTechnology(e.target.value);setGroup('');setPage(0);setSelected('');}}><option value="">All technologies</option>{[...new Set([...(database?['oracle','postgresql','mysql','mssql','db2','mongodb']:['mqseries','activemq','msmq','rabbitmq','kafka']),...resources.map(item=>item.system)])].sort().map(value=><option key={value}>{value}</option>)}</select></label><span>{filtered.length} observed {database?'databases':'destinations'}</span>{!database&&group&&<Button onClick={()=>{setGroup('');setPage(0);setSelected('');}}>All queue managers</Button>}</div>
 {warnings.map((warning,i)=><p className="mesh-warning" role="alert" key={i}>{warning}</p>)}
 {!database&&<p className="mesh-note">Queue depth is the peak number of queued messages in the selected timeframe, matched by IBM MQ manager and queue name. Other technologies show — until a depth metric mapping is available. — means unavailable, not zero. Reused manager names across environments require additional metric scoping.</p>}{depthError&&<p className="mesh-warning">{depthError}</p>}
 <div className="data-infrastructure-content"><div className="data-infrastructure-list">{loading?<p role="status">{database?'Discovering databases…':'Discovering messaging queues…'}</p>:!database&&!group?groups.length?<><SimpleTable data={groups.slice(page*50,(page+1)*50)} columns={groupColumns}/><div className="mesh-toolbar"><Button disabled={page===0} onClick={()=>setPage(v=>v-1)}>Previous groups</Button><span>Page {page+1} of {Math.ceil(groups.length/50)}</span><Button disabled={(page+1)*50>=groups.length} onClick={()=>setPage(v=>v+1)}>Next groups</Button></div></>:<p>No messaging queues found in this scope.</p>:scoped.length?<><SimpleTable data={displayRows} columns={columns}/><div className="mesh-toolbar"><Button disabled={page===0} onClick={()=>setPage(v=>v-1)}>Previous</Button><span>Page {page+1} of {Math.ceil(scoped.length/50)}</span><Button disabled={(page+1)*50>=scoped.length} onClick={()=>setPage(v=>v+1)}>Next</Button></div></>:<p>No matching {database?'databases':'queues'} in this scope.</p>}</div>{item&&<ResourceDetails key={`${item.id}:${timeframe}`} item={item} timeframe={timeframe} onClose={()=>setSelected('')}/>}</div>
 </section>;
}
