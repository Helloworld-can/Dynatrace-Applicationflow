import React,{createContext,useContext,useEffect,useState} from 'react';
import {stateClient} from '@dynatrace-sdk/client-state';
export interface FlowSettings {fontSize:number;zoom:string;animation:boolean}
const defaults:FlowSettings={fontSize:12,zoom:'fit',animation:typeof window==='undefined'||!window.matchMedia('(prefers-reduced-motion: reduce)').matches};
const zooms=['fit','0.5','0.75','1','1.25','1.5','2'];
const key='observability-flow-preferences-v1';
export const FlowPreferencesContext=createContext({settings:defaults,change:(patch:Partial<FlowSettings>)=>{void patch;}});
export const useFlowPreferences=()=>useContext(FlowPreferencesContext);
export function useSavedFlowPreferences(){
 const [settings,setSettings]=useState(defaults),[loading,setLoading]=useState(true),[saving,setSaving]=useState(false),[message,setMessage]=useState('');
 useEffect(()=>{let cancelled=false;void stateClient.getUserAppStates({filter:`key = '${key}'`,addFields:'value'}).then(states=>{
  const result=states.find(state=>state.key===key);if(!result?.value)return;
  const v:unknown=JSON.parse(result.value);if(cancelled||!v||typeof v!=='object')return;
  const data=v as Record<string,unknown>;
  setSettings({fontSize:typeof data.fontSize==='number'&&[12,14,16,18].includes(data.fontSize)?data.fontSize:12,zoom:typeof data.zoom==='string'&&zooms.includes(data.zoom)?data.zoom:'fit',animation:typeof data.animation==='boolean'?data.animation:defaults.animation});
 }).catch(()=>{if(!cancelled)setMessage('Saved preferences could not be loaded.');}).finally(()=>{if(!cancelled)setLoading(false);});return()=>{cancelled=true;};},[]);
 const change=(patch:Partial<FlowSettings>)=>{if(loading||saving)return;setSettings(previous=>({...previous,...patch}));setMessage('Unsaved changes');};
 const save=async()=>{setSaving(true);try{await stateClient.setUserAppState({key,body:{value:JSON.stringify(settings)}});setMessage('Saved to your account');}catch{setMessage('Applied for this session; saving failed. Try Save preferences again.');}finally{setSaving(false);}};
 return {settings,change,loading,saving,message,save};
}
export function FlowPreferenceControls({value}:{value:ReturnType<typeof useSavedFlowPreferences>}){
 return <fieldset className="flow-preferences" disabled={value.loading||value.saving}><legend>Flow preferences</legend>
 <label>Font size <select aria-label="Flow font size" value={value.settings.fontSize} onChange={e=>value.change({fontSize:Number(e.target.value)})}>{[12,14,16,18].map(size=><option key={size} value={size}>{size} px</option>)}</select></label>
 <label>Starting zoom <select aria-label="Saved flow zoom" value={value.settings.zoom} onChange={e=>value.change({zoom:e.target.value})}>{zooms.map(zoom=><option key={zoom} value={zoom}>{zoom==='fit'?'Fit entire flow':`${Number(zoom)*100}%`}</option>)}</select></label>
 <label title="Moving arrows illustrate call direction, not individual requests or measured traffic speed."><input type="checkbox" checked={value.settings.animation} onChange={e=>value.change({animation:e.target.checked})}/> Animate traffic</label>
 <button onClick={()=>{void value.save();}}>Save preferences</button><span role="status">{value.loading?'Loading preferences…':value.saving?'Saving…':value.message}</span>
 </fieldset>;
}
