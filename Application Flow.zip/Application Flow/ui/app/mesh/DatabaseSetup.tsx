import React,{useEffect,useState} from 'react';
import {Button} from '@dynatrace/strato-components/buttons';
import {TopologyNode} from '../types/observability';
import {extensionsUrl} from './tenantLinks';
import {DatabaseIdentity,ConnectionResult,inspectDatabaseConnection} from './extensionConnection';
export function DatabaseSetup({node,identity}:{node:TopologyNode;identity?:DatabaseIdentity}) {
 const url=extensionsUrl();
 const [status,setStatus]=useState<ConnectionResult>(),[loading,setLoading]=useState(true),[revision,setRevision]=useState(0),[disconnect,setDisconnect]=useState(false);
 const detail=(prefix:string)=>node.details?.find(line=>line.startsWith(prefix))?.slice(prefix.length).trim()??'';
 const observedServer=detail('Server:');
 const endpoint=/^(?:\[([^\]]+)\]|([^:]+)):(\d+)$/.exec(observedServer);
 const system=identity?.system??detail('Technology:'),address=identity?.address??(endpoint?(endpoint[1]||endpoint[2]):observedServer),port=identity?.port??endpoint?.[3]??'',namespace=identity?.namespace??detail('Namespace:');
 useEffect(()=>{
  let cancelled=false;setStatus(undefined);setDisconnect(false);setLoading(true);
  if(node.kind!=='database'){setLoading(false);return;}
  void inspectDatabaseConnection({system,address,port,namespace}).then(result=>{if(!cancelled){setStatus(result);setLoading(false);}});
  return()=>{cancelled=true;};
 },[node.id,node.kind,system,address,port,namespace,revision]);
 const open=()=>{if(url)window.open(url,'_blank','noopener,noreferrer');};
 return <section className="mesh-inspector"><h3>{node.kind==='messaging'?'Messaging':'Database'} · {node.label}</h3>
  {node.kind==='database'?<>
   {loading?<p role="status">Checking extension configuration…</p>:<>
    <Button className={status?.state==='connected'?'extension-disconnect':status?.state==='disconnected'?'extension-connect':''} disabled={!url} onClick={()=>{if(status?.state==='connected')setDisconnect(true);else open();}}>{status?.state==='connected'?'Disconnect':status?.state==='disconnected'?'Connect':'Check configuration'}</Button>
    <p className="mesh-note">{status?.message}</p>
    <Button onClick={()=>setRevision(value=>value+1)}>Refresh connection status</Button>
   </>}
   {disconnect&&<div className="extension-confirm" role="region" aria-label="Disconnect database monitoring"><strong>Disconnect database monitoring</strong><p>Open Extensions and disable the matching endpoint. If a configuration includes other databases, keep those endpoints enabled. Nothing is changed until you confirm it in Extensions.</p>{status?.matches.map(match=><p key={`${match.extension}:${match.id}`}><code>{match.extension}</code><br/>Configuration: <code>{match.id}</code></p>)}<Button onClick={open}>Open Extensions to disconnect</Button><Button onClick={()=>setDisconnect(false)}>Cancel</Button></div>}
  </>:<><Button className="extension-connect" disabled={!url} onClick={open}>Connect</Button><p className="mesh-note">Messaging extension status is not verified. Review existing configurations in Extensions before adding one.</p></>}
  {!url&&<p className="mesh-note">Open this app in the Dynatrace tenant shell to configure extensions.</p>}
 </section>;
}
