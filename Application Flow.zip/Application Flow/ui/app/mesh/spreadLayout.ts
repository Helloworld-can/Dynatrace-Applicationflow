/** Deterministic force layout spreads fan-out across the canvas, not one tall tier. */
export function spreadPositions(ids:string[],edges:{source:string;target:string}[]):Map<string,{x:number;y:number}> {
  const ordered=[...ids].sort();
  const count=ordered.length,columns=Math.max(1,Math.ceil(Math.sqrt(count*1.65)));
  const width=Math.max(700,(columns-1)*250),height=Math.max(450,(Math.ceil(count/columns)-1)*220);
  const points=ordered.map((id,index)=>({id,x:(index%columns)*250-width/2,y:Math.floor(index/columns)*220-height/2}));
  const byId=new Map(points.map((p,i)=>[p.id,i]));
  const seen=new Set<string>();
  const links=edges.flatMap(edge=>{const a=byId.get(edge.source),b=byId.get(edge.target);if(a===undefined||b===undefined||a===b)return [];const key=[Math.min(a,b),Math.max(a,b)].join(':');if(seen.has(key))return [];seen.add(key);return [{a,b}];});
  const degree=points.map((_,i)=>links.filter(l=>l.a===i||l.b===i).length);
  for(let step=0;step<220;step++){
    const force=points.map(p=>({x:-p.x*.008,y:-p.y*.018}));
    for(let i=0;i<count;i++)for(let j=i+1;j<count;j++){
      const dx=points[i].x-points[j].x,dy=points[i].y-points[j].y,d=Math.max(1,Math.hypot(dx,dy));
      const push=75000/(d*d)+(d<210?(210-d)*.4:0);
      force[i].x+=dx/d*push;force[i].y+=dy/d*push;force[j].x-=dx/d*push;force[j].y-=dy/d*push;
    }
    for(const {a,b} of links){const dx=points[b].x-points[a].x,dy=points[b].y-points[a].y,d=Math.max(1,Math.hypot(dx,dy));const pull=(d-280)*.025/Math.sqrt(Math.max(degree[a],degree[b],1));force[a].x+=dx/d*pull;force[a].y+=dy/d*pull;force[b].x-=dx/d*pull;force[b].y-=dy/d*pull;}
    const cap=18*(1-step/220)+.5;
    points.forEach((p,i)=>{p.x+=Math.max(-cap,Math.min(cap,force[i].x));p.y+=Math.max(-cap,Math.min(cap,force[i].y));});
  }
  // Guarantee spacing for icons and multi-line service names after relaxation.
  for(let pass=0;pass<30;pass++)for(let i=0;i<count;i++)for(let j=i+1;j<count;j++){
    const dx=points[j].x-points[i].x,dy=points[j].y-points[i].y,d=Math.max(.001,Math.hypot(dx,dy));if(d<185){const shift=(185-d)/2;points[i].x-=dx/d*shift;points[i].y-=dy/d*shift;points[j].x+=dx/d*shift;points[j].y+=dy/d*shift;}
  }
  const minX=Math.min(0,...points.map(p=>p.x)),minY=Math.min(0,...points.map(p=>p.y));
  return new Map(points.map(p=>[p.id,{x:p.x-minX+40,y:p.y-minY+40}]));
}
