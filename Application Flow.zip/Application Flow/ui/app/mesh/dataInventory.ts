import {asString,DqlRecord,dqlString} from '../hooks/query';
import type {ServiceOwner} from './model';
export interface DataResource {
 id:string;kind:'database'|'messaging';name:string;system:string;address:string;port:string;namespace:string;manager:string;destination:string;
 services:string[];calls:number;errors:number;durationSum:number;durationCount:number;properties:DqlRecord;
}
export const databaseFields='system=coalesce(db.system,db.system.name),namespace=coalesce(db.namespace,db.name),address=server.address,port=toString(server.port)';
export const messagingFields='system=messaging.system,destination=messaging.destination.name,manager=messaging.destination.manager_name,address=server.address,port=toString(server.port)';
export function serviceScope(services:ServiceOwner[],app:string,env:string):string {
 if(!app&&env==='ALL')return 'true';
 const ids=services.filter(s=>(!app||s.app===app)&&(env==='ALL'||(env==='__APP_ONLY__'?s.environments.length===0:s.environments.includes(env)))).map(s=>s.id);
 return ids.length?`in(coalesce(toString(dt.entity.service),toString(dt.smartscape.service)),{${ids.map(dqlString).join(',')}})`:'false';
}
export function inventoryQuery(kind:DataResource['kind'],scope:string,technology=''):string {
 const database=kind==='database';
 return `fetch spans\n| filter ${scope}\n${technology?`| filter ${database?'coalesce(db.system,db.system.name)':'messaging.system'} == ${dqlString(technology)}\n`:''}| filter ${database?'span.kind == "client" AND (isNotNull(db.system) OR isNotNull(db.system.name) OR isNotNull(db.namespace))':'isNotNull(messaging.system) OR isNotNull(messaging.destination.name)'}\n| summarize calls=count(),errors=countIf(request.is_failed == true OR lower(span.status_code) == "error"),duration_sum=sum(duration)/1ms,duration_count=countIf(isNotNull(duration)),by:{service_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service)),${database?databaseFields:messagingFields}}\n| sort calls desc\n| limit 10000`;
}
export function resourcesFromRows(rows:DqlRecord[],kind:DataResource['kind']):DataResource[] {
 const map=new Map<string,DataResource>();
 for(const row of rows){
  const system=asString(row.system),namespace=asString(row.namespace),address=asString(row.address),port=asString(row.port),manager=asString(row.manager),destination=asString(row.destination),service=asString(row.service_id);
  // Missing endpoint identity must not merge similarly named dependencies across services.
  const id=JSON.stringify([kind,system,namespace,address,port,manager,destination,!address&&!manager?service:'']);
  const item=map.get(id)??{id,kind,name:namespace||destination||address||system||'Unresolved destination',system,namespace,address,port,manager,destination,services:[],calls:0,errors:0,durationSum:0,durationCount:0,properties:{}};
  if(service&&!item.services.includes(service))item.services.push(service);
  item.calls+=Number(row.calls)||0;item.errors+=Number(row.errors)||0;item.durationSum+=Number(row.duration_sum)||0;item.durationCount+=Number(row.duration_count)||0;
  item.properties={system,namespace,address,port,manager,destination,'Emitting services':item.services};map.set(id,item);
 }
 return [...map.values()].sort((a,b)=>b.calls-a.calls);
}
const equals=(field:string,value:string)=>value?`${field} == ${dqlString(value)}`:`isNull(${field}) OR ${field} == ""`;
export function resourceFilter(item:DataResource):string {
 const fields:('system'|'namespace'|'address'|'port'|'destination'|'manager')[]=item.kind==='database'?['system','namespace','address','port']:['system','destination','manager','address','port'];
 const identity=fields.map(field=>`(${equals(field,item[field])})`).join(' AND ');
 const services=item.services.length?`in(coalesce(toString(dt.entity.service),toString(dt.smartscape.service)),{${item.services.map(dqlString).join(',')}})`:'false';
 return `${identity} AND ${services}`;
}
export function slowQueries(item:DataResource,threshold:number):string {
 return `fetch spans\n| filter span.kind == "client"\n| fieldsAdd ${databaseFields}\n| filter ${resourceFilter(item)}\n| filter duration >= ${Math.max(0,Math.floor(threshold))}ms\n| fields start_time,query=coalesce(db.query.text,db.statement),operation=coalesce(db.operation.name,db.operation),duration_ms=duration/1ms,trace_id=toString(trace.id),service_id=coalesce(toString(dt.entity.service),toString(dt.smartscape.service))\n| sort duration_ms desc\n| limit 100`;
}
