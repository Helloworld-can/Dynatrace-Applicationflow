import {serviceLink,hostLink,logsLink,syntheticLink,openInvestigation} from './investigationLinks';
import React, { useEffect, useState } from 'react';
import { Button } from '@dynatrace/strato-components/buttons';
import {RumLinks} from './RumLinks';
import { asString, dqlString, runDql } from '../hooks/query';

type State = 'healthy' | 'critical' | 'unknown';
interface Area { state:State; detail:string; query?:string; targets?:{id:string;field:string}[] }
const unknown=(detail:string):Area=>({state:'unknown',detail});
export function InvestigationAreas({serviceId,appCode,timeframe,impacted,cpu}:{serviceId?:string;appCode?:string;timeframe:string;impacted?:boolean;cpu?:number}) {
  const [areas,setAreas]=useState<Record<string,Area>>({});
  const [revision,setRevision]=useState(0);
  const scope=serviceId?`coalesce(toString(dt.entity.service),toString(dt.smartscape.service)) == ${dqlString(serviceId)}`:appCode?`app.code == ${dqlString(appCode)} OR app_code == ${dqlString(appCode)}`:'false';
  const logs=`fetch logs, from:now()-${timeframe}\n| filter ${scope}`;

  useEffect(()=>{
    let cancelled=false;
    setAreas({});
    const checked=async(query:string)=>{
      const warnings:string[]=[];
      const rows=await runDql(query,timeframe,message=>warnings.push(message));
      if(warnings.length)throw new Error(warnings.join(' '));
      return rows;
    };
    const save=(key:string,area:Area)=>{if(!cancelled)setAreas(previous=>({...previous,[key]:area}));};
    const load=async(key:string,fn:()=>Promise<Area>)=>{try{save(key,await fn());}catch(error){save(key,unknown(`Unavailable: ${error instanceof Error?error.message:'query failed'}`));}};
    void load('Logs',async()=>{
      const rows=await checked(`${logs}\n| summarize total=count(), errors=countIf(in(upper(loglevel),array("ERROR","FATAL","SEVERE")))`);
      const total=Number(rows[0]?.total??0),errors=Number(rows[0]?.errors??0);
      return {state:errors>0?'critical':total>0?'healthy':'unknown',detail:total>0?`${errors} error logs / ${total} logs`:'No correlated logs',query:`${logs}\n| filter in(upper(loglevel),array("ERROR","FATAL","SEVERE"))\n| sort timestamp desc\n| limit 1000`};
    });
    void load('RUM',async()=>{
      if(!appCode)return unknown('No application mapping');
      const entities=await Promise.all(['application','mobile_application','custom_application'].map(type=>checked(`fetch dt.entity.${type}\n| filter in(${dqlString(`APP:${appCode}`)}, tags)\n| fields id=toString(id)\n| limit 1000`)));
      if(entities.some(rows=>rows.length>=1000))throw new Error('RUM inventory capped');
      const ids=entities.flat().map(row=>asString(row.id)).filter(Boolean);
      const query=`fetch user.events, from:now()-${timeframe}\n| filter app.code == ${dqlString(appCode)} OR app_code == ${dqlString(appCode)}${ids.length?` OR in(dt.rum.application.entity,array(${ids.map(dqlString).join(',')}))`:''}`;
      const rows=await checked(`${query}\n| summarize total=count(), errors=countIf(characteristics.has_error == true OR characteristics.has_failed_request == true OR characteristics.has_crash == true)`);
      const total=Number(rows[0]?.total??0),errors=Number(rows[0]?.errors??0);
      return {state:errors>0?'critical':total>0?'healthy':'unknown',detail:total>0?`${errors} error events / ${total} events`:'No correlated RUM events',query:`${query}\n| filter characteristics.has_error == true OR characteristics.has_failed_request == true OR characteristics.has_crash == true\n| limit 1000`};
    });
    void load('Synthetic',async()=>{
      if(!appCode)return unknown('No application mapping');
      const entities=await Promise.all(['http_check','synthetic_test','multiprotocol_monitor'].map(type=>checked(`fetch dt.entity.${type}\n| filter in(${dqlString(`APP:${appCode}`)}, tags)\n| fields id=toString(id)\n| limit 1000`)));
      if(entities.some(rows=>rows.length>=1000))throw new Error('Synthetic inventory capped');
      const ids=entities.flat().map(row=>asString(row.id)).filter(Boolean);
      if(!ids.length)return unknown('No APP-tagged monitors');
      const query=`fetch dt.davis.problems, from:now()-${timeframe}\n| filter event.status == "ACTIVE"\n| expand affected_entity_ids\n| filter in(affected_entity_ids,array(${ids.map(dqlString).join(',')}))`;
      const rows=await checked(`${query}\n| summarize problems=countDistinct(event.id)`);
      const count=Number(rows[0]?.problems??0);
      return {state:count>0?'critical':'unknown',detail:`${ids.length} monitors · ${count} active problems in window. Execution health not evaluated.`,query,targets:entities.flatMap((rows,index)=>rows.map(row=>({id:asString(row.id),field:`dt.entity.${['http_check','synthetic_test','multiprotocol_monitor'][index]}`})))};
    });
    return()=>{cancelled=true;};
  },[appCode,timeframe,logs,revision]);
  return <section className="investigation-section">
    <h4>Investigate <Button onClick={()=>setRevision(value=>value+1)}>Refresh checks</Button></h4>
    <div className="investigation-grid">
      <div className="investigation-card" data-health={impacted===undefined?'unknown':impacted?'critical':'healthy'}>
        <strong>Services / API</strong><b>{impacted===undefined?'Unknown':impacted?'Investigate':'No signal breach'}</b>
        <small>{serviceId?'Selected service':'Selected dependency · observed calls'}</small>
        <Button onClick={()=>openInvestigation(serviceLink(appCode,timeframe,serviceId))}>Open services ↗</Button>
      </div>
      {['Logs','RUM','Synthetic'].map(key=>{const area=areas[key];return <div key={key} className="investigation-card" data-health={area?.state??'unknown'}>
        <strong>{key}</strong><b>{!area?'Checking…':area.state==='critical'?'Investigate':area.state==='healthy'?'No errors observed':'Unknown'}</b>
        <small>{key==='Logs'&&serviceId?'Selected service':`Application ${appCode??'unmapped'} · all environments`}</small>
        <p>{area?.detail}</p>
        {key==='RUM'?<RumLinks appCode={appCode} timeframe={timeframe}/>:<Button disabled={key==='Synthetic'?!appCode:!appCode&&!serviceId} onClick={()=>openInvestigation(key==='Logs'?logsLink(appCode,timeframe,serviceId):syntheticLink(appCode!,timeframe))}>Open {key} ↗</Button>}

      </div>;})}
      <div className="investigation-card" data-health={cpu===undefined?'unknown':cpu>=90?'critical':'healthy'}><strong>Infrastructure</strong><b>{cpu===undefined?'Unknown':cpu>=90?'Investigate':'Below CPU threshold'}</b><p>{cpu===undefined?'No linked host CPU':`${cpu.toFixed(1)}% highest mean host CPU`}</p><small>Host links are available with service signals.</small><Button onClick={()=>openInvestigation(hostLink(timeframe))}>Open infrastructure · all hosts ↗</Button></div>
    </div>
    <p className="mesh-note">Red indicates evidence to investigate, not proven root cause. Logs: any ERROR/FATAL/SEVERE. RUM: any error, failed request or crash. Synthetic: active correlated Davis problems in this window; no problem does not prove successful executions. RUM and Synthetic are APP-wide checks. Refresh checks reloads these three areas.</p>
  </section>;
}
