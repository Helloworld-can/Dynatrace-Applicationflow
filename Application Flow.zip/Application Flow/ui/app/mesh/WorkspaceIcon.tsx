import React from 'react';
export type WorkspaceIconKind='application'|'services'|'hosts'|'logs'|'traces'|'synthetic'|'rum'|'traffic'|'latency'|'errors'|'cpu'|'database'|'queue'|'worker'|'refresh'|'proxy'|'gateway'|'loadbalancer'|'network'|'saas'|'external';
export function WorkspaceIcon({kind,size=24}:{kind:WorkspaceIconKind;size?:number}) {
  const shapes:Record<WorkspaceIconKind,React.ReactNode>={
    proxy:<><rect x="7" y="3" width="10" height="18" rx="2"/><path d="M1 8h10m-3-3 3 3-3 3M23 16H13m3-3-3 3 3 3"/></>,
    gateway:<><path d="M3 21V3h18v18M7 21V8h10v13M1 14h9m-3-3 3 3-3 3M14 14h9"/></>,
    loadbalancer:<><rect x="1" y="9" width="6" height="6" rx="1"/><rect x="17" y="2" width="6" height="5" rx="1"/><rect x="17" y="17" width="6" height="5" rx="1"/><path d="M7 12h5V4h5M12 12v8h5"/></>,
    network:<><rect x="2" y="7" width="20" height="10" rx="2"/><path d="M5 11v2m4-2v2m4-2v2m4-2v2M12 1v6m0 10v6M7 1h10M7 23h10"/></>,
    saas:<><path d="M6 19a5 5 0 1 1 0-10 7 7 0 0 1 13-2 6 6 0 0 1 0 12Z"/><path d="M9 13h7m-3-3 3 3-3 3"/></>,
    external:<><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2c6 5 6 15 0 20-6-5-6-15 0-20"/></>,
    application:<><path d="m12 2 6 3.5v7L12 16l-6-3.5v-7ZM6 5.5l6 3.5 6-3.5M12 9v7M6 9l-5 3v7l6 3.5 5-3M18 9l5 3v7l-6 3.5-5-3M1 12l6 3.5L12 13M7 15.5v7M23 12l-6 3.5L12 13M17 15.5v7"/></>,
    services:<><circle cx="12" cy="4" r="2.5"/><circle cx="4" cy="20" r="2.5"/><circle cx="20" cy="20" r="2.5"/><path d="M11 6 5 17m8-11 6 11M7 20h10"/></>,
    hosts:<><rect x="3" y="2" width="18" height="8" rx="2"/><rect x="3" y="14" width="18" height="8" rx="2"/><path d="M7 6h1m4 0h5M7 18h1m4 0h5"/></>,
    logs:<><path d="M6 2h9l4 4v16H6ZM14 2v5h5M9 11h7m-7 4h7m-7 4h5"/></>,
    traces:<><circle cx="5" cy="3" r="2"/><circle cx="5" cy="21" r="2"/><circle cx="18" cy="16" r="2"/><path d="M5 5v14m0-10h7c5 0 6 2 6 5"/></>,
    synthetic:<><rect x="2" y="3" width="20" height="14" rx="1"/><path d="M12 17v5m-5 0h10"/></>,
    rum:<><rect x="2" y="4" width="15" height="11" rx="1"/><path d="M9 15v5m-4 0h7"/><rect x="16" y="10" width="6" height="12" rx="1"/></>,
    traffic:<><path d="M5 21v-7m7 7V8m7 13V3"/></>,
    latency:<><circle cx="12" cy="12" r="9"/><path d="M12 6v7l4 2"/></>,
    errors:<><path d="m12 3 10 18H2ZM12 9v5m0 3v1"/></>,
    cpu:<><rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4m6-4v4M9 18v4m6-4v4M2 9h4m-4 6h4m12-6h4m-4 6h4"/><rect x="9" y="9" width="6" height="6"/></>,
    database:<><ellipse cx="12" cy="4" rx="8" ry="3"/><path d="M4 4v16c0 4 16 4 16 0V4M4 10c0 4 16 4 16 0M4 15c0 4 16 4 16 0"/></>,
    queue:<><rect x="1" y="5" width="22" height="14" rx="3"/><path d="M6 9v6m4-6v6m4-6v6m4-6v6"/></>,
    worker:<><path d="m9 3 1-2h4l1 2 3 2 2 0 2 4-1 2v3l1 2-2 4h-3l-2 2H9l-2-2H4l-2-4 1-2v-3L2 9l2-4h3Z"/><circle cx="12" cy="12" r="4"/></>,
    refresh:<><path d="M20 8a9 9 0 1 0 0 9M20 2v6h-6"/></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round">{shapes[kind]}</svg>;
}
