import {
  useEffect,
  useState,
} from "react";

import {
  asNumber,
  asString,
  dqlString,
  runDql,
} from "./query";

export type EnvironmentItem = {
  environment: string;
  service_count: number;
};

export const useEnvironments = (
  appCode: string,
) => {
  const [environments, setEnvironments] =
    useState<EnvironmentItem[]>([]);

  const [loading, setLoading] =
    useState(false);

  const [error, setError] =
    useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      if (
        !appCode ||
        appCode === "ALL"
      ) {
        setEnvironments([]);
        setLoading(false);
        setError(null);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const appTag =
          dqlString(
            `APP:${appCode}`,
          );

        const query = `
fetch dt.entity.service
| filter contains(
    toString(tags),
    ${appTag}
  )
| expand tags
| filter startsWith(
    tags,
    "ENV:"
  )
| fieldsAdd Environment = replaceString(
    tags,
    "ENV:",
    ""
  )
| summarize
    Services=count(),
    by:{Environment}
| sort Environment asc
`;

        const rows =
          await runDql(query);

        const discovered:
          EnvironmentItem[] = [];

        for (const row of rows) {
          const environment =
            asString(
              row.Environment,
            )
              .trim()
              .toUpperCase();

          if (!environment) {
            continue;
          }

          discovered.push({
            environment,
            service_count:
              asNumber(
                row.Services,
              ),
          });
        }

        if (!cancelled) {
          setEnvironments(
            discovered,
          );
        }
      } catch (caught) {
        console.error(
          "Environment discovery failed",
          caught,
        );

        if (!cancelled) {
          setEnvironments([]);

          setError(
            caught instanceof Error
              ? caught.message
              : "Unable to discover environments.",
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void load();

    return () => {
      cancelled = true;
    };
  }, [appCode]);

  return {
    environments,
    loading,
    error,
  };
};