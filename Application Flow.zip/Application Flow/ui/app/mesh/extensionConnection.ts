import {extensionsClient} from '@dynatrace-sdk/client-extensions-v2';
export interface DatabaseIdentity {system:string;address:string;port:string;namespace:string}
export interface ConnectionMatch {extension:string;id:string}
export interface ConnectionResult {state:'connected'|'disconnected'|'unknown';matches:ConnectionMatch[];message:string}
const record=(v:unknown):Record<string,unknown>|undefined=>v!==null&&typeof v==='object'&&!Array.isArray(v)?v as Record<string,unknown>:undefined;
const text=(v:unknown)=>typeof v==='string'?v.trim():typeof v==='number'?String(v):'';
const field=(r:Record<string,unknown>,keys:string[])=>keys.map(k=>text(r[k])).find(Boolean)??'';
const host=(s:string)=>s.trim().toLowerCase().replace(/\.$/,'');
const technologies:Record<string,RegExp>={oracle:/oracle/i,postgresql:/postgres/i,postgres:/postgres/i,mysql:/mysql/i,mariadb:/mariadb|mysql/i,mssql:/sql.?server|mssql/i,'microsoft sql server':/sql.?server|mssql/i,'sql server':/sql.?server|mssql/i,db2:/db2/i,mongodb:/mongo/i,redis:/redis/i};
// Only explicit endpoint fields count; labels and description text never establish ownership.
export function matchConfiguration(value:unknown,identity:DatabaseIdentity):'match'|'none'|'unknown'{
 const root=record(value);if(!root)return 'unknown';if(root.enabled===false)return 'none';
 let matched=false,uncertain=root.enabled!==true,seen=false;
 const walk=(v:unknown,enabled:boolean|undefined,depth:number)=>{
  if(depth>12){uncertain=true;return;}
  if(Array.isArray(v)){v.forEach(x=>walk(x,enabled,depth+1));return;}
  const r=record(v);if(!r)return;
  const active=enabled===false?false:typeof r.enabled==='boolean'?r.enabled:enabled;
  if(active===false){seen=true;return;}
  const address=field(r,['host','hostname','hostName','serverAddress','address','server']);
  if(address){
   seen=true;if(host(address)!==host(identity.address))return;
   const port=field(r,['port']),namespace=field(r,['database','databaseName','dbname','serviceName','sid','SID']);
   if(port&&identity.port&&port!==identity.port)return;
   if(namespace&&identity.namespace&&namespace!==identity.namespace)return;
   // Same host alone cannot distinguish multiple database instances.
   if(active!==true||!port||!identity.port||!namespace||!identity.namespace){uncertain=true;return;}
   matched=true;return;
  }
  for(const [key,child] of Object.entries(r))if(!/password|credential|secret|token|auth/i.test(key))walk(child,active,depth+1);
 };
 walk(root,undefined,0);
 return matched?'match':uncertain||!seen?'unknown':'none';
}
export async function inspectDatabaseConnection(identity:DatabaseIdentity):Promise<ConnectionResult>{
 const unknown=(message:string):ConnectionResult=>({state:'unknown',matches:[],message});
 const technology=technologies[identity.system.trim().toLowerCase()];
 if(!technology||!identity.address)return unknown('Endpoint identity or supported database technology is missing. Review monitoring configuration in Extensions.');
 const matches:ConnectionMatch[]=[];let uncertain=false;
 try{
  let pageKey:string|undefined;let pages=0;
  do{
   if(++pages>50)return unknown('Extension inventory is incomplete. Review configuration in Extensions.');
   const page=await extensionsClient.listExtensions(pageKey?{pageKey}:{pageSize:100,addFields:'keywords'});
   for(const extension of page.items){
    if(!technology.test(`${extension.extensionName} ${(extension.keywords??[]).join(' ')}`))continue;
    let configPage:string|undefined;let configPages=0;
    do{
     if(++configPages>50)return unknown('Monitoring configuration inventory is incomplete.');
     const configs=await extensionsClient.listExtensionMonitoringConfigurations(configPage?{extensionName:extension.extensionName,pageKey:configPage}:{extensionName:extension.extensionName,pageSize:500});
     for(const config of configs.items){
      const result=matchConfiguration(config.value,identity);
      if(result==='match')matches.push({extension:extension.extensionName,id:config.objectId});
      if(result==='unknown')uncertain=true;
     }
     configPage=configs.nextPageKey;
    }while(configPage);
   }
   pageKey=page.nextPageKey;
  }while(pageKey);
 }catch{return unknown('Unable to verify extension configuration. Check extensions read permissions or review in Extensions.');}
 if(matches.length)return {state:'connected',matches,message:'Enabled monitoring configuration matched to this endpoint. This is configuration status, not database health.'};
 return uncertain?unknown('Some configurations could not be matched reliably. Review in Extensions before connecting.'):{state:'disconnected',matches:[],message:'No matching enabled configuration found among accessible extensions identified for this database technology.'};
}
