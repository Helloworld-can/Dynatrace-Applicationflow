import {serviceLink,hostLink,logsLink,syntheticLink,openInvestigation} from './investigationLinks';
import {EntityProperties} from './EntityProperties';
import React, {useEffect, useState} from 'react';
import {Button} from '@dynatrace/strato-components/buttons';
import {sendIntent} from '@dynatrace-sdk/navigation';
import {asString, dqlString, DqlRecord, runDql} from '../hooks/query';
import type {ComponentService} from '../types/observability';
import {WorkspaceIcon} from './WorkspaceIcon';
import {ServiceOwner, minutes} from './model';

const fmt=(value:number|undefined,suffix='')=>value===undefined?'—':`${value.toLocaleString(undefined,{maximumFractionDigits:1})}${suffix}`;
export function applicationSignals(row?:DqlRecord) {
  const n=(key:string)=>{const value=row?.[key]==null?undefined:Number(row[key]);return value!==undefined&&Number.isFinite(value)?value:undefined;};
  const count=n('requests');
  if(!count||!Number.isFinite(count))return {};
  const errors=n('errors'),good=n('good');
  return {count,score:good===undefined?undefined:100*good/count,errorRate:errors===undefined?undefined:100*errors/count,mean:n('mean'),p95:n('p95')};
}
export function ApplicationSidebar({appCode,environment,timeframe,services,architectureServices,flowLoading,children,onLoadingChange}:{appCode:string;environment:string;timeframe:string;services:ServiceOwner[];architectureServices?:ComponentService[];flowLoading?:boolean;children:React.ReactNode;onLoadingChange?:(loading:boolean)=>void}) {
  const [state,setState]=useState<{row?:DqlRecord;hosts?:string[];cpu?:number;issues:string[];loading:boolean}>({issues:[],loading:true});
  const listedServices=services;
  const connectedServices=(architectureServices??[]).filter(item=>!services.some(owned=>owned.id===item.id));
  const ids=services.map(s=>s.id).sort();
  const filter=ids.length?`in(coalesce(toString(dt.entity.service),toString(dt.smartscape.service)),{${ids.map(dqlString).join(',')}})`:'false';
  const spans=`fetch spans\n| filter ${filter}`;
  useEffect(()=>{
    let cancelled=false;setState({issues:[],loading:true});onLoadingChange?.(true);
    void(async()=>{
      const issues:string[]=[];
      const checked=async(query:string):Promise<DqlRecord[]|undefined>=>{try{const notices:string[]=[];const rows=await runDql(query,timeframe,m=>notices.push(m));if(notices.length)throw new Error(notices.join(' '));if(rows.length>=1000)throw new Error('Result capped; data omitted');return rows;}catch(e){issues.push((e instanceof Error?e.message:'Query unavailable').slice(0,300));return undefined;}};
      const [metrics,hostRows]=await Promise.all([
        checked(`${spans}\n| filter span.kind == "server"\n| fieldsAdd failed=coalesce(request.is_failed,false) OR coalesce(lower(span.status_code) == "error",false)\n| summarize requests=count(),errors=countIf(failed),good=countIf(NOT failed AND duration < 700ms),mean=avg(duration)/1ms,p95=percentile(duration,95)/1ms`),
        checked(`${spans}\n| filter isNotNull(dt.entity.host)\n| fields id=toString(dt.entity.host)\n| dedup id\n| limit 1000`),
      ]);
      if(cancelled)return;
      const hosts=hostRows?.map(row=>asString(row.id)).filter(Boolean);
      setState({row:metrics?.[0],hosts,issues:[...issues],loading:true});
      const cpuRows=hosts?.length?await checked(`timeseries cpu=avg(dt.host.cpu.usage,scalar:true),by:{dt.entity.host},filter:in(dt.entity.host,array(${hosts.map(dqlString).join(',')}))\n| summarize cpu=max(cpu)`):undefined;
      const cpu=cpuRows?.[0]?.cpu==null?undefined:Number(cpuRows[0].cpu);
      if(!cancelled){setState({row:metrics?.[0],hosts,cpu,issues,loading:false});onLoadingChange?.(false);}
    })();return()=>{cancelled=true;};
  },[spans,timeframe,onLoadingChange]);
  const signals=applicationSignals(state.row);
  const time={'dt.timeframe':{from:`now-${timeframe}`,to:'now'}};
  const open=(query:string)=>sendIntent({'dt.query':query,...time});
  const health=signals.count===undefined?'unknown':(signals.errorRate??0)>=5||(signals.mean??0)>=1500?'critical':(signals.errorRate??0)>=1||(signals.mean??0)>=700?'warning':'healthy';
  return <aside className="application-sidebar" aria-label={`${appCode} application details`}>
    <header className="application-sidebar-header"><div className="workspace-app-emblem"><WorkspaceIcon kind="application" size={38}/></div><div><h2>{appCode}</h2><b data-health={health}>● {environment==='__APP_ONLY__'?'APP only':environment} · {state.loading&&!state.row?'LOADING':health.toUpperCase()}</b></div></header>
    <section className="application-resources"><h3>Explore application</h3>
      <details><summary><WorkspaceIcon kind="services"/>Services <b>{listedServices.length}</b></summary><Button onClick={()=>openInvestigation(serviceLink(appCode,timeframe))}>Open application services ↗</Button><p className="mesh-note">APP-tagged services in the selected application and environment.</p><div className="application-resource-list">{listedServices.map(s=><Button key={s.id} onClick={()=>openInvestigation(serviceLink(undefined,timeframe,s.id))}>{s.name} ↗</Button>)}</div>{services.map(s=><div key={s.id}><small>{s.name}</small><EntityProperties entityId={s.id} timeframe={timeframe}/></div>)}</details>
      <details><summary><WorkspaceIcon kind="services"/>Connected services <b>{flowLoading?'…':connectedServices.length}</b></summary><p className="mesh-note">Other service IDs represented in the flow. Ownership is not inferred; inspect entity tags.</p>{connectedServices.map(s=><div key={s.id}><Button onClick={()=>openInvestigation(serviceLink(undefined,timeframe,s.id))}>{s.name} ↗</Button><EntityProperties entityId={s.id} timeframe={timeframe}/></div>)}</details>
      <details><summary><WorkspaceIcon kind="hosts"/>Hosts <b>{state.hosts?.length??(state.loading?'…':'—')}</b></summary><p className="mesh-note">Hosts observed on this application’s spans in the selected window.</p>{state.hosts?.length?state.hosts.map(id=><div key={id}><Button onClick={()=>openInvestigation(hostLink(timeframe,id))}>{id} ↗</Button><EntityProperties entityId={id} timeframe={timeframe}/></div>):<p className="mesh-note">{state.loading?'Loading correlated hosts…':'No correlated host data available.'}</p>}</details>
      <Button className="workspace-resource-action" disabled={!ids.length} onClick={()=>openInvestigation(logsLink(appCode,timeframe))}><WorkspaceIcon kind="logs"/>Logs <span aria-hidden="true">›</span></Button>
      <Button className="workspace-resource-action" disabled={!ids.length} onClick={()=>open(`${spans}\n| sort start_time desc\n| limit 1000`)}><WorkspaceIcon kind="traces"/>Distributed traces <span>›</span></Button>
      <Button className="workspace-resource-action" onClick={()=>openInvestigation(syntheticLink(appCode,timeframe))}><WorkspaceIcon kind="synthetic"/>Synthetic <small>APP-wide</small></Button>
      <details><summary><WorkspaceIcon kind="rum"/>RUM · Web / Mobile <small>APP-wide</small></summary>{children}</details>
    </section>
    <section className="application-score" aria-label="Transaction score" aria-busy={state.loading&&!state.row}><h3>Transaction score <span title="Non-failed retained service requests completed in under 700 ms. This is not Apdex." aria-label="Score definition" className="workspace-info-icon">i</span></h3><strong>{fmt(signals.score,'%')}</strong>{state.loading&&!state.row&&<small role="status">Loading application metrics…</small>}<progress max={100} value={signals.score??0} aria-label="Good observed request percentage"/><p>Non-failed requests under 700 ms.</p><details className="workspace-score-definition"><summary>How is this calculated?</summary><small>Observed service requests, not Apdex or unique business transactions. Missing durations do not count as good.</small></details></section>
    <section className="application-golden"><h3>Application Golden Signals</h3><div className="signal-grid">
      <div><WorkspaceIcon kind="traffic"/><small>Requests/min</small><strong>{fmt(signals.count===undefined?undefined:signals.count/minutes(timeframe))}</strong></div>
      <div data-health={(signals.errorRate??0)>=5?'critical':undefined}><WorkspaceIcon kind="errors"/><small>Error rate</small><strong>{fmt(signals.errorRate,'%')}</strong></div>
      <div><WorkspaceIcon kind="latency"/><small>Mean response</small><strong>{fmt(signals.mean,' ms')}</strong></div>
      <div><WorkspaceIcon kind="traffic"/><small>p95 response</small><strong>{fmt(signals.p95,' ms')}</strong></div>
      <div className="application-cpu"><WorkspaceIcon kind="cpu"/><small>Host CPU · proxy</small><strong>{fmt(state.cpu,'%')}</strong></div>
    </div><details className="workspace-score-definition"><summary>Metric scope · {timeframe}</summary><p className="mesh-note">Metrics use APP-tagged services in the selected environment; connected flow dependencies are listed separately. Retained server spans; sampling affects counts. CPU is the highest host mean, not application saturation. Refresh to update.</p></details></section>
    {state.issues.map((issue,i)=><p key={i} className="mesh-warning" role="alert">{issue}</p>)}
  </aside>;
}
