import React from 'react';
import { TopologyNode } from '../types/observability';
import { minutes } from './model';
import { InvestigationAreas } from './InvestigationAreas';
export function DependencyInspector({node,appCode,timeframe}:{node:TopologyNode;appCode?:string;timeframe:string}) {
  const fmt=(value:number|undefined,suffix='')=>value===undefined?'No data':`${value.toLocaleString(undefined,{maximumFractionDigits:2})}${suffix}`;
  const observed=node.traffic!==undefined && node.traffic>0;
  const impacted=observed?(node.errorRate??0)>0 || (node.latencyMs??0)>=700:undefined;
  return <section className="mesh-inspector"><h3>{node.label}</h3><h4>Golden signals · {timeframe}</h4>
    <div className="signal-grid">
      <div><small>Traffic · observed calls/min</small><strong>{fmt(observed?node.traffic!/minutes(timeframe):undefined)}</strong></div>
      <div data-health={observed&&(node.latencyMs??0)>=700?'critical':'unknown'}><small>Latency · mean response</small><strong>{fmt(observed?node.latencyMs:undefined,' ms')}</strong></div>
      <div data-health={observed&&(node.errorRate??0)>0?'critical':'unknown'}><small>Errors · observed calls</small><strong>{fmt(observed?node.errorRate:undefined,'%')}</strong></div>
      <div><small>Saturation</small><strong>Not available</strong></div>
    </div>
    <p className="mesh-note">Selected dependency's observed call metrics from the loaded flow. No service entity or host saturation is inferred. Red: any observed error or mean response ≥700 ms. Refresh the flow to reload these metrics.</p>
    <InvestigationAreas appCode={appCode??node.appCode} timeframe={timeframe} impacted={impacted}/>
  </section>;
}
