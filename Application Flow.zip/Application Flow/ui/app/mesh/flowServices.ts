import type {ComponentService, TopologyModel} from '../types/observability';

/** Services represented by the architecture, including members of collapsed nodes. */
export function flowServices(model:TopologyModel):ComponentService[] {
  const services=new Map<string,ComponentService>();
  for(const node of model.nodes){
    if(node.kind==='database'||node.kind==='messaging'||node.id.startsWith('rum:'))continue;
    const members=node.services?.length?node.services:[{id:node.entityId??node.id,name:node.label}];
    for(const service of members){
      if(service.id.startsWith('SERVICE-'))services.set(service.id,service);
    }
  }
  return [...services.values()].sort((a,b)=>a.name.localeCompare(b.name));
}
