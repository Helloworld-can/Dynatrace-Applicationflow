import React,{useEffect,useState} from 'react';
import {DqlRecord,dqlString,runDql} from '../hooks/query';
import type {TopologyNode} from '../types/observability';

export const propertyText=(value:unknown):string=>value==null?'—':typeof value==='string'?value:JSON.stringify(value)??'—';
export function entityType(id:string):string|undefined {
  const prefix=id.split('-')[0];
  const types:Record<string,string>={SERVICE:'service',HOST:'host',PROCESS_GROUP:'process_group',PROCESS_GROUP_INSTANCE:'process_group_instance',APPLICATION:'application',MOBILE_APPLICATION:'mobile_application',CUSTOM_APPLICATION:'custom_application',CUSTOM_DEVICE:'custom_device',RELATIONAL_DATABASE_SERVICE:'relational_database_service',HTTP_CHECK:'http_check',SYNTHETIC_TEST:'synthetic_test'};
  return types[prefix];
}
export function EntityProperties({entityId,node,timeframe='2h',observed}:{entityId?:string;node?:TopologyNode;timeframe?:string;observed?:DqlRecord}) {
  const [expanded,setExpanded]=useState(false),[record,setRecord]=useState<DqlRecord>(),[message,setMessage]=useState(''),[loading,setLoading]=useState(false);
  const id=entityId??node?.entityId??node?.id??'',type=entityType(id);
  useEffect(()=>{
    let cancelled=false;setRecord(undefined);setMessage('');setLoading(false);
    if(!expanded||!type)return;
    setLoading(true);
    void runDql(`fetch dt.entity.${type}\n| filter id == ${dqlString(id)}\n| limit 1`,timeframe,m=>{if(!cancelled)setMessage(m);}).then(rows=>{if(!cancelled){setRecord(rows[0]);if(!rows.length)setMessage('No entity properties returned in this scope.');}}).catch((e:unknown)=>{if(!cancelled)setMessage(e instanceof Error?e.message:'Entity properties unavailable');}).finally(()=>{if(!cancelled)setLoading(false);});
    return()=>{cancelled=true;};
  },[expanded,id,type,timeframe]);
  const properties: DqlRecord=observed??(node?{'Flow ID':node.id,'Name':node.label,'Kind':node.kind,'Observed health':node.health,'Application scope':node.appCode,'Environment scope':node.environment,'Details':node.details}:{});
  const tags=Array.isArray(record?.tags)?record.tags:[];
  return <details className="entity-properties" onToggle={e=>setExpanded(e.currentTarget.open)}><summary>Properties &amp; tags</summary>
    <h4>Observed properties</h4><dl>{Object.entries(properties).filter(([,v])=>v!=null).map(([key,value])=><React.Fragment key={key}><dt>{key}</dt><dd>{propertyText(value)}</dd></React.Fragment>)}</dl>
    {loading?<p role="status">Loading entity properties…</p>:<><h4>Entity tags</h4>{tags.length?<ul>{tags.map((tag,i)=><li key={i}>{propertyText(tag)}</li>)}</ul>:<p>{!type?'No resolved Dynatrace entity ID. Tags cannot be inferred from the application scope.':record?'No tags returned for this entity.':'Tags unavailable.'}</p>}
    {record&&<><h4>Entity properties · {id}</h4><dl>{Object.entries(record).filter(([key])=>key!=='tags').map(([key,value])=><React.Fragment key={key}><dt>{key}</dt><dd>{propertyText(value)}</dd></React.Fragment>)}</dl></>}</>}
    {message&&<p role="alert" className="mesh-warning">{message}</p>}
  </details>;
}
