import React from 'react';
import {WorkspaceIcon} from './WorkspaceIcon';

export function FlowLegend({overview=false}:{overview?:boolean}){
  const colours=[['#079465','Healthy'],['#df9600','Warning'],['#d53343','Critical'],['#8392a5','Unknown / no data']];
  return <aside aria-label="Flow legend" style={{position:'sticky',top:0,zIndex:8,background:'#fff',border:'1px solid #d5e2ed',borderRadius:6,padding:'9px 12px',margin:'6px 0',fontSize:12,lineHeight:1.5,color:'#183c60',boxShadow:'0 2px 5px #183c6010'}}>
    <div style={{display:'flex',gap:14,alignItems:'center',flexWrap:'wrap'}}><strong>Legend</strong><span>Node health:</span>{colours.map(([colour,label])=><span key={label} style={{display:'inline-flex',gap:5,alignItems:'center'}}><span aria-hidden="true" style={{width:10,height:10,borderRadius:'50%',background:colour}}/>{label}</span>)}</div>
    <div style={{display:'flex',gap:16,alignItems:'center',flexWrap:'wrap',marginTop:5}}>
      <span><b aria-hidden="true">→</b> Caller → destination</span>
      <span><span aria-hidden="true" style={{display:'inline-block',width:25,borderTop:'2px solid #79a8ed',marginRight:5}}/> {overview?'Observed connection':'Observed / correlated evidence'}</span>
      <span><span aria-hidden="true" style={{display:'inline-block',width:25,borderTop:'2px dashed #79a8ed',marginRight:5}}/> {overview?'ENV scope unverified':'Smartscape-only or unresolved — read edge label'}</span>
      {!overview&&<><span><WorkspaceIcon kind="worker" size={16}/> Monitored service</span><span><WorkspaceIcon kind="external" size={16}/> Destination endpoint</span><span><WorkspaceIcon kind="database" size={16}/> Database</span><span><WorkspaceIcon kind="queue" size={16}/> Queue / topic</span></>}
    </div>
    <div style={{marginTop:4}}>calls/min = observed call rate · ms = mean duration · sampled calls ≠ full-timeframe request totals. {overview?'ENV warnings describe scope, not health.':'Coloured links describe request outcomes, not device health; blue is a neutral connection colour. Solid lines do not certify the intended architecture.'}</div>
  </aside>;
}
